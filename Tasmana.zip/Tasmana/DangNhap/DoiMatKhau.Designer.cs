﻿namespace DangNhap
{
    partial class DoiMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DoiMatKhau));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TXB_mkhientai = new System.Windows.Forms.TextBox();
            this.TXB_mkmoi = new System.Windows.Forms.TextBox();
            this.TXB_xacnhanmk = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.BTN_luu = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_close = new Guna.UI.WinForms.GunaButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // TXB_mkhientai
            // 
            this.TXB_mkhientai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.TXB_mkhientai.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.TXB_mkhientai, "TXB_mkhientai");
            this.TXB_mkhientai.ForeColor = System.Drawing.Color.White;
            this.TXB_mkhientai.Name = "TXB_mkhientai";
            this.TXB_mkhientai.UseSystemPasswordChar = true;
            // 
            // TXB_mkmoi
            // 
            this.TXB_mkmoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.TXB_mkmoi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.TXB_mkmoi, "TXB_mkmoi");
            this.TXB_mkmoi.ForeColor = System.Drawing.Color.White;
            this.TXB_mkmoi.Name = "TXB_mkmoi";
            this.TXB_mkmoi.UseSystemPasswordChar = true;
            // 
            // TXB_xacnhanmk
            // 
            this.TXB_xacnhanmk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.TXB_xacnhanmk.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.TXB_xacnhanmk, "TXB_xacnhanmk");
            this.TXB_xacnhanmk.ForeColor = System.Drawing.Color.White;
            this.TXB_xacnhanmk.Name = "TXB_xacnhanmk";
            this.TXB_xacnhanmk.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // BTN_luu
            // 
            this.BTN_luu.Animated = true;
            this.BTN_luu.AnimationHoverSpeed = 0.5F;
            this.BTN_luu.AnimationSpeed = 0.03F;
            this.BTN_luu.BackColor = System.Drawing.Color.Transparent;
            this.BTN_luu.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_luu.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.BorderColor = System.Drawing.Color.Black;
            this.BTN_luu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_luu.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_luu, "BTN_luu");
            this.BTN_luu.ForeColor = System.Drawing.Color.White;
            this.BTN_luu.Image = null;
            this.BTN_luu.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_luu.Name = "BTN_luu";
            this.BTN_luu.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverImage = null;
            this.BTN_luu.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_luu.Radius = 5;
            this.BTN_luu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_luu.Click += new System.EventHandler(this.BTN_luu_Click);
            // 
            // BTN_close
            // 
            this.BTN_close.AnimationHoverSpeed = 0.07F;
            this.BTN_close.AnimationSpeed = 0.03F;
            this.BTN_close.BackColor = System.Drawing.Color.Transparent;
            this.BTN_close.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_close.BorderColor = System.Drawing.Color.Black;
            this.BTN_close.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_close.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_close, "BTN_close");
            this.BTN_close.ForeColor = System.Drawing.Color.White;
            this.BTN_close.Image = ((System.Drawing.Image)(resources.GetObject("BTN_close.Image")));
            this.BTN_close.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_close.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_close.Name = "BTN_close";
            this.BTN_close.OnHoverBaseColor = System.Drawing.Color.Red;
            this.BTN_close.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.BTN_close.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_close.OnHoverImage = null;
            this.BTN_close.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_close.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_close.Click += new System.EventHandler(this.BTN_close_Click);
            // 
            // DoiMatKhau
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.Controls.Add(this.BTN_luu);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TXB_xacnhanmk);
            this.Controls.Add(this.TXB_mkmoi);
            this.Controls.Add(this.TXB_mkhientai);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTN_close);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DoiMatKhau";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DoiMatKhau_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DoiMatKhau_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.DoiMatKhau_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXB_mkhientai;
        private System.Windows.Forms.TextBox TXB_mkmoi;
        private System.Windows.Forms.TextBox TXB_xacnhanmk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private Guna.UI.WinForms.GunaGradientButton BTN_luu;
        private Guna.UI.WinForms.GunaButton BTN_close;
    }
}