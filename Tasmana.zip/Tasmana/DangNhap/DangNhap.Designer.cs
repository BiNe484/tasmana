﻿
namespace DangNhap
{
    partial class DangNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DangNhap));
            this.BT_DangNhap = new Guna.UI.WinForms.GunaButton();
            this.LB_quenpw = new System.Windows.Forms.Label();
            this.TB_MatKhau = new System.Windows.Forms.TextBox();
            this.LB_pw = new System.Windows.Forms.Label();
            this.LB_id = new System.Windows.Forms.Label();
            this.LB_tasmana = new System.Windows.Forms.Label();
            this.BTN_close = new Guna.UI.WinForms.GunaButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LB_welcometo = new System.Windows.Forms.Label();
            this.LB_dangnhap = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.CBBB_manguoidung = new Syncfusion.Windows.Forms.Tools.ComboBoxBase();
            this.CHB_luuid = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTN_facelogin = new Guna.UI.WinForms.GunaButton();
            this.BTN_show = new System.Windows.Forms.Button();
            this.BTN_hide = new System.Windows.Forms.Button();
            this.LB_Wrong = new System.Windows.Forms.Label();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.CBBB_manguoidung)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // BT_DangNhap
            // 
            resources.ApplyResources(this.BT_DangNhap, "BT_DangNhap");
            this.BT_DangNhap.Animated = true;
            this.BT_DangNhap.AnimationHoverSpeed = 0.3F;
            this.BT_DangNhap.AnimationSpeed = 0.03F;
            this.BT_DangNhap.BackColor = System.Drawing.Color.Transparent;
            this.BT_DangNhap.BaseColor = System.Drawing.Color.Transparent;
            this.BT_DangNhap.BorderColor = System.Drawing.Color.White;
            this.BT_DangNhap.BorderSize = 2;
            this.BT_DangNhap.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BT_DangNhap.FocusedColor = System.Drawing.Color.Empty;
            this.BT_DangNhap.ForeColor = System.Drawing.Color.White;
            this.BT_DangNhap.Image = null;
            this.BT_DangNhap.ImageSize = new System.Drawing.Size(20, 20);
            this.BT_DangNhap.Name = "BT_DangNhap";
            this.BT_DangNhap.OnHoverBaseColor = System.Drawing.Color.White;
            this.BT_DangNhap.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BT_DangNhap.OnHoverForeColor = System.Drawing.Color.Black;
            this.BT_DangNhap.OnHoverImage = null;
            this.BT_DangNhap.OnPressedColor = System.Drawing.Color.DimGray;
            this.BT_DangNhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BT_DangNhap.Click += new System.EventHandler(this.BT_DangNhap_Click);
            // 
            // LB_quenpw
            // 
            resources.ApplyResources(this.LB_quenpw, "LB_quenpw");
            this.LB_quenpw.BackColor = System.Drawing.Color.Transparent;
            this.LB_quenpw.ForeColor = System.Drawing.Color.Silver;
            this.LB_quenpw.Name = "LB_quenpw";
            this.LB_quenpw.Click += new System.EventHandler(this.LB_quenpw_Click);
            // 
            // TB_MatKhau
            // 
            resources.ApplyResources(this.TB_MatKhau, "TB_MatKhau");
            this.TB_MatKhau.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(17)))), ((int)(((byte)(26)))));
            this.TB_MatKhau.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TB_MatKhau.ForeColor = System.Drawing.Color.White;
            this.TB_MatKhau.Name = "TB_MatKhau";
            // 
            // LB_pw
            // 
            resources.ApplyResources(this.LB_pw, "LB_pw");
            this.LB_pw.BackColor = System.Drawing.Color.Transparent;
            this.LB_pw.ForeColor = System.Drawing.Color.Silver;
            this.LB_pw.Name = "LB_pw";
            // 
            // LB_id
            // 
            resources.ApplyResources(this.LB_id, "LB_id");
            this.LB_id.BackColor = System.Drawing.Color.Transparent;
            this.LB_id.ForeColor = System.Drawing.Color.Silver;
            this.LB_id.Name = "LB_id";
            // 
            // LB_tasmana
            // 
            resources.ApplyResources(this.LB_tasmana, "LB_tasmana");
            this.LB_tasmana.BackColor = System.Drawing.Color.Transparent;
            this.LB_tasmana.ForeColor = System.Drawing.Color.White;
            this.LB_tasmana.Name = "LB_tasmana";
            // 
            // BTN_close
            // 
            resources.ApplyResources(this.BTN_close, "BTN_close");
            this.BTN_close.AnimationHoverSpeed = 0.07F;
            this.BTN_close.AnimationSpeed = 0.03F;
            this.BTN_close.BackColor = System.Drawing.Color.Transparent;
            this.BTN_close.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_close.BorderColor = System.Drawing.Color.Black;
            this.BTN_close.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_close.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_close.ForeColor = System.Drawing.Color.White;
            this.BTN_close.Image = ((System.Drawing.Image)(resources.GetObject("BTN_close.Image")));
            this.BTN_close.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_close.ImageSize = new System.Drawing.Size(15, 15);
            this.BTN_close.Name = "BTN_close";
            this.BTN_close.OnHoverBaseColor = System.Drawing.Color.Red;
            this.BTN_close.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.BTN_close.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_close.OnHoverImage = null;
            this.BTN_close.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_close.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_close.Click += new System.EventHandler(this.BTN_close_Click);
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Name = "panel2";
            // 
            // LB_welcometo
            // 
            resources.ApplyResources(this.LB_welcometo, "LB_welcometo");
            this.LB_welcometo.BackColor = System.Drawing.Color.Transparent;
            this.LB_welcometo.ForeColor = System.Drawing.Color.White;
            this.LB_welcometo.Name = "LB_welcometo";
            // 
            // LB_dangnhap
            // 
            resources.ApplyResources(this.LB_dangnhap, "LB_dangnhap");
            this.LB_dangnhap.BackColor = System.Drawing.Color.Transparent;
            this.LB_dangnhap.ForeColor = System.Drawing.Color.White;
            this.LB_dangnhap.Name = "LB_dangnhap";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Name = "panel3";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.Silver;
            this.panel4.Name = "panel4";
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.Silver;
            this.panel5.Name = "panel5";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Name = "panel6";
            // 
            // CBBB_manguoidung
            // 
            resources.ApplyResources(this.CBBB_manguoidung, "CBBB_manguoidung");
            this.CBBB_manguoidung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(16)))), ((int)(((byte)(22)))));
            this.CBBB_manguoidung.BeforeTouchSize = new System.Drawing.Size(452, 30);
            this.CBBB_manguoidung.FlatBorderColor = System.Drawing.Color.Transparent;
            this.CBBB_manguoidung.FlatStyle = Syncfusion.Windows.Forms.Tools.ComboFlatStyle.Flat;
            this.CBBB_manguoidung.ForeColor = System.Drawing.Color.White;
            this.CBBB_manguoidung.MetroBorderColor = System.Drawing.Color.Silver;
            this.CBBB_manguoidung.Name = "CBBB_manguoidung";
            this.CBBB_manguoidung.SelectionChangeCommitted += new System.EventHandler(this.CBBB_manguoidung_SelectionChangeCommitted);
            // 
            // CHB_luuid
            // 
            resources.ApplyResources(this.CHB_luuid, "CHB_luuid");
            this.CHB_luuid.BackColor = System.Drawing.Color.Transparent;
            this.CHB_luuid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CHB_luuid.ForeColor = System.Drawing.Color.Silver;
            this.CHB_luuid.Name = "CHB_luuid";
            this.CHB_luuid.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Name = "panel1";
            // 
            // BTN_facelogin
            // 
            resources.ApplyResources(this.BTN_facelogin, "BTN_facelogin");
            this.BTN_facelogin.Animated = true;
            this.BTN_facelogin.AnimationHoverSpeed = 0.3F;
            this.BTN_facelogin.AnimationSpeed = 0.03F;
            this.BTN_facelogin.BackColor = System.Drawing.Color.Transparent;
            this.BTN_facelogin.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_facelogin.BorderColor = System.Drawing.Color.White;
            this.BTN_facelogin.BorderSize = 2;
            this.BTN_facelogin.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_facelogin.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_facelogin.ForeColor = System.Drawing.Color.White;
            this.BTN_facelogin.Image = null;
            this.BTN_facelogin.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_facelogin.Name = "BTN_facelogin";
            this.BTN_facelogin.OnHoverBaseColor = System.Drawing.Color.White;
            this.BTN_facelogin.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_facelogin.OnHoverForeColor = System.Drawing.Color.Black;
            this.BTN_facelogin.OnHoverImage = null;
            this.BTN_facelogin.OnPressedColor = System.Drawing.Color.DimGray;
            this.BTN_facelogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_facelogin.Click += new System.EventHandler(this.BTN_facelogin_Click);
            // 
            // BTN_show
            // 
            resources.ApplyResources(this.BTN_show, "BTN_show");
            this.BTN_show.BackColor = System.Drawing.Color.Transparent;
            this.BTN_show.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BTN_show.FlatAppearance.BorderSize = 0;
            this.BTN_show.Name = "BTN_show";
            this.BTN_show.UseVisualStyleBackColor = false;
            this.BTN_show.Click += new System.EventHandler(this.BTN_show_Click);
            // 
            // BTN_hide
            // 
            resources.ApplyResources(this.BTN_hide, "BTN_hide");
            this.BTN_hide.BackColor = System.Drawing.Color.Transparent;
            this.BTN_hide.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BTN_hide.FlatAppearance.BorderSize = 0;
            this.BTN_hide.Name = "BTN_hide";
            this.BTN_hide.UseVisualStyleBackColor = false;
            this.BTN_hide.Click += new System.EventHandler(this.BTN_hide_Click);
            // 
            // LB_Wrong
            // 
            resources.ApplyResources(this.LB_Wrong, "LB_Wrong");
            this.LB_Wrong.BackColor = System.Drawing.Color.Transparent;
            this.LB_Wrong.ForeColor = System.Drawing.Color.Red;
            this.LB_Wrong.Name = "LB_Wrong";
            // 
            // gunaPictureBox3
            // 
            resources.ApplyResources(this.gunaPictureBox3, "gunaPictureBox3");
            this.gunaPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.Transparent;
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.TabStop = false;
            // 
            // DangNhap
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.Controls.Add(this.CHB_luuid);
            this.Controls.Add(this.LB_tasmana);
            this.Controls.Add(this.LB_Wrong);
            this.Controls.Add(this.BTN_show);
            this.Controls.Add(this.BTN_hide);
            this.Controls.Add(this.BTN_facelogin);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.LB_dangnhap);
            this.Controls.Add(this.LB_welcometo);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.BTN_close);
            this.Controls.Add(this.BT_DangNhap);
            this.Controls.Add(this.LB_quenpw);
            this.Controls.Add(this.LB_id);
            this.Controls.Add(this.TB_MatKhau);
            this.Controls.Add(this.LB_pw);
            this.Controls.Add(this.CBBB_manguoidung);
            this.Controls.Add(this.gunaPictureBox3);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DangNhap";
            this.Load += new System.EventHandler(this.DangNhap_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DangNhap_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DangNhap_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.DangNhap_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.CBBB_manguoidung)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LB_tasmana;
        private System.Windows.Forms.TextBox TB_MatKhau;
        private System.Windows.Forms.Label LB_pw;
        private System.Windows.Forms.Label LB_id;
        private System.Windows.Forms.Label LB_quenpw;
        private Guna.UI.WinForms.GunaButton BT_DangNhap;
        private Guna.UI.WinForms.GunaButton BTN_close;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label LB_welcometo;
        private System.Windows.Forms.Label LB_dangnhap;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private Syncfusion.Windows.Forms.Tools.ComboBoxBase CBBB_manguoidung;
        private System.Windows.Forms.CheckBox CHB_luuid;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaButton BTN_facelogin;
        private System.Windows.Forms.Button BTN_show;
        private System.Windows.Forms.Button BTN_hide;
        private System.Windows.Forms.Label LB_Wrong;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
    }
}

