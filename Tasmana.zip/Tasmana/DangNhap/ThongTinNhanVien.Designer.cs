﻿namespace DangNhap
{
    partial class ThongTinNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinNhanVien));
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.TXB_matkhau = new System.Windows.Forms.TextBox();
            this.TXB_manguoidung = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.BTN_doimatkhau = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.LB_taikhoan = new System.Windows.Forms.Label();
            this.LB_matkhau = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.TXB_bhxh = new System.Windows.Forms.TextBox();
            this.TXB_quequan = new System.Windows.Forms.TextBox();
            this.TXB_email = new System.Windows.Forms.TextBox();
            this.TXB_sdt = new System.Windows.Forms.TextBox();
            this.TXB_cccd = new System.Windows.Forms.TextBox();
            this.TXB_thuongtru = new System.Windows.Forms.TextBox();
            this.TXB_tamtru = new System.Windows.Forms.TextBox();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.LB_sdt = new System.Windows.Forms.Label();
            this.LB_quequan = new System.Windows.Forms.Label();
            this.LB_tamtru = new System.Windows.Forms.Label();
            this.LB_email = new System.Windows.Forms.Label();
            this.LB_BHXH = new System.Windows.Forms.Label();
            this.LB_thuongtru = new System.Windows.Forms.Label();
            this.LB_id = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TXB_ngaykyHDLD = new System.Windows.Forms.TextBox();
            this.TXB_ngayhetHDLD = new System.Windows.Forms.TextBox();
            this.TXB_nhom = new System.Windows.Forms.TextBox();
            this.TXB_phongban = new System.Windows.Forms.TextBox();
            this.TXB_loainv = new System.Windows.Forms.TextBox();
            this.TXB_tinhtrangHDLD = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CHB_tunglanv = new System.Windows.Forms.CheckBox();
            this.LB_vitri = new System.Windows.Forms.Label();
            this.LB_manhom = new System.Windows.Forms.Label();
            this.LB_ngayhetHDLD = new System.Windows.Forms.Label();
            this.LB_HDLD = new System.Windows.Forms.Label();
            this.LB_ngaykyHDLD = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.TXB_ngaysinh = new System.Windows.Forms.TextBox();
            this.TXB_gioitinh = new System.Windows.Forms.TextBox();
            this.TXB_ten = new System.Windows.Forms.TextBox();
            this.TXB_ho = new System.Windows.Forms.TextBox();
            this.TXB_manv = new System.Windows.Forms.TextBox();
            this.TXB_honnhan = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LB_hovaten = new System.Windows.Forms.Label();
            this.LB_manv = new System.Windows.Forms.Label();
            this.LB_honnhan = new System.Windows.Forms.Label();
            this.LB_ngaysinh = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Name = "panel5";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel6.Controls.Add(this.TXB_matkhau);
            this.panel6.Controls.Add(this.TXB_manguoidung);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Controls.Add(this.BTN_doimatkhau);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.LB_taikhoan);
            this.panel6.Controls.Add(this.LB_matkhau);
            this.panel6.Name = "panel6";
            // 
            // TXB_matkhau
            // 
            resources.ApplyResources(this.TXB_matkhau, "TXB_matkhau");
            this.TXB_matkhau.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_matkhau.ForeColor = System.Drawing.Color.White;
            this.TXB_matkhau.Name = "TXB_matkhau";
            // 
            // TXB_manguoidung
            // 
            resources.ApplyResources(this.TXB_manguoidung, "TXB_manguoidung");
            this.TXB_manguoidung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_manguoidung.ForeColor = System.Drawing.Color.White;
            this.TXB_manguoidung.Name = "TXB_manguoidung";
            // 
            // panel9
            // 
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Name = "panel9";
            // 
            // panel8
            // 
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Name = "panel8";
            // 
            // panel7
            // 
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Name = "panel7";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Name = "panel2";
            // 
            // BTN_doimatkhau
            // 
            resources.ApplyResources(this.BTN_doimatkhau, "BTN_doimatkhau");
            this.BTN_doimatkhau.FlatAppearance.BorderSize = 3;
            this.BTN_doimatkhau.ForeColor = System.Drawing.Color.White;
            this.BTN_doimatkhau.Name = "BTN_doimatkhau";
            this.BTN_doimatkhau.UseVisualStyleBackColor = true;
            this.BTN_doimatkhau.Click += new System.EventHandler(this.BTN_doimatkhau_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Name = "label5";
            // 
            // LB_taikhoan
            // 
            resources.ApplyResources(this.LB_taikhoan, "LB_taikhoan");
            this.LB_taikhoan.ForeColor = System.Drawing.Color.White;
            this.LB_taikhoan.Name = "LB_taikhoan";
            // 
            // LB_matkhau
            // 
            resources.ApplyResources(this.LB_matkhau, "LB_matkhau");
            this.LB_matkhau.ForeColor = System.Drawing.Color.White;
            this.LB_matkhau.Name = "LB_matkhau";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel4.Controls.Add(this.TXB_bhxh);
            this.panel4.Controls.Add(this.TXB_quequan);
            this.panel4.Controls.Add(this.TXB_email);
            this.panel4.Controls.Add(this.TXB_sdt);
            this.panel4.Controls.Add(this.TXB_cccd);
            this.panel4.Controls.Add(this.TXB_thuongtru);
            this.panel4.Controls.Add(this.TXB_tamtru);
            this.panel4.Controls.Add(this.panel21);
            this.panel4.Controls.Add(this.panel20);
            this.panel4.Controls.Add(this.panel19);
            this.panel4.Controls.Add(this.panel18);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.LB_sdt);
            this.panel4.Controls.Add(this.LB_quequan);
            this.panel4.Controls.Add(this.LB_tamtru);
            this.panel4.Controls.Add(this.LB_email);
            this.panel4.Controls.Add(this.LB_BHXH);
            this.panel4.Controls.Add(this.LB_thuongtru);
            this.panel4.Controls.Add(this.LB_id);
            this.panel4.Name = "panel4";
            // 
            // TXB_bhxh
            // 
            resources.ApplyResources(this.TXB_bhxh, "TXB_bhxh");
            this.TXB_bhxh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_bhxh.ForeColor = System.Drawing.Color.White;
            this.TXB_bhxh.Name = "TXB_bhxh";
            // 
            // TXB_quequan
            // 
            resources.ApplyResources(this.TXB_quequan, "TXB_quequan");
            this.TXB_quequan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_quequan.ForeColor = System.Drawing.Color.White;
            this.TXB_quequan.Name = "TXB_quequan";
            // 
            // TXB_email
            // 
            resources.ApplyResources(this.TXB_email, "TXB_email");
            this.TXB_email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_email.ForeColor = System.Drawing.Color.White;
            this.TXB_email.Name = "TXB_email";
            // 
            // TXB_sdt
            // 
            resources.ApplyResources(this.TXB_sdt, "TXB_sdt");
            this.TXB_sdt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_sdt.ForeColor = System.Drawing.Color.White;
            this.TXB_sdt.Name = "TXB_sdt";
            // 
            // TXB_cccd
            // 
            resources.ApplyResources(this.TXB_cccd, "TXB_cccd");
            this.TXB_cccd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_cccd.ForeColor = System.Drawing.Color.White;
            this.TXB_cccd.Name = "TXB_cccd";
            // 
            // TXB_thuongtru
            // 
            resources.ApplyResources(this.TXB_thuongtru, "TXB_thuongtru");
            this.TXB_thuongtru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_thuongtru.ForeColor = System.Drawing.Color.White;
            this.TXB_thuongtru.Name = "TXB_thuongtru";
            // 
            // TXB_tamtru
            // 
            resources.ApplyResources(this.TXB_tamtru, "TXB_tamtru");
            this.TXB_tamtru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_tamtru.ForeColor = System.Drawing.Color.White;
            this.TXB_tamtru.Name = "TXB_tamtru";
            // 
            // panel21
            // 
            resources.ApplyResources(this.panel21, "panel21");
            this.panel21.BackColor = System.Drawing.Color.White;
            this.panel21.Name = "panel21";
            // 
            // panel20
            // 
            resources.ApplyResources(this.panel20, "panel20");
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.Name = "panel20";
            // 
            // panel19
            // 
            resources.ApplyResources(this.panel19, "panel19");
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Name = "panel19";
            // 
            // panel18
            // 
            resources.ApplyResources(this.panel18, "panel18");
            this.panel18.BackColor = System.Drawing.Color.White;
            this.panel18.Name = "panel18";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            // 
            // LB_sdt
            // 
            resources.ApplyResources(this.LB_sdt, "LB_sdt");
            this.LB_sdt.ForeColor = System.Drawing.Color.White;
            this.LB_sdt.Name = "LB_sdt";
            // 
            // LB_quequan
            // 
            resources.ApplyResources(this.LB_quequan, "LB_quequan");
            this.LB_quequan.ForeColor = System.Drawing.Color.White;
            this.LB_quequan.Name = "LB_quequan";
            // 
            // LB_tamtru
            // 
            resources.ApplyResources(this.LB_tamtru, "LB_tamtru");
            this.LB_tamtru.ForeColor = System.Drawing.Color.White;
            this.LB_tamtru.Name = "LB_tamtru";
            // 
            // LB_email
            // 
            resources.ApplyResources(this.LB_email, "LB_email");
            this.LB_email.ForeColor = System.Drawing.Color.White;
            this.LB_email.Name = "LB_email";
            // 
            // LB_BHXH
            // 
            resources.ApplyResources(this.LB_BHXH, "LB_BHXH");
            this.LB_BHXH.ForeColor = System.Drawing.Color.White;
            this.LB_BHXH.Name = "LB_BHXH";
            // 
            // LB_thuongtru
            // 
            resources.ApplyResources(this.LB_thuongtru, "LB_thuongtru");
            this.LB_thuongtru.ForeColor = System.Drawing.Color.White;
            this.LB_thuongtru.Name = "LB_thuongtru";
            // 
            // LB_id
            // 
            resources.ApplyResources(this.LB_id, "LB_id");
            this.LB_id.ForeColor = System.Drawing.Color.White;
            this.LB_id.Name = "LB_id";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.TXB_ngaykyHDLD);
            this.panel1.Controls.Add(this.TXB_ngayhetHDLD);
            this.panel1.Controls.Add(this.TXB_nhom);
            this.panel1.Controls.Add(this.TXB_phongban);
            this.panel1.Controls.Add(this.TXB_loainv);
            this.panel1.Controls.Add(this.TXB_tinhtrangHDLD);
            this.panel1.Controls.Add(this.panel17);
            this.panel1.Controls.Add(this.panel16);
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.CHB_tunglanv);
            this.panel1.Controls.Add(this.LB_vitri);
            this.panel1.Controls.Add(this.LB_manhom);
            this.panel1.Controls.Add(this.LB_ngayhetHDLD);
            this.panel1.Controls.Add(this.LB_HDLD);
            this.panel1.Controls.Add(this.LB_ngaykyHDLD);
            this.panel1.Name = "panel1";
            // 
            // TXB_ngaykyHDLD
            // 
            resources.ApplyResources(this.TXB_ngaykyHDLD, "TXB_ngaykyHDLD");
            this.TXB_ngaykyHDLD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_ngaykyHDLD.ForeColor = System.Drawing.Color.White;
            this.TXB_ngaykyHDLD.Name = "TXB_ngaykyHDLD";
            // 
            // TXB_ngayhetHDLD
            // 
            resources.ApplyResources(this.TXB_ngayhetHDLD, "TXB_ngayhetHDLD");
            this.TXB_ngayhetHDLD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_ngayhetHDLD.ForeColor = System.Drawing.Color.White;
            this.TXB_ngayhetHDLD.Name = "TXB_ngayhetHDLD";
            // 
            // TXB_nhom
            // 
            resources.ApplyResources(this.TXB_nhom, "TXB_nhom");
            this.TXB_nhom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_nhom.ForeColor = System.Drawing.Color.White;
            this.TXB_nhom.Name = "TXB_nhom";
            // 
            // TXB_phongban
            // 
            resources.ApplyResources(this.TXB_phongban, "TXB_phongban");
            this.TXB_phongban.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_phongban.ForeColor = System.Drawing.Color.White;
            this.TXB_phongban.Name = "TXB_phongban";
            // 
            // TXB_loainv
            // 
            resources.ApplyResources(this.TXB_loainv, "TXB_loainv");
            this.TXB_loainv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_loainv.ForeColor = System.Drawing.Color.White;
            this.TXB_loainv.Name = "TXB_loainv";
            // 
            // TXB_tinhtrangHDLD
            // 
            resources.ApplyResources(this.TXB_tinhtrangHDLD, "TXB_tinhtrangHDLD");
            this.TXB_tinhtrangHDLD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_tinhtrangHDLD.ForeColor = System.Drawing.Color.White;
            this.TXB_tinhtrangHDLD.Name = "TXB_tinhtrangHDLD";
            // 
            // panel17
            // 
            resources.ApplyResources(this.panel17, "panel17");
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Name = "panel17";
            // 
            // panel16
            // 
            resources.ApplyResources(this.panel16, "panel16");
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Name = "panel16";
            // 
            // panel15
            // 
            resources.ApplyResources(this.panel15, "panel15");
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Name = "panel15";
            // 
            // panel14
            // 
            resources.ApplyResources(this.panel14, "panel14");
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Name = "panel14";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Name = "label8";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // CHB_tunglanv
            // 
            resources.ApplyResources(this.CHB_tunglanv, "CHB_tunglanv");
            this.CHB_tunglanv.ForeColor = System.Drawing.Color.White;
            this.CHB_tunglanv.Name = "CHB_tunglanv";
            this.CHB_tunglanv.UseVisualStyleBackColor = true;
            // 
            // LB_vitri
            // 
            resources.ApplyResources(this.LB_vitri, "LB_vitri");
            this.LB_vitri.ForeColor = System.Drawing.Color.White;
            this.LB_vitri.Name = "LB_vitri";
            // 
            // LB_manhom
            // 
            resources.ApplyResources(this.LB_manhom, "LB_manhom");
            this.LB_manhom.ForeColor = System.Drawing.Color.White;
            this.LB_manhom.Name = "LB_manhom";
            // 
            // LB_ngayhetHDLD
            // 
            resources.ApplyResources(this.LB_ngayhetHDLD, "LB_ngayhetHDLD");
            this.LB_ngayhetHDLD.ForeColor = System.Drawing.Color.White;
            this.LB_ngayhetHDLD.Name = "LB_ngayhetHDLD";
            // 
            // LB_HDLD
            // 
            resources.ApplyResources(this.LB_HDLD, "LB_HDLD");
            this.LB_HDLD.ForeColor = System.Drawing.Color.White;
            this.LB_HDLD.Name = "LB_HDLD";
            // 
            // LB_ngaykyHDLD
            // 
            resources.ApplyResources(this.LB_ngaykyHDLD, "LB_ngaykyHDLD");
            this.LB_ngaykyHDLD.ForeColor = System.Drawing.Color.White;
            this.LB_ngaykyHDLD.Name = "LB_ngaykyHDLD";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel3.Controls.Add(this.TXB_ngaysinh);
            this.panel3.Controls.Add(this.TXB_gioitinh);
            this.panel3.Controls.Add(this.TXB_ten);
            this.panel3.Controls.Add(this.TXB_ho);
            this.panel3.Controls.Add(this.TXB_manv);
            this.panel3.Controls.Add(this.TXB_honnhan);
            this.panel3.Controls.Add(this.panel13);
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.LB_hovaten);
            this.panel3.Controls.Add(this.LB_manv);
            this.panel3.Controls.Add(this.LB_honnhan);
            this.panel3.Controls.Add(this.LB_ngaysinh);
            this.panel3.Name = "panel3";
            // 
            // TXB_ngaysinh
            // 
            resources.ApplyResources(this.TXB_ngaysinh, "TXB_ngaysinh");
            this.TXB_ngaysinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_ngaysinh.ForeColor = System.Drawing.Color.White;
            this.TXB_ngaysinh.Name = "TXB_ngaysinh";
            // 
            // TXB_gioitinh
            // 
            resources.ApplyResources(this.TXB_gioitinh, "TXB_gioitinh");
            this.TXB_gioitinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_gioitinh.ForeColor = System.Drawing.Color.White;
            this.TXB_gioitinh.Name = "TXB_gioitinh";
            // 
            // TXB_ten
            // 
            resources.ApplyResources(this.TXB_ten, "TXB_ten");
            this.TXB_ten.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_ten.ForeColor = System.Drawing.Color.White;
            this.TXB_ten.Name = "TXB_ten";
            // 
            // TXB_ho
            // 
            resources.ApplyResources(this.TXB_ho, "TXB_ho");
            this.TXB_ho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_ho.ForeColor = System.Drawing.Color.White;
            this.TXB_ho.Name = "TXB_ho";
            // 
            // TXB_manv
            // 
            resources.ApplyResources(this.TXB_manv, "TXB_manv");
            this.TXB_manv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_manv.ForeColor = System.Drawing.Color.White;
            this.TXB_manv.Name = "TXB_manv";
            // 
            // TXB_honnhan
            // 
            resources.ApplyResources(this.TXB_honnhan, "TXB_honnhan");
            this.TXB_honnhan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_honnhan.ForeColor = System.Drawing.Color.White;
            this.TXB_honnhan.Name = "TXB_honnhan";
            // 
            // panel13
            // 
            resources.ApplyResources(this.panel13, "panel13");
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Name = "panel13";
            // 
            // panel12
            // 
            resources.ApplyResources(this.panel12, "panel12");
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Name = "panel12";
            // 
            // panel11
            // 
            resources.ApplyResources(this.panel11, "panel11");
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Name = "panel11";
            // 
            // panel10
            // 
            resources.ApplyResources(this.panel10, "panel10");
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Name = "panel10";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Name = "label7";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // LB_hovaten
            // 
            resources.ApplyResources(this.LB_hovaten, "LB_hovaten");
            this.LB_hovaten.ForeColor = System.Drawing.Color.White;
            this.LB_hovaten.Name = "LB_hovaten";
            // 
            // LB_manv
            // 
            resources.ApplyResources(this.LB_manv, "LB_manv");
            this.LB_manv.ForeColor = System.Drawing.Color.White;
            this.LB_manv.Name = "LB_manv";
            // 
            // LB_honnhan
            // 
            resources.ApplyResources(this.LB_honnhan, "LB_honnhan");
            this.LB_honnhan.ForeColor = System.Drawing.Color.White;
            this.LB_honnhan.Name = "LB_honnhan";
            // 
            // LB_ngaysinh
            // 
            resources.ApplyResources(this.LB_ngaysinh, "LB_ngaysinh");
            this.LB_ngaysinh.ForeColor = System.Drawing.Color.White;
            this.LB_ngaysinh.Name = "LB_ngaysinh";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            // 
            // ThongTinNhanVien
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel5);
            this.Name = "ThongTinNhanVien";
            this.Load += new System.EventHandler(this.ThongTinNhanVien_Load);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox TXB_matkhau;
        private System.Windows.Forms.TextBox TXB_manguoidung;
        private System.Windows.Forms.Label LB_taikhoan;
        private System.Windows.Forms.Label LB_matkhau;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label LB_sdt;
        private System.Windows.Forms.TextBox TXB_email;
        private System.Windows.Forms.Label LB_email;
        private System.Windows.Forms.TextBox TXB_sdt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TXB_tinhtrangHDLD;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox CHB_tunglanv;
        private System.Windows.Forms.Label LB_vitri;
        private System.Windows.Forms.Label LB_manhom;
        private System.Windows.Forms.Label LB_ngayhetHDLD;
        private System.Windows.Forms.Label LB_HDLD;
        private System.Windows.Forms.Label LB_ngaykyHDLD;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox TXB_ten;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TXB_ho;
        private System.Windows.Forms.TextBox TXB_manv;
        private System.Windows.Forms.Label LB_hovaten;
        private System.Windows.Forms.Label LB_manv;
        private System.Windows.Forms.Label LB_honnhan;
        private System.Windows.Forms.TextBox TXB_honnhan;
        private System.Windows.Forms.Label LB_ngaysinh;
        private System.Windows.Forms.TextBox TXB_bhxh;
        private System.Windows.Forms.TextBox TXB_quequan;
        private System.Windows.Forms.Label LB_quequan;
        private System.Windows.Forms.Label LB_tamtru;
        private System.Windows.Forms.Label LB_BHXH;
        private System.Windows.Forms.Label LB_thuongtru;
        private System.Windows.Forms.Label LB_id;
        private System.Windows.Forms.TextBox TXB_cccd;
        private System.Windows.Forms.TextBox TXB_tamtru;
        private System.Windows.Forms.TextBox TXB_thuongtru;
        private System.Windows.Forms.TextBox TXB_nhom;
        private System.Windows.Forms.TextBox TXB_phongban;
        private System.Windows.Forms.TextBox TXB_loainv;
        private System.Windows.Forms.TextBox TXB_gioitinh;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXB_ngaysinh;
        private System.Windows.Forms.TextBox TXB_ngaykyHDLD;
        private System.Windows.Forms.TextBox TXB_ngayhetHDLD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BTN_doimatkhau;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
    }
}