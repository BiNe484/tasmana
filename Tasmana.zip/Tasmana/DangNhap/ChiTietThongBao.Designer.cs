﻿namespace DangNhap
{
    partial class ChiTietThongBao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChiTietThongBao));
            this.TXB_title = new System.Windows.Forms.TextBox();
            this.LB_author = new System.Windows.Forms.Label();
            this.TXB_content = new System.Windows.Forms.RichTextBox();
            this.LLB_hienfile = new System.Windows.Forms.LinkLabel();
            this.LB_filedinhkem = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            this.SuspendLayout();
            // 
            // TXB_title
            // 
            this.TXB_title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            resources.ApplyResources(this.TXB_title, "TXB_title");
            this.TXB_title.ForeColor = System.Drawing.Color.White;
            this.TXB_title.Name = "TXB_title";
            // 
            // LB_author
            // 
            resources.ApplyResources(this.LB_author, "LB_author");
            this.LB_author.ForeColor = System.Drawing.Color.White;
            this.LB_author.Name = "LB_author";
            // 
            // TXB_content
            // 
            this.TXB_content.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_content, "TXB_content");
            this.TXB_content.ForeColor = System.Drawing.Color.Black;
            this.TXB_content.Name = "TXB_content";
            // 
            // LLB_hienfile
            // 
            resources.ApplyResources(this.LLB_hienfile, "LLB_hienfile");
            this.LLB_hienfile.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(13)))), ((int)(((byte)(14)))));
            this.LLB_hienfile.ForeColor = System.Drawing.Color.Black;
            this.LLB_hienfile.LinkColor = System.Drawing.Color.White;
            this.LLB_hienfile.Name = "LLB_hienfile";
            this.LLB_hienfile.TabStop = true;
            this.LLB_hienfile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LLB_hienfile_LinkClicked);
            // 
            // LB_filedinhkem
            // 
            resources.ApplyResources(this.LB_filedinhkem, "LB_filedinhkem");
            this.LB_filedinhkem.ForeColor = System.Drawing.Color.White;
            this.LB_filedinhkem.Name = "LB_filedinhkem";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // BTN_thoat
            // 
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.DimGray;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // ChiTietThongBao
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.BTN_thoat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.LB_filedinhkem);
            this.Controls.Add(this.LLB_hienfile);
            this.Controls.Add(this.TXB_content);
            this.Controls.Add(this.LB_author);
            this.Controls.Add(this.TXB_title);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChiTietThongBao";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ChiTietThongBao_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ChiTietThongBao_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ChiTietThongBao_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXB_title;
        private System.Windows.Forms.Label LB_author;
        private System.Windows.Forms.RichTextBox TXB_content;
        private System.Windows.Forms.LinkLabel LLB_hienfile;
        private System.Windows.Forms.Label LB_filedinhkem;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
    }
}