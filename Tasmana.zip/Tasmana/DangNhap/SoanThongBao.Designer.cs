﻿namespace DangNhap
{
    partial class SoanThongBao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SoanThongBao));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.LB_den = new System.Windows.Forms.Label();
            this.PN_hienthi = new System.Windows.Forms.Panel();
            this.LLB_hienfile = new System.Windows.Forms.LinkLabel();
            this.BTN_file = new System.Windows.Forms.Button();
            this.gunaGradientButton1 = new Guna.UI.WinForms.GunaGradientButton();
            this.TXB_noidung = new System.Windows.Forms.TextBox();
            this.TXB_tieude = new System.Windows.Forms.TextBox();
            this.LB_soantin = new System.Windows.Forms.Label();
            this.LB_tieude = new System.Windows.Forms.Label();
            this.MSCBB_thongbao = new Syncfusion.Windows.Forms.Tools.MultiSelectionComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CB_priority = new System.Windows.Forms.CheckBox();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            this.PN_hienthi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MSCBB_thongbao)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // LB_den
            // 
            resources.ApplyResources(this.LB_den, "LB_den");
            this.LB_den.ForeColor = System.Drawing.Color.White;
            this.LB_den.Name = "LB_den";
            // 
            // PN_hienthi
            // 
            this.PN_hienthi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.PN_hienthi.Controls.Add(this.LLB_hienfile);
            this.PN_hienthi.Controls.Add(this.BTN_file);
            this.PN_hienthi.Controls.Add(this.gunaGradientButton1);
            this.PN_hienthi.Controls.Add(this.TXB_noidung);
            resources.ApplyResources(this.PN_hienthi, "PN_hienthi");
            this.PN_hienthi.Name = "PN_hienthi";
            // 
            // LLB_hienfile
            // 
            resources.ApplyResources(this.LLB_hienfile, "LLB_hienfile");
            this.LLB_hienfile.LinkColor = System.Drawing.Color.White;
            this.LLB_hienfile.Name = "LLB_hienfile";
            this.LLB_hienfile.TabStop = true;
            // 
            // BTN_file
            // 
            resources.ApplyResources(this.BTN_file, "BTN_file");
            this.BTN_file.ForeColor = System.Drawing.Color.White;
            this.BTN_file.Name = "BTN_file";
            this.BTN_file.UseVisualStyleBackColor = true;
            this.BTN_file.Click += new System.EventHandler(this.BTN_file_Click);
            // 
            // gunaGradientButton1
            // 
            this.gunaGradientButton1.AnimationHoverSpeed = 0.5F;
            this.gunaGradientButton1.AnimationSpeed = 0.03F;
            this.gunaGradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaGradientButton1.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.gunaGradientButton1.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.gunaGradientButton1.BorderColor = System.Drawing.Color.White;
            this.gunaGradientButton1.BorderSize = 1;
            this.gunaGradientButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientButton1.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.gunaGradientButton1, "gunaGradientButton1");
            this.gunaGradientButton1.ForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.Image = null;
            this.gunaGradientButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaGradientButton1.Name = "gunaGradientButton1";
            this.gunaGradientButton1.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.gunaGradientButton1.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.gunaGradientButton1.OnHoverBorderColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverImage = null;
            this.gunaGradientButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.Radius = 5;
            this.gunaGradientButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton1.Click += new System.EventHandler(this.gunaGradientButton1_Click);
            // 
            // TXB_noidung
            // 
            this.TXB_noidung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.TXB_noidung.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.TXB_noidung, "TXB_noidung");
            this.TXB_noidung.ForeColor = System.Drawing.Color.White;
            this.TXB_noidung.Name = "TXB_noidung";
            // 
            // TXB_tieude
            // 
            this.TXB_tieude.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            resources.ApplyResources(this.TXB_tieude, "TXB_tieude");
            this.TXB_tieude.ForeColor = System.Drawing.Color.White;
            this.TXB_tieude.Name = "TXB_tieude";
            // 
            // LB_soantin
            // 
            resources.ApplyResources(this.LB_soantin, "LB_soantin");
            this.LB_soantin.ForeColor = System.Drawing.Color.White;
            this.LB_soantin.Name = "LB_soantin";
            // 
            // LB_tieude
            // 
            resources.ApplyResources(this.LB_tieude, "LB_tieude");
            this.LB_tieude.ForeColor = System.Drawing.Color.White;
            this.LB_tieude.Name = "LB_tieude";
            // 
            // MSCBB_thongbao
            // 
            this.MSCBB_thongbao.AutoSizeMode = Syncfusion.Windows.Forms.Tools.AutoSizeModes.None;
            this.MSCBB_thongbao.BeforeTouchSize = new System.Drawing.Size(579, 31);
            this.MSCBB_thongbao.ButtonStyle = Syncfusion.Windows.Forms.ButtonAppearance.Metro;
            this.MSCBB_thongbao.DataSource = ((object)(resources.GetObject("MSCBB_thongbao.DataSource")));
            this.MSCBB_thongbao.FlatBorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.MSCBB_thongbao, "MSCBB_thongbao");
            this.MSCBB_thongbao.MetroColor = System.Drawing.Color.White;
            this.MSCBB_thongbao.Name = "MSCBB_thongbao";
            this.MSCBB_thongbao.ShowCheckBox = true;
            this.MSCBB_thongbao.ShowGroups = true;
            this.MSCBB_thongbao.ThemeName = "Metro";
            this.MSCBB_thongbao.TickColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.MSCBB_thongbao.UseVisualStyle = true;
            this.MSCBB_thongbao.VisualItemBorderColor = System.Drawing.Color.DimGray;
            this.MSCBB_thongbao.VisualItemForeColor = System.Drawing.Color.Black;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // CB_priority
            // 
            resources.ApplyResources(this.CB_priority, "CB_priority");
            this.CB_priority.Name = "CB_priority";
            this.CB_priority.UseVisualStyleBackColor = true;
            // 
            // BTN_thoat
            // 
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.DimGray;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // SoanThongBao
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.CB_priority);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MSCBB_thongbao);
            this.Controls.Add(this.LB_tieude);
            this.Controls.Add(this.LB_soantin);
            this.Controls.Add(this.TXB_tieude);
            this.Controls.Add(this.LB_den);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.PN_hienthi);
            this.Controls.Add(this.BTN_thoat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SoanThongBao";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SoanThongBao_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SoanThongBao_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.SoanThongBao_MouseUp);
            this.PN_hienthi.ResumeLayout(false);
            this.PN_hienthi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MSCBB_thongbao)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label LB_den;
        private System.Windows.Forms.Panel PN_hienthi;
        private System.Windows.Forms.TextBox TXB_tieude;
        private System.Windows.Forms.TextBox TXB_noidung;
        private System.Windows.Forms.Label LB_soantin;
        private System.Windows.Forms.Label LB_tieude;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
        private Guna.UI.WinForms.GunaGradientButton gunaGradientButton1;
        public System.Windows.Forms.LinkLabel LLB_hienfile;
        private System.Windows.Forms.Button BTN_file;
        private Syncfusion.Windows.Forms.Tools.MultiSelectionComboBox MSCBB_thongbao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox CB_priority;
    }
}