﻿
namespace DangNhap
{
    partial class ThemCongViecNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThemCongViecNhanVien));
            this.PN_hienthithemcongviec = new System.Windows.Forms.Panel();
            this.LB_PhiDichVu = new System.Windows.Forms.Label();
            this.TXB_PhiDichVu = new System.Windows.Forms.TextBox();
            this.LB_Ghichu = new System.Windows.Forms.Label();
            this.TXB_ghiChu = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CB_thoihan = new System.Windows.Forms.CheckBox();
            this.CBB_QuyenTruyCap = new System.Windows.Forms.ComboBox();
            this.LLB_hienfile = new System.Windows.Forms.LinkLabel();
            this.TXB_MaCongViec = new System.Windows.Forms.TextBox();
            this.LB_MaCongViec = new System.Windows.Forms.Label();
            this.TXB_macanho = new System.Windows.Forms.TextBox();
            this.DTP_gio = new System.Windows.Forms.DateTimePicker();
            this.CBB_nhom = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CBB_phongban = new System.Windows.Forms.ComboBox();
            this.BTN_file = new System.Windows.Forms.Button();
            this.LB_quyentruycap = new System.Windows.Forms.Label();
            this.LB_maphongban = new System.Windows.Forms.Label();
            this.LB_noidung = new System.Windows.Forms.Label();
            this.BTN_huy = new Guna.UI.WinForms.GunaGradientButton();
            this.TXB_noidung = new System.Windows.Forms.TextBox();
            this.BTN_ok = new Guna.UI.WinForms.GunaGradientButton();
            this.LB_macanho = new System.Windows.Forms.Label();
            this.LB_thoihan = new System.Windows.Forms.Label();
            this.DTP_ngay = new System.Windows.Forms.DateTimePicker();
            this.CBB_manhanvien = new System.Windows.Forms.ComboBox();
            this.LB_manhanvien = new System.Windows.Forms.Label();
            this.LB_themcongviec = new System.Windows.Forms.Label();
            this.BTN_phongban = new System.Windows.Forms.Button();
            this.BTN_nhanvien = new System.Windows.Forms.Button();
            this.BTN_nhom = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            this.PN_hienthithemcongviec.SuspendLayout();
            this.SuspendLayout();
            // 
            // PN_hienthithemcongviec
            // 
            resources.ApplyResources(this.PN_hienthithemcongviec, "PN_hienthithemcongviec");
            this.PN_hienthithemcongviec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.PN_hienthithemcongviec.Controls.Add(this.LB_PhiDichVu);
            this.PN_hienthithemcongviec.Controls.Add(this.TXB_PhiDichVu);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_Ghichu);
            this.PN_hienthithemcongviec.Controls.Add(this.TXB_ghiChu);
            this.PN_hienthithemcongviec.Controls.Add(this.panel6);
            this.PN_hienthithemcongviec.Controls.Add(this.panel1);
            this.PN_hienthithemcongviec.Controls.Add(this.CB_thoihan);
            this.PN_hienthithemcongviec.Controls.Add(this.CBB_QuyenTruyCap);
            this.PN_hienthithemcongviec.Controls.Add(this.LLB_hienfile);
            this.PN_hienthithemcongviec.Controls.Add(this.TXB_MaCongViec);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_MaCongViec);
            this.PN_hienthithemcongviec.Controls.Add(this.TXB_macanho);
            this.PN_hienthithemcongviec.Controls.Add(this.DTP_gio);
            this.PN_hienthithemcongviec.Controls.Add(this.CBB_nhom);
            this.PN_hienthithemcongviec.Controls.Add(this.label1);
            this.PN_hienthithemcongviec.Controls.Add(this.CBB_phongban);
            this.PN_hienthithemcongviec.Controls.Add(this.BTN_file);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_quyentruycap);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_maphongban);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_noidung);
            this.PN_hienthithemcongviec.Controls.Add(this.BTN_huy);
            this.PN_hienthithemcongviec.Controls.Add(this.TXB_noidung);
            this.PN_hienthithemcongviec.Controls.Add(this.BTN_ok);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_macanho);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_thoihan);
            this.PN_hienthithemcongviec.Controls.Add(this.DTP_ngay);
            this.PN_hienthithemcongviec.Controls.Add(this.CBB_manhanvien);
            this.PN_hienthithemcongviec.Controls.Add(this.LB_manhanvien);
            this.PN_hienthithemcongviec.Name = "PN_hienthithemcongviec";
            // 
            // LB_PhiDichVu
            // 
            resources.ApplyResources(this.LB_PhiDichVu, "LB_PhiDichVu");
            this.LB_PhiDichVu.ForeColor = System.Drawing.Color.White;
            this.LB_PhiDichVu.Name = "LB_PhiDichVu";
            // 
            // TXB_PhiDichVu
            // 
            resources.ApplyResources(this.TXB_PhiDichVu, "TXB_PhiDichVu");
            this.TXB_PhiDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_PhiDichVu.ForeColor = System.Drawing.Color.White;
            this.TXB_PhiDichVu.Name = "TXB_PhiDichVu";
            // 
            // LB_Ghichu
            // 
            resources.ApplyResources(this.LB_Ghichu, "LB_Ghichu");
            this.LB_Ghichu.ForeColor = System.Drawing.Color.White;
            this.LB_Ghichu.Name = "LB_Ghichu";
            // 
            // TXB_ghiChu
            // 
            resources.ApplyResources(this.TXB_ghiChu, "TXB_ghiChu");
            this.TXB_ghiChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_ghiChu.ForeColor = System.Drawing.Color.White;
            this.TXB_ghiChu.Name = "TXB_ghiChu";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Name = "panel6";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Name = "panel1";
            // 
            // CB_thoihan
            // 
            resources.ApplyResources(this.CB_thoihan, "CB_thoihan");
            this.CB_thoihan.ForeColor = System.Drawing.Color.White;
            this.CB_thoihan.Name = "CB_thoihan";
            this.CB_thoihan.UseVisualStyleBackColor = true;
            this.CB_thoihan.CheckedChanged += new System.EventHandler(this.CB_thoihan_CheckedChanged);
            // 
            // CBB_QuyenTruyCap
            // 
            resources.ApplyResources(this.CBB_QuyenTruyCap, "CBB_QuyenTruyCap");
            this.CBB_QuyenTruyCap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_QuyenTruyCap.ForeColor = System.Drawing.Color.White;
            this.CBB_QuyenTruyCap.FormattingEnabled = true;
            this.CBB_QuyenTruyCap.Items.AddRange(new object[] {
            resources.GetString("CBB_QuyenTruyCap.Items"),
            resources.GetString("CBB_QuyenTruyCap.Items1"),
            resources.GetString("CBB_QuyenTruyCap.Items2")});
            this.CBB_QuyenTruyCap.Name = "CBB_QuyenTruyCap";
            // 
            // LLB_hienfile
            // 
            resources.ApplyResources(this.LLB_hienfile, "LLB_hienfile");
            this.LLB_hienfile.LinkColor = System.Drawing.Color.White;
            this.LLB_hienfile.Name = "LLB_hienfile";
            this.LLB_hienfile.TabStop = true;
            // 
            // TXB_MaCongViec
            // 
            resources.ApplyResources(this.TXB_MaCongViec, "TXB_MaCongViec");
            this.TXB_MaCongViec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_MaCongViec.ForeColor = System.Drawing.Color.White;
            this.TXB_MaCongViec.Name = "TXB_MaCongViec";
            // 
            // LB_MaCongViec
            // 
            resources.ApplyResources(this.LB_MaCongViec, "LB_MaCongViec");
            this.LB_MaCongViec.ForeColor = System.Drawing.Color.White;
            this.LB_MaCongViec.Name = "LB_MaCongViec";
            // 
            // TXB_macanho
            // 
            resources.ApplyResources(this.TXB_macanho, "TXB_macanho");
            this.TXB_macanho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_macanho.ForeColor = System.Drawing.Color.White;
            this.TXB_macanho.Name = "TXB_macanho";
            // 
            // DTP_gio
            // 
            resources.ApplyResources(this.DTP_gio, "DTP_gio");
            this.DTP_gio.CalendarMonthBackground = System.Drawing.Color.Black;
            this.DTP_gio.CalendarTitleBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.DTP_gio.CalendarTrailingForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.DTP_gio.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTP_gio.Name = "DTP_gio";
            // 
            // CBB_nhom
            // 
            resources.ApplyResources(this.CBB_nhom, "CBB_nhom");
            this.CBB_nhom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_nhom.ForeColor = System.Drawing.Color.White;
            this.CBB_nhom.FormattingEnabled = true;
            this.CBB_nhom.Name = "CBB_nhom";
            this.CBB_nhom.SelectedIndexChanged += new System.EventHandler(this.CBB_nhom_SelectedIndexChanged);
            this.CBB_nhom.SelectedValueChanged += new System.EventHandler(this.CBB_nhom_SelectedValueChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // CBB_phongban
            // 
            resources.ApplyResources(this.CBB_phongban, "CBB_phongban");
            this.CBB_phongban.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_phongban.ForeColor = System.Drawing.Color.White;
            this.CBB_phongban.FormattingEnabled = true;
            this.CBB_phongban.Name = "CBB_phongban";
            this.CBB_phongban.SelectedIndexChanged += new System.EventHandler(this.CBB_phongban_SelectedIndexChanged);
            this.CBB_phongban.SelectedValueChanged += new System.EventHandler(this.CBB_phongban_SelectedValueChanged);
            // 
            // BTN_file
            // 
            resources.ApplyResources(this.BTN_file, "BTN_file");
            this.BTN_file.ForeColor = System.Drawing.Color.White;
            this.BTN_file.Name = "BTN_file";
            this.BTN_file.UseVisualStyleBackColor = true;
            this.BTN_file.Click += new System.EventHandler(this.BTN_file_Click);
            // 
            // LB_quyentruycap
            // 
            resources.ApplyResources(this.LB_quyentruycap, "LB_quyentruycap");
            this.LB_quyentruycap.ForeColor = System.Drawing.Color.White;
            this.LB_quyentruycap.Name = "LB_quyentruycap";
            // 
            // LB_maphongban
            // 
            resources.ApplyResources(this.LB_maphongban, "LB_maphongban");
            this.LB_maphongban.ForeColor = System.Drawing.Color.White;
            this.LB_maphongban.Name = "LB_maphongban";
            // 
            // LB_noidung
            // 
            resources.ApplyResources(this.LB_noidung, "LB_noidung");
            this.LB_noidung.ForeColor = System.Drawing.Color.White;
            this.LB_noidung.Name = "LB_noidung";
            // 
            // BTN_huy
            // 
            resources.ApplyResources(this.BTN_huy, "BTN_huy");
            this.BTN_huy.Animated = true;
            this.BTN_huy.AnimationHoverSpeed = 0.5F;
            this.BTN_huy.AnimationSpeed = 0.03F;
            this.BTN_huy.BackColor = System.Drawing.Color.Transparent;
            this.BTN_huy.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(218)))), ((int)(((byte)(215)))));
            this.BTN_huy.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(218)))), ((int)(((byte)(215)))));
            this.BTN_huy.BorderColor = System.Drawing.Color.Red;
            this.BTN_huy.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_huy.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_huy.ForeColor = System.Drawing.Color.Black;
            this.BTN_huy.Image = null;
            this.BTN_huy.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_huy.Name = "BTN_huy";
            this.BTN_huy.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_huy.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_huy.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_huy.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_huy.OnHoverImage = null;
            this.BTN_huy.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_huy.Radius = 5;
            this.BTN_huy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_huy.Click += new System.EventHandler(this.BTN_huy_Click);
            // 
            // TXB_noidung
            // 
            resources.ApplyResources(this.TXB_noidung, "TXB_noidung");
            this.TXB_noidung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_noidung.ForeColor = System.Drawing.Color.White;
            this.TXB_noidung.Name = "TXB_noidung";
            // 
            // BTN_ok
            // 
            resources.ApplyResources(this.BTN_ok, "BTN_ok");
            this.BTN_ok.Animated = true;
            this.BTN_ok.AnimationHoverSpeed = 0.5F;
            this.BTN_ok.AnimationSpeed = 0.03F;
            this.BTN_ok.BackColor = System.Drawing.Color.Transparent;
            this.BTN_ok.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_ok.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_ok.BorderColor = System.Drawing.Color.Black;
            this.BTN_ok.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_ok.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_ok.ForeColor = System.Drawing.Color.White;
            this.BTN_ok.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_ok.Image = null;
            this.BTN_ok.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_ok.Name = "BTN_ok";
            this.BTN_ok.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_ok.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_ok.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_ok.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_ok.OnHoverImage = null;
            this.BTN_ok.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_ok.Radius = 5;
            this.BTN_ok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_ok.Click += new System.EventHandler(this.BTN_ok_Click);
            // 
            // LB_macanho
            // 
            resources.ApplyResources(this.LB_macanho, "LB_macanho");
            this.LB_macanho.ForeColor = System.Drawing.Color.White;
            this.LB_macanho.Name = "LB_macanho";
            // 
            // LB_thoihan
            // 
            resources.ApplyResources(this.LB_thoihan, "LB_thoihan");
            this.LB_thoihan.ForeColor = System.Drawing.Color.White;
            this.LB_thoihan.Name = "LB_thoihan";
            // 
            // DTP_ngay
            // 
            resources.ApplyResources(this.DTP_ngay, "DTP_ngay");
            this.DTP_ngay.CalendarMonthBackground = System.Drawing.Color.Black;
            this.DTP_ngay.CalendarTitleBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.DTP_ngay.CalendarTrailingForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.DTP_ngay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DTP_ngay.Name = "DTP_ngay";
            // 
            // CBB_manhanvien
            // 
            resources.ApplyResources(this.CBB_manhanvien, "CBB_manhanvien");
            this.CBB_manhanvien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_manhanvien.ForeColor = System.Drawing.Color.White;
            this.CBB_manhanvien.FormattingEnabled = true;
            this.CBB_manhanvien.Name = "CBB_manhanvien";
            this.CBB_manhanvien.SelectedIndexChanged += new System.EventHandler(this.CBB_manhanvien_SelectedIndexChanged);
            // 
            // LB_manhanvien
            // 
            resources.ApplyResources(this.LB_manhanvien, "LB_manhanvien");
            this.LB_manhanvien.ForeColor = System.Drawing.Color.White;
            this.LB_manhanvien.Name = "LB_manhanvien";
            // 
            // LB_themcongviec
            // 
            resources.ApplyResources(this.LB_themcongviec, "LB_themcongviec");
            this.LB_themcongviec.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LB_themcongviec.Name = "LB_themcongviec";
            // 
            // BTN_phongban
            // 
            resources.ApplyResources(this.BTN_phongban, "BTN_phongban");
            this.BTN_phongban.BackColor = System.Drawing.Color.Transparent;
            this.BTN_phongban.FlatAppearance.BorderSize = 0;
            this.BTN_phongban.ForeColor = System.Drawing.Color.White;
            this.BTN_phongban.Name = "BTN_phongban";
            this.BTN_phongban.UseVisualStyleBackColor = false;
            this.BTN_phongban.Click += new System.EventHandler(this.BTN_phongban_Click);
            // 
            // BTN_nhanvien
            // 
            resources.ApplyResources(this.BTN_nhanvien, "BTN_nhanvien");
            this.BTN_nhanvien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(55)))));
            this.BTN_nhanvien.FlatAppearance.BorderSize = 0;
            this.BTN_nhanvien.ForeColor = System.Drawing.Color.White;
            this.BTN_nhanvien.Name = "BTN_nhanvien";
            this.BTN_nhanvien.UseVisualStyleBackColor = false;
            this.BTN_nhanvien.Click += new System.EventHandler(this.BTN_nhanvien_Click);
            // 
            // BTN_nhom
            // 
            resources.ApplyResources(this.BTN_nhom, "BTN_nhom");
            this.BTN_nhom.BackColor = System.Drawing.Color.Transparent;
            this.BTN_nhom.FlatAppearance.BorderSize = 0;
            this.BTN_nhom.ForeColor = System.Drawing.Color.White;
            this.BTN_nhom.Name = "BTN_nhom";
            this.BTN_nhom.UseVisualStyleBackColor = false;
            this.BTN_nhom.Click += new System.EventHandler(this.BTN_nhom_Click);
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Name = "panel2";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.Name = "panel3";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel4.Name = "panel4";
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel5.Name = "panel5";
            // 
            // BTN_thoat
            // 
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // ThemCongViecNhanVien
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.LB_themcongviec);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.PN_hienthithemcongviec);
            this.Controls.Add(this.BTN_phongban);
            this.Controls.Add(this.BTN_nhanvien);
            this.Controls.Add(this.BTN_nhom);
            this.Controls.Add(this.BTN_thoat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ThemCongViecNhanVien";
            this.Load += new System.EventHandler(this.ThemCongViecNhanVien_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ThemCongViecNhanVien_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ThemCongViecNhanVien_MousMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ThemCongViecNhanVien_MouseUp);
            this.PN_hienthithemcongviec.ResumeLayout(false);
            this.PN_hienthithemcongviec.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PN_hienthithemcongviec;
        private System.Windows.Forms.Label LB_themcongviec;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
        private System.Windows.Forms.Button BTN_phongban;
        private System.Windows.Forms.Button BTN_nhanvien;
        private System.Windows.Forms.Button BTN_nhom;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DateTimePicker DTP_gio;
        private System.Windows.Forms.ComboBox CBB_nhom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBB_phongban;
        private System.Windows.Forms.Button BTN_file;
        private System.Windows.Forms.Label LB_quyentruycap;
        private System.Windows.Forms.Label LB_maphongban;
        private System.Windows.Forms.Label LB_noidung;
        private Guna.UI.WinForms.GunaGradientButton BTN_huy;
        private System.Windows.Forms.TextBox TXB_noidung;
        private Guna.UI.WinForms.GunaGradientButton BTN_ok;
        private System.Windows.Forms.Label LB_macanho;
        private System.Windows.Forms.Label LB_thoihan;
        private System.Windows.Forms.DateTimePicker DTP_ngay;
        private System.Windows.Forms.Label LB_manhanvien;
        private System.Windows.Forms.TextBox TXB_macanho;
        private System.Windows.Forms.ComboBox CBB_manhanvien;
        private System.Windows.Forms.TextBox TXB_MaCongViec;
        private System.Windows.Forms.Label LB_MaCongViec;
        private System.Windows.Forms.ComboBox CBB_QuyenTruyCap;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.LinkLabel LLB_hienfile;
        private System.Windows.Forms.Label LB_Ghichu;
        public System.Windows.Forms.TextBox TXB_ghiChu;
        private System.Windows.Forms.CheckBox CB_thoihan;
        private System.Windows.Forms.Label LB_PhiDichVu;
        public System.Windows.Forms.TextBox TXB_PhiDichVu;
    }
}