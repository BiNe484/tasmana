﻿
namespace DangNhap
{
    partial class ChiTietCongViec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChiTietCongViec));
            this.LB_quyentruycap = new System.Windows.Forms.Label();
            this.LB_manhanvien = new System.Windows.Forms.Label();
            this.LB_noidung = new System.Windows.Forms.Label();
            this.TXB_noidung = new System.Windows.Forms.TextBox();
            this.BTN_luu = new Guna.UI.WinForms.GunaGradientButton();
            this.LB_macanho = new System.Windows.Forms.Label();
            this.LB_thoihan = new System.Windows.Forms.Label();
            this.DTP_ngay = new System.Windows.Forms.DateTimePicker();
            this.LB_themcongviec = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LB_maphongban = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CBB_TrangThai = new System.Windows.Forms.ComboBox();
            this.LB_macongviec = new System.Windows.Forms.Label();
            this.gunaGradientButton1 = new Guna.UI.WinForms.GunaGradientButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.DTP_gio = new System.Windows.Forms.DateTimePicker();
            this.TXB_macanho = new System.Windows.Forms.TextBox();
            this.TXB_MaNV = new System.Windows.Forms.TextBox();
            this.TXB_Nhom = new System.Windows.Forms.TextBox();
            this.TXB_PhongBan = new System.Windows.Forms.TextBox();
            this.TXB_MaCV = new System.Windows.Forms.TextBox();
            this.LB_Ghichu = new System.Windows.Forms.Label();
            this.TXB_GhiChu = new System.Windows.Forms.TextBox();
            this.LLB_chitietfile = new System.Windows.Forms.LinkLabel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.CBB_quyentruycap = new System.Windows.Forms.ComboBox();
            this.CB_thoihan = new System.Windows.Forms.CheckBox();
            this.PN_nen = new System.Windows.Forms.Panel();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            this.LB_PhiDichVu = new System.Windows.Forms.Label();
            this.TXB_PhiDichVu = new System.Windows.Forms.TextBox();
            this.BTN_file = new System.Windows.Forms.Button();
            this.PN_nen.SuspendLayout();
            this.SuspendLayout();
            // 
            // LB_quyentruycap
            // 
            resources.ApplyResources(this.LB_quyentruycap, "LB_quyentruycap");
            this.LB_quyentruycap.ForeColor = System.Drawing.Color.White;
            this.LB_quyentruycap.Name = "LB_quyentruycap";
            // 
            // LB_manhanvien
            // 
            resources.ApplyResources(this.LB_manhanvien, "LB_manhanvien");
            this.LB_manhanvien.ForeColor = System.Drawing.Color.White;
            this.LB_manhanvien.Name = "LB_manhanvien";
            // 
            // LB_noidung
            // 
            resources.ApplyResources(this.LB_noidung, "LB_noidung");
            this.LB_noidung.ForeColor = System.Drawing.Color.White;
            this.LB_noidung.Name = "LB_noidung";
            // 
            // TXB_noidung
            // 
            resources.ApplyResources(this.TXB_noidung, "TXB_noidung");
            this.TXB_noidung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_noidung.ForeColor = System.Drawing.Color.White;
            this.TXB_noidung.Name = "TXB_noidung";
            // 
            // BTN_luu
            // 
            resources.ApplyResources(this.BTN_luu, "BTN_luu");
            this.BTN_luu.Animated = true;
            this.BTN_luu.AnimationHoverSpeed = 0.5F;
            this.BTN_luu.AnimationSpeed = 0.03F;
            this.BTN_luu.BackColor = System.Drawing.Color.Transparent;
            this.BTN_luu.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_luu.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.BorderColor = System.Drawing.Color.Black;
            this.BTN_luu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_luu.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_luu.ForeColor = System.Drawing.Color.White;
            this.BTN_luu.Image = null;
            this.BTN_luu.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_luu.Name = "BTN_luu";
            this.BTN_luu.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverImage = null;
            this.BTN_luu.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_luu.Radius = 5;
            this.BTN_luu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_luu.Click += new System.EventHandler(this.BTN_luu_Click);
            // 
            // LB_macanho
            // 
            resources.ApplyResources(this.LB_macanho, "LB_macanho");
            this.LB_macanho.ForeColor = System.Drawing.Color.White;
            this.LB_macanho.Name = "LB_macanho";
            // 
            // LB_thoihan
            // 
            resources.ApplyResources(this.LB_thoihan, "LB_thoihan");
            this.LB_thoihan.ForeColor = System.Drawing.Color.White;
            this.LB_thoihan.Name = "LB_thoihan";
            // 
            // DTP_ngay
            // 
            resources.ApplyResources(this.DTP_ngay, "DTP_ngay");
            this.DTP_ngay.CalendarMonthBackground = System.Drawing.Color.Black;
            this.DTP_ngay.CalendarTitleBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.DTP_ngay.CalendarTrailingForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.DTP_ngay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DTP_ngay.Name = "DTP_ngay";
            // 
            // LB_themcongviec
            // 
            resources.ApplyResources(this.LB_themcongviec, "LB_themcongviec");
            this.LB_themcongviec.BackColor = System.Drawing.Color.Transparent;
            this.LB_themcongviec.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LB_themcongviec.Name = "LB_themcongviec";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // LB_maphongban
            // 
            resources.ApplyResources(this.LB_maphongban, "LB_maphongban");
            this.LB_maphongban.ForeColor = System.Drawing.Color.White;
            this.LB_maphongban.Name = "LB_maphongban";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // CBB_TrangThai
            // 
            resources.ApplyResources(this.CBB_TrangThai, "CBB_TrangThai");
            this.CBB_TrangThai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_TrangThai.ForeColor = System.Drawing.Color.White;
            this.CBB_TrangThai.FormattingEnabled = true;
            this.CBB_TrangThai.Items.AddRange(new object[] {
            resources.GetString("CBB_TrangThai.Items"),
            resources.GetString("CBB_TrangThai.Items1"),
            resources.GetString("CBB_TrangThai.Items2")});
            this.CBB_TrangThai.Name = "CBB_TrangThai";
            // 
            // LB_macongviec
            // 
            resources.ApplyResources(this.LB_macongviec, "LB_macongviec");
            this.LB_macongviec.ForeColor = System.Drawing.Color.White;
            this.LB_macongviec.Name = "LB_macongviec";
            // 
            // gunaGradientButton1
            // 
            resources.ApplyResources(this.gunaGradientButton1, "gunaGradientButton1");
            this.gunaGradientButton1.Animated = true;
            this.gunaGradientButton1.AnimationHoverSpeed = 1F;
            this.gunaGradientButton1.AnimationSpeed = 0.03F;
            this.gunaGradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaGradientButton1.BaseColor1 = System.Drawing.Color.Transparent;
            this.gunaGradientButton1.BaseColor2 = System.Drawing.Color.Transparent;
            this.gunaGradientButton1.BorderColor = System.Drawing.Color.Red;
            this.gunaGradientButton1.BorderSize = 1;
            this.gunaGradientButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientButton1.ForeColor = System.Drawing.Color.Red;
            this.gunaGradientButton1.Image = null;
            this.gunaGradientButton1.ImageSize = new System.Drawing.Size(10, 10);
            this.gunaGradientButton1.Name = "gunaGradientButton1";
            this.gunaGradientButton1.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.gunaGradientButton1.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.gunaGradientButton1.OnHoverBorderColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverImage = null;
            this.gunaGradientButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.Radius = 5;
            this.gunaGradientButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton1.Click += new System.EventHandler(this.gunaGradientButton1_Click);
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Name = "panel1";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Name = "panel2";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.Name = "panel3";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel4.Name = "panel4";
            // 
            // DTP_gio
            // 
            resources.ApplyResources(this.DTP_gio, "DTP_gio");
            this.DTP_gio.CalendarMonthBackground = System.Drawing.Color.Black;
            this.DTP_gio.CalendarTitleBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.DTP_gio.CalendarTrailingForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.DTP_gio.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTP_gio.Name = "DTP_gio";
            // 
            // TXB_macanho
            // 
            resources.ApplyResources(this.TXB_macanho, "TXB_macanho");
            this.TXB_macanho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_macanho.ForeColor = System.Drawing.Color.White;
            this.TXB_macanho.Name = "TXB_macanho";
            // 
            // TXB_MaNV
            // 
            resources.ApplyResources(this.TXB_MaNV, "TXB_MaNV");
            this.TXB_MaNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_MaNV.ForeColor = System.Drawing.Color.White;
            this.TXB_MaNV.Name = "TXB_MaNV";
            // 
            // TXB_Nhom
            // 
            resources.ApplyResources(this.TXB_Nhom, "TXB_Nhom");
            this.TXB_Nhom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_Nhom.ForeColor = System.Drawing.Color.White;
            this.TXB_Nhom.Name = "TXB_Nhom";
            // 
            // TXB_PhongBan
            // 
            resources.ApplyResources(this.TXB_PhongBan, "TXB_PhongBan");
            this.TXB_PhongBan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_PhongBan.ForeColor = System.Drawing.Color.White;
            this.TXB_PhongBan.Name = "TXB_PhongBan";
            // 
            // TXB_MaCV
            // 
            resources.ApplyResources(this.TXB_MaCV, "TXB_MaCV");
            this.TXB_MaCV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_MaCV.ForeColor = System.Drawing.Color.White;
            this.TXB_MaCV.Name = "TXB_MaCV";
            // 
            // LB_Ghichu
            // 
            resources.ApplyResources(this.LB_Ghichu, "LB_Ghichu");
            this.LB_Ghichu.ForeColor = System.Drawing.Color.White;
            this.LB_Ghichu.Name = "LB_Ghichu";
            // 
            // TXB_GhiChu
            // 
            resources.ApplyResources(this.TXB_GhiChu, "TXB_GhiChu");
            this.TXB_GhiChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_GhiChu.ForeColor = System.Drawing.Color.White;
            this.TXB_GhiChu.Name = "TXB_GhiChu";
            // 
            // LLB_chitietfile
            // 
            resources.ApplyResources(this.LLB_chitietfile, "LLB_chitietfile");
            this.LLB_chitietfile.LinkColor = System.Drawing.Color.White;
            this.LLB_chitietfile.Name = "LLB_chitietfile";
            this.LLB_chitietfile.TabStop = true;
            this.LLB_chitietfile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LLB_chitietfile_LinkClicked);
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Name = "panel6";
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.Silver;
            this.panel5.Name = "panel5";
            // 
            // CBB_quyentruycap
            // 
            resources.ApplyResources(this.CBB_quyentruycap, "CBB_quyentruycap");
            this.CBB_quyentruycap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_quyentruycap.ForeColor = System.Drawing.Color.White;
            this.CBB_quyentruycap.FormattingEnabled = true;
            this.CBB_quyentruycap.Items.AddRange(new object[] {
            resources.GetString("CBB_quyentruycap.Items"),
            resources.GetString("CBB_quyentruycap.Items1"),
            resources.GetString("CBB_quyentruycap.Items2")});
            this.CBB_quyentruycap.Name = "CBB_quyentruycap";
            // 
            // CB_thoihan
            // 
            resources.ApplyResources(this.CB_thoihan, "CB_thoihan");
            this.CB_thoihan.ForeColor = System.Drawing.Color.White;
            this.CB_thoihan.Name = "CB_thoihan";
            this.CB_thoihan.UseVisualStyleBackColor = true;
            this.CB_thoihan.CheckedChanged += new System.EventHandler(this.CB_thoihan_CheckedChanged);
            // 
            // PN_nen
            // 
            resources.ApplyResources(this.PN_nen, "PN_nen");
            this.PN_nen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.PN_nen.Controls.Add(this.BTN_thoat);
            this.PN_nen.Controls.Add(this.LB_themcongviec);
            this.PN_nen.Name = "PN_nen";
            this.PN_nen.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PN_nen_MouseDown);
            this.PN_nen.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PN_nen_MouseMove);
            this.PN_nen.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PN_nen_MouseUp);
            // 
            // BTN_thoat
            // 
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.DimGray;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // LB_PhiDichVu
            // 
            resources.ApplyResources(this.LB_PhiDichVu, "LB_PhiDichVu");
            this.LB_PhiDichVu.ForeColor = System.Drawing.Color.White;
            this.LB_PhiDichVu.Name = "LB_PhiDichVu";
            // 
            // TXB_PhiDichVu
            // 
            resources.ApplyResources(this.TXB_PhiDichVu, "TXB_PhiDichVu");
            this.TXB_PhiDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_PhiDichVu.ForeColor = System.Drawing.Color.White;
            this.TXB_PhiDichVu.Name = "TXB_PhiDichVu";
            // 
            // BTN_file
            // 
            resources.ApplyResources(this.BTN_file, "BTN_file");
            this.BTN_file.ForeColor = System.Drawing.Color.White;
            this.BTN_file.Name = "BTN_file";
            this.BTN_file.UseVisualStyleBackColor = true;
            // 
            // ChiTietCongViec
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.Controls.Add(this.LB_PhiDichVu);
            this.Controls.Add(this.TXB_PhiDichVu);
            this.Controls.Add(this.CB_thoihan);
            this.Controls.Add(this.CBB_quyentruycap);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.LLB_chitietfile);
            this.Controls.Add(this.TXB_GhiChu);
            this.Controls.Add(this.LB_Ghichu);
            this.Controls.Add(this.TXB_MaCV);
            this.Controls.Add(this.TXB_PhongBan);
            this.Controls.Add(this.TXB_Nhom);
            this.Controls.Add(this.TXB_MaNV);
            this.Controls.Add(this.TXB_macanho);
            this.Controls.Add(this.DTP_gio);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gunaGradientButton1);
            this.Controls.Add(this.LB_macongviec);
            this.Controls.Add(this.CBB_TrangThai);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LB_maphongban);
            this.Controls.Add(this.BTN_file);
            this.Controls.Add(this.LB_quyentruycap);
            this.Controls.Add(this.LB_manhanvien);
            this.Controls.Add(this.LB_noidung);
            this.Controls.Add(this.TXB_noidung);
            this.Controls.Add(this.BTN_luu);
            this.Controls.Add(this.LB_macanho);
            this.Controls.Add(this.LB_thoihan);
            this.Controls.Add(this.DTP_ngay);
            this.Controls.Add(this.PN_nen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChiTietCongViec";
            this.PN_nen.ResumeLayout(false);
            this.PN_nen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BTN_file;
        private System.Windows.Forms.Label LB_quyentruycap;
        private System.Windows.Forms.Label LB_manhanvien;
        private System.Windows.Forms.Label LB_noidung;
        private Guna.UI.WinForms.GunaGradientButton BTN_luu;
        private System.Windows.Forms.Label LB_macanho;
        private System.Windows.Forms.Label LB_thoihan;
        private System.Windows.Forms.Label LB_themcongviec;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LB_maphongban;
        private System.Windows.Forms.Label label2;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
        private System.Windows.Forms.Label LB_macongviec;
        private Guna.UI.WinForms.GunaGradientButton gunaGradientButton1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.TextBox TXB_MaNV;
        public System.Windows.Forms.TextBox TXB_Nhom;
        public System.Windows.Forms.TextBox TXB_PhongBan;
        public System.Windows.Forms.TextBox TXB_noidung;
        public System.Windows.Forms.DateTimePicker DTP_ngay;
        public System.Windows.Forms.ComboBox CBB_TrangThai;
        public System.Windows.Forms.DateTimePicker DTP_gio;
        public System.Windows.Forms.TextBox TXB_macanho;
        public System.Windows.Forms.TextBox TXB_MaCV;
        private System.Windows.Forms.Label LB_Ghichu;
        public System.Windows.Forms.TextBox TXB_GhiChu;
        public System.Windows.Forms.LinkLabel LLB_chitietfile;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.ComboBox CBB_quyentruycap;
        public System.Windows.Forms.CheckBox CB_thoihan;
        private System.Windows.Forms.Panel PN_nen;
        private System.Windows.Forms.Label LB_PhiDichVu;
        public System.Windows.Forms.TextBox TXB_PhiDichVu;
    }
}