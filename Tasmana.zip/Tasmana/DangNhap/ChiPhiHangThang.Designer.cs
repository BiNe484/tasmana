﻿namespace DangNhap
{
    partial class ChiPhiHangThang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChiPhiHangThang));
            this.GGC_BillHangThang = new Syncfusion.Windows.Forms.Grid.Grouping.GridGroupingControl();
            this.BTN_ThemBill = new Guna.UI.WinForms.GunaGradientButton();
            this.LB_BillHangThang = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            ((System.ComponentModel.ISupportInitialize)(this.GGC_BillHangThang)).BeginInit();
            this.SuspendLayout();
            // 
            // GGC_BillHangThang
            // 
            this.GGC_BillHangThang.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(215)))));
            resources.ApplyResources(this.GGC_BillHangThang, "GGC_BillHangThang");
            this.GGC_BillHangThang.BackColor = System.Drawing.SystemColors.Window;
            this.GGC_BillHangThang.Name = "GGC_BillHangThang";
            this.GGC_BillHangThang.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus;
            this.GGC_BillHangThang.UseRightToLeftCompatibleTextBox = true;
            this.GGC_BillHangThang.VersionInfo = "25.1462.39";
            this.GGC_BillHangThang.TableControlCellDoubleClick += new Syncfusion.Windows.Forms.Grid.Grouping.GridTableControlCellClickEventHandler(this.GGC_BillHangThang_TableControlCellDoubleClick);
            // 
            // BTN_ThemBill
            // 
            resources.ApplyResources(this.BTN_ThemBill, "BTN_ThemBill");
            this.BTN_ThemBill.Animated = true;
            this.BTN_ThemBill.AnimationHoverSpeed = 0.3F;
            this.BTN_ThemBill.AnimationSpeed = 0.03F;
            this.BTN_ThemBill.BackColor = System.Drawing.Color.Transparent;
            this.BTN_ThemBill.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_ThemBill.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_ThemBill.BorderColor = System.Drawing.Color.White;
            this.BTN_ThemBill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_ThemBill.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_ThemBill.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_ThemBill.ForeColor = System.Drawing.Color.White;
            this.BTN_ThemBill.Image = null;
            this.BTN_ThemBill.ImageSize = new System.Drawing.Size(15, 15);
            this.BTN_ThemBill.Name = "BTN_ThemBill";
            this.BTN_ThemBill.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(40)))), ((int)(((byte)(184)))));
            this.BTN_ThemBill.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(40)))), ((int)(((byte)(184)))));
            this.BTN_ThemBill.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_ThemBill.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_ThemBill.OnHoverImage = null;
            this.BTN_ThemBill.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_ThemBill.Radius = 5;
            this.BTN_ThemBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_ThemBill.Click += new System.EventHandler(this.BTN_ThemBill_Click);
            // 
            // LB_BillHangThang
            // 
            resources.ApplyResources(this.LB_BillHangThang, "LB_BillHangThang");
            this.LB_BillHangThang.BackColor = System.Drawing.Color.Transparent;
            this.LB_BillHangThang.ForeColor = System.Drawing.Color.White;
            this.LB_BillHangThang.Name = "LB_BillHangThang";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // BTN_thoat
            // 
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // ChiPhiHangThang
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.BTN_thoat);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.LB_BillHangThang);
            this.Controls.Add(this.BTN_ThemBill);
            this.Controls.Add(this.GGC_BillHangThang);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChiPhiHangThang";
            this.Load += new System.EventHandler(this.ChiPhiHangThang_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HoaDon_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HoaDon_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.HoaDon_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.GGC_BillHangThang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Syncfusion.Windows.Forms.Grid.Grouping.GridGroupingControl GGC_BillHangThang;
        private Guna.UI.WinForms.GunaGradientButton BTN_ThemBill;
        private System.Windows.Forms.Label LB_BillHangThang;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
        private System.Windows.Forms.Panel panel5;
    }
}