﻿
namespace DangNhap
{
    partial class NhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NhanVien));
            this.BTN_themnhanvien = new Guna.UI.WinForms.GunaGradientButton();
            this.GGC_danhsachnv = new Syncfusion.Windows.Forms.Grid.Grouping.GridGroupingControl();
            this.BTN_themnhom = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_PhongBan = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_in = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_PDF = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_excel = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_ThemQuanLy = new Guna.UI.WinForms.GunaGradientButton();
            ((System.ComponentModel.ISupportInitialize)(this.GGC_danhsachnv)).BeginInit();
            this.SuspendLayout();
            // 
            // BTN_themnhanvien
            // 
            resources.ApplyResources(this.BTN_themnhanvien, "BTN_themnhanvien");
            this.BTN_themnhanvien.Animated = true;
            this.BTN_themnhanvien.AnimationHoverSpeed = 0.3F;
            this.BTN_themnhanvien.AnimationSpeed = 0.03F;
            this.BTN_themnhanvien.BackColor = System.Drawing.Color.Transparent;
            this.BTN_themnhanvien.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(156)))), ((int)(((byte)(46)))));
            this.BTN_themnhanvien.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(156)))), ((int)(((byte)(46)))));
            this.BTN_themnhanvien.BorderColor = System.Drawing.Color.White;
            this.BTN_themnhanvien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_themnhanvien.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_themnhanvien.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_themnhanvien.ForeColor = System.Drawing.Color.White;
            this.BTN_themnhanvien.Image = null;
            this.BTN_themnhanvien.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_themnhanvien.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_themnhanvien.Name = "BTN_themnhanvien";
            this.BTN_themnhanvien.OnHoverBaseColor1 = System.Drawing.Color.ForestGreen;
            this.BTN_themnhanvien.OnHoverBaseColor2 = System.Drawing.Color.ForestGreen;
            this.BTN_themnhanvien.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_themnhanvien.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_themnhanvien.OnHoverImage = null;
            this.BTN_themnhanvien.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_themnhanvien.Radius = 5;
            this.BTN_themnhanvien.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_themnhanvien.Click += new System.EventHandler(this.BTN_themnhanvien_Click);
            // 
            // GGC_danhsachnv
            // 
            this.GGC_danhsachnv.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(215)))));
            resources.ApplyResources(this.GGC_danhsachnv, "GGC_danhsachnv");
            this.GGC_danhsachnv.BackColor = System.Drawing.SystemColors.Window;
            this.GGC_danhsachnv.Name = "GGC_danhsachnv";
            this.GGC_danhsachnv.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus;
            this.GGC_danhsachnv.UseRightToLeftCompatibleTextBox = true;
            this.GGC_danhsachnv.VersionInfo = "25.1462.39";
            this.GGC_danhsachnv.TableControlCellDoubleClick += new Syncfusion.Windows.Forms.Grid.Grouping.GridTableControlCellClickEventHandler(this.GGC_danhsachnv_TableControlCellDoubleClick);
            // 
            // BTN_themnhom
            // 
            resources.ApplyResources(this.BTN_themnhom, "BTN_themnhom");
            this.BTN_themnhom.Animated = true;
            this.BTN_themnhom.AnimationHoverSpeed = 0.3F;
            this.BTN_themnhom.AnimationSpeed = 0.03F;
            this.BTN_themnhom.BackColor = System.Drawing.Color.Transparent;
            this.BTN_themnhom.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(196)))), ((int)(((byte)(170)))));
            this.BTN_themnhom.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(196)))), ((int)(((byte)(170)))));
            this.BTN_themnhom.BorderColor = System.Drawing.Color.Black;
            this.BTN_themnhom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_themnhom.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_themnhom.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_themnhom.ForeColor = System.Drawing.Color.White;
            this.BTN_themnhom.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_themnhom.Image = null;
            this.BTN_themnhom.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_themnhom.Name = "BTN_themnhom";
            this.BTN_themnhom.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(100)))), ((int)(((byte)(170)))));
            this.BTN_themnhom.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(100)))), ((int)(((byte)(170)))));
            this.BTN_themnhom.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_themnhom.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_themnhom.OnHoverImage = null;
            this.BTN_themnhom.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_themnhom.Radius = 5;
            this.BTN_themnhom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_themnhom.Click += new System.EventHandler(this.BTN_themnhom_Click);
            // 
            // BTN_PhongBan
            // 
            resources.ApplyResources(this.BTN_PhongBan, "BTN_PhongBan");
            this.BTN_PhongBan.Animated = true;
            this.BTN_PhongBan.AnimationHoverSpeed = 0.3F;
            this.BTN_PhongBan.AnimationSpeed = 0.03F;
            this.BTN_PhongBan.BackColor = System.Drawing.Color.Transparent;
            this.BTN_PhongBan.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_PhongBan.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_PhongBan.BorderColor = System.Drawing.Color.Black;
            this.BTN_PhongBan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_PhongBan.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_PhongBan.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_PhongBan.ForeColor = System.Drawing.Color.White;
            this.BTN_PhongBan.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_PhongBan.Image = null;
            this.BTN_PhongBan.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_PhongBan.Name = "BTN_PhongBan";
            this.BTN_PhongBan.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(40)))), ((int)(((byte)(184)))));
            this.BTN_PhongBan.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(40)))), ((int)(((byte)(184)))));
            this.BTN_PhongBan.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_PhongBan.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_PhongBan.OnHoverImage = null;
            this.BTN_PhongBan.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_PhongBan.Radius = 5;
            this.BTN_PhongBan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_PhongBan.Click += new System.EventHandler(this.BTN_PhongBan_Click);
            // 
            // BTN_in
            // 
            resources.ApplyResources(this.BTN_in, "BTN_in");
            this.BTN_in.AnimationHoverSpeed = 0.07F;
            this.BTN_in.AnimationSpeed = 0.03F;
            this.BTN_in.BaseColor1 = System.Drawing.Color.Silver;
            this.BTN_in.BaseColor2 = System.Drawing.Color.DimGray;
            this.BTN_in.BorderColor = System.Drawing.Color.White;
            this.BTN_in.BorderSize = 1;
            this.BTN_in.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_in.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_in.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_in.ForeColor = System.Drawing.Color.White;
            this.BTN_in.Image = ((System.Drawing.Image)(resources.GetObject("BTN_in.Image")));
            this.BTN_in.ImageSize = new System.Drawing.Size(15, 15);
            this.BTN_in.Name = "BTN_in";
            this.BTN_in.OnHoverBaseColor1 = System.Drawing.Color.DimGray;
            this.BTN_in.OnHoverBaseColor2 = System.Drawing.Color.DimGray;
            this.BTN_in.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_in.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_in.OnHoverImage = null;
            this.BTN_in.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_in.TextOffsetX = 3;
            this.BTN_in.Click += new System.EventHandler(this.BTN_in_Click);
            // 
            // BTN_PDF
            // 
            resources.ApplyResources(this.BTN_PDF, "BTN_PDF");
            this.BTN_PDF.AnimationHoverSpeed = 0.07F;
            this.BTN_PDF.AnimationSpeed = 0.03F;
            this.BTN_PDF.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(131)))), ((int)(((byte)(18)))));
            this.BTN_PDF.BaseColor2 = System.Drawing.Color.Coral;
            this.BTN_PDF.BorderColor = System.Drawing.Color.White;
            this.BTN_PDF.BorderSize = 1;
            this.BTN_PDF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_PDF.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_PDF.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_PDF.ForeColor = System.Drawing.Color.White;
            this.BTN_PDF.Image = ((System.Drawing.Image)(resources.GetObject("BTN_PDF.Image")));
            this.BTN_PDF.ImageSize = new System.Drawing.Size(15, 15);
            this.BTN_PDF.Name = "BTN_PDF";
            this.BTN_PDF.OnHoverBaseColor1 = System.Drawing.Color.OrangeRed;
            this.BTN_PDF.OnHoverBaseColor2 = System.Drawing.Color.OrangeRed;
            this.BTN_PDF.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_PDF.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_PDF.OnHoverImage = null;
            this.BTN_PDF.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_PDF.TextOffsetX = 3;
            this.BTN_PDF.Click += new System.EventHandler(this.BTN_PDF_Click);
            // 
            // BTN_excel
            // 
            resources.ApplyResources(this.BTN_excel, "BTN_excel");
            this.BTN_excel.AnimationHoverSpeed = 0.07F;
            this.BTN_excel.AnimationSpeed = 0.03F;
            this.BTN_excel.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(95)))), ((int)(((byte)(45)))));
            this.BTN_excel.BaseColor2 = System.Drawing.Color.Green;
            this.BTN_excel.BorderColor = System.Drawing.Color.White;
            this.BTN_excel.BorderSize = 1;
            this.BTN_excel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_excel.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_excel.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_excel.ForeColor = System.Drawing.Color.White;
            this.BTN_excel.Image = ((System.Drawing.Image)(resources.GetObject("BTN_excel.Image")));
            this.BTN_excel.ImageSize = new System.Drawing.Size(15, 15);
            this.BTN_excel.Name = "BTN_excel";
            this.BTN_excel.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(95)))), ((int)(((byte)(45)))));
            this.BTN_excel.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(95)))), ((int)(((byte)(45)))));
            this.BTN_excel.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_excel.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_excel.OnHoverImage = null;
            this.BTN_excel.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_excel.TextOffsetX = 3;
            this.BTN_excel.Click += new System.EventHandler(this.BTN_excel_Click);
            // 
            // BTN_ThemQuanLy
            // 
            resources.ApplyResources(this.BTN_ThemQuanLy, "BTN_ThemQuanLy");
            this.BTN_ThemQuanLy.Animated = true;
            this.BTN_ThemQuanLy.AnimationHoverSpeed = 0.3F;
            this.BTN_ThemQuanLy.AnimationSpeed = 0.03F;
            this.BTN_ThemQuanLy.BackColor = System.Drawing.Color.Transparent;
            this.BTN_ThemQuanLy.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(187)))), ((int)(((byte)(225)))));
            this.BTN_ThemQuanLy.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(187)))), ((int)(((byte)(225)))));
            this.BTN_ThemQuanLy.BorderColor = System.Drawing.Color.White;
            this.BTN_ThemQuanLy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_ThemQuanLy.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_ThemQuanLy.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_ThemQuanLy.ForeColor = System.Drawing.Color.White;
            this.BTN_ThemQuanLy.Image = null;
            this.BTN_ThemQuanLy.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_ThemQuanLy.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_ThemQuanLy.Name = "BTN_ThemQuanLy";
            this.BTN_ThemQuanLy.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(100)))), ((int)(((byte)(225)))));
            this.BTN_ThemQuanLy.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(100)))), ((int)(((byte)(225)))));
            this.BTN_ThemQuanLy.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_ThemQuanLy.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_ThemQuanLy.OnHoverImage = null;
            this.BTN_ThemQuanLy.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_ThemQuanLy.Radius = 5;
            this.BTN_ThemQuanLy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_ThemQuanLy.Click += new System.EventHandler(this.BTN_ThemQuanLy_Click);
            // 
            // NhanVien
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.Controls.Add(this.BTN_ThemQuanLy);
            this.Controls.Add(this.BTN_PhongBan);
            this.Controls.Add(this.BTN_in);
            this.Controls.Add(this.BTN_PDF);
            this.Controls.Add(this.BTN_excel);
            this.Controls.Add(this.BTN_themnhom);
            this.Controls.Add(this.GGC_danhsachnv);
            this.Controls.Add(this.BTN_themnhanvien);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "NhanVien";
            this.Load += new System.EventHandler(this.NhanVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GGC_danhsachnv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI.WinForms.GunaGradientButton BTN_themnhanvien;
        private Syncfusion.Windows.Forms.Grid.Grouping.GridGroupingControl GGC_danhsachnv;
        private Guna.UI.WinForms.GunaGradientButton BTN_themnhom;
        private Guna.UI.WinForms.GunaGradientButton BTN_in;
        private Guna.UI.WinForms.GunaGradientButton BTN_PDF;
        private Guna.UI.WinForms.GunaGradientButton BTN_excel;
        private Guna.UI.WinForms.GunaGradientButton BTN_PhongBan;
        private Guna.UI.WinForms.GunaGradientButton BTN_ThemQuanLy;
    }
}