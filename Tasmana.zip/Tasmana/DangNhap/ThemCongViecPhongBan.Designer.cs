﻿
namespace DangNhap
{
    partial class ThemCongViecPhongBan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThemCongViecPhongBan));
            this.panel1 = new System.Windows.Forms.Panel();
            this.CBB_QuyenTruyCap = new System.Windows.Forms.ComboBox();
            this.TXB_MaCongViec = new System.Windows.Forms.TextBox();
            this.LB_MaCongViec = new System.Windows.Forms.Label();
            this.TXB_macanho = new System.Windows.Forms.TextBox();
            this.DTP_gio = new System.Windows.Forms.DateTimePicker();
            this.CBB_phongban = new System.Windows.Forms.ComboBox();
            this.LB_quyentruycap = new System.Windows.Forms.Label();
            this.LB_maphongban = new System.Windows.Forms.Label();
            this.LB_noidung = new System.Windows.Forms.Label();
            this.BTN_huy = new Guna.UI.WinForms.GunaGradientButton();
            this.TXB_noidung = new System.Windows.Forms.TextBox();
            this.BTN_ok = new Guna.UI.WinForms.GunaGradientButton();
            this.LB_macanho = new System.Windows.Forms.Label();
            this.LB_thoihan = new System.Windows.Forms.Label();
            this.DTP_ngay = new System.Windows.Forms.DateTimePicker();
            this.panel6 = new System.Windows.Forms.Panel();
            this.LB_Ghichu = new System.Windows.Forms.Label();
            this.TXB_ghiChu = new System.Windows.Forms.TextBox();
            this.CB_thoihan = new System.Windows.Forms.CheckBox();
            this.LLB_themfilepb = new System.Windows.Forms.LinkLabel();
            this.LB_PhiDichVu = new System.Windows.Forms.Label();
            this.TXB_PhiDichVu = new System.Windows.Forms.TextBox();
            this.BTN_file = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Name = "panel1";
            // 
            // CBB_QuyenTruyCap
            // 
            resources.ApplyResources(this.CBB_QuyenTruyCap, "CBB_QuyenTruyCap");
            this.CBB_QuyenTruyCap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_QuyenTruyCap.ForeColor = System.Drawing.Color.White;
            this.CBB_QuyenTruyCap.FormattingEnabled = true;
            this.CBB_QuyenTruyCap.Items.AddRange(new object[] {
            resources.GetString("CBB_QuyenTruyCap.Items"),
            resources.GetString("CBB_QuyenTruyCap.Items1")});
            this.CBB_QuyenTruyCap.Name = "CBB_QuyenTruyCap";
            // 
            // TXB_MaCongViec
            // 
            resources.ApplyResources(this.TXB_MaCongViec, "TXB_MaCongViec");
            this.TXB_MaCongViec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_MaCongViec.ForeColor = System.Drawing.Color.White;
            this.TXB_MaCongViec.Name = "TXB_MaCongViec";
            // 
            // LB_MaCongViec
            // 
            resources.ApplyResources(this.LB_MaCongViec, "LB_MaCongViec");
            this.LB_MaCongViec.ForeColor = System.Drawing.Color.White;
            this.LB_MaCongViec.Name = "LB_MaCongViec";
            // 
            // TXB_macanho
            // 
            resources.ApplyResources(this.TXB_macanho, "TXB_macanho");
            this.TXB_macanho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_macanho.ForeColor = System.Drawing.Color.White;
            this.TXB_macanho.Name = "TXB_macanho";
            // 
            // DTP_gio
            // 
            resources.ApplyResources(this.DTP_gio, "DTP_gio");
            this.DTP_gio.CalendarMonthBackground = System.Drawing.Color.Black;
            this.DTP_gio.CalendarTitleBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.DTP_gio.CalendarTrailingForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.DTP_gio.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTP_gio.Name = "DTP_gio";
            // 
            // CBB_phongban
            // 
            resources.ApplyResources(this.CBB_phongban, "CBB_phongban");
            this.CBB_phongban.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_phongban.ForeColor = System.Drawing.Color.White;
            this.CBB_phongban.FormattingEnabled = true;
            this.CBB_phongban.Name = "CBB_phongban";
            this.CBB_phongban.SelectedValueChanged += new System.EventHandler(this.CBB_phongban_SelectedValueChanged);
            // 
            // LB_quyentruycap
            // 
            resources.ApplyResources(this.LB_quyentruycap, "LB_quyentruycap");
            this.LB_quyentruycap.ForeColor = System.Drawing.Color.White;
            this.LB_quyentruycap.Name = "LB_quyentruycap";
            // 
            // LB_maphongban
            // 
            resources.ApplyResources(this.LB_maphongban, "LB_maphongban");
            this.LB_maphongban.ForeColor = System.Drawing.Color.White;
            this.LB_maphongban.Name = "LB_maphongban";
            // 
            // LB_noidung
            // 
            resources.ApplyResources(this.LB_noidung, "LB_noidung");
            this.LB_noidung.ForeColor = System.Drawing.Color.White;
            this.LB_noidung.Name = "LB_noidung";
            // 
            // BTN_huy
            // 
            resources.ApplyResources(this.BTN_huy, "BTN_huy");
            this.BTN_huy.Animated = true;
            this.BTN_huy.AnimationHoverSpeed = 0.5F;
            this.BTN_huy.AnimationSpeed = 0.03F;
            this.BTN_huy.BackColor = System.Drawing.Color.Transparent;
            this.BTN_huy.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(218)))), ((int)(((byte)(215)))));
            this.BTN_huy.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(218)))), ((int)(((byte)(215)))));
            this.BTN_huy.BorderColor = System.Drawing.Color.Red;
            this.BTN_huy.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_huy.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_huy.ForeColor = System.Drawing.Color.Black;
            this.BTN_huy.Image = null;
            this.BTN_huy.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_huy.Name = "BTN_huy";
            this.BTN_huy.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_huy.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_huy.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_huy.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_huy.OnHoverImage = null;
            this.BTN_huy.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_huy.Radius = 5;
            this.BTN_huy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_huy.Click += new System.EventHandler(this.BTN_huy_Click);
            // 
            // TXB_noidung
            // 
            resources.ApplyResources(this.TXB_noidung, "TXB_noidung");
            this.TXB_noidung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_noidung.ForeColor = System.Drawing.Color.White;
            this.TXB_noidung.Name = "TXB_noidung";
            // 
            // BTN_ok
            // 
            resources.ApplyResources(this.BTN_ok, "BTN_ok");
            this.BTN_ok.Animated = true;
            this.BTN_ok.AnimationHoverSpeed = 0.5F;
            this.BTN_ok.AnimationSpeed = 0.03F;
            this.BTN_ok.BackColor = System.Drawing.Color.Transparent;
            this.BTN_ok.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_ok.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_ok.BorderColor = System.Drawing.Color.Black;
            this.BTN_ok.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_ok.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_ok.ForeColor = System.Drawing.Color.White;
            this.BTN_ok.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_ok.Image = null;
            this.BTN_ok.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_ok.Name = "BTN_ok";
            this.BTN_ok.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_ok.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_ok.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_ok.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_ok.OnHoverImage = null;
            this.BTN_ok.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_ok.Radius = 5;
            this.BTN_ok.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_ok.Click += new System.EventHandler(this.BTN_ok_Click);
            // 
            // LB_macanho
            // 
            resources.ApplyResources(this.LB_macanho, "LB_macanho");
            this.LB_macanho.ForeColor = System.Drawing.Color.White;
            this.LB_macanho.Name = "LB_macanho";
            // 
            // LB_thoihan
            // 
            resources.ApplyResources(this.LB_thoihan, "LB_thoihan");
            this.LB_thoihan.ForeColor = System.Drawing.Color.White;
            this.LB_thoihan.Name = "LB_thoihan";
            // 
            // DTP_ngay
            // 
            resources.ApplyResources(this.DTP_ngay, "DTP_ngay");
            this.DTP_ngay.CalendarMonthBackground = System.Drawing.Color.Black;
            this.DTP_ngay.CalendarTitleBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.DTP_ngay.CalendarTrailingForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.DTP_ngay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DTP_ngay.Name = "DTP_ngay";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Name = "panel6";
            // 
            // LB_Ghichu
            // 
            resources.ApplyResources(this.LB_Ghichu, "LB_Ghichu");
            this.LB_Ghichu.ForeColor = System.Drawing.Color.White;
            this.LB_Ghichu.Name = "LB_Ghichu";
            // 
            // TXB_ghiChu
            // 
            resources.ApplyResources(this.TXB_ghiChu, "TXB_ghiChu");
            this.TXB_ghiChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_ghiChu.ForeColor = System.Drawing.Color.White;
            this.TXB_ghiChu.Name = "TXB_ghiChu";
            // 
            // CB_thoihan
            // 
            resources.ApplyResources(this.CB_thoihan, "CB_thoihan");
            this.CB_thoihan.ForeColor = System.Drawing.Color.White;
            this.CB_thoihan.Name = "CB_thoihan";
            this.CB_thoihan.UseVisualStyleBackColor = true;
            this.CB_thoihan.CheckedChanged += new System.EventHandler(this.CB_thoihan_CheckedChanged);
            // 
            // LLB_themfilepb
            // 
            resources.ApplyResources(this.LLB_themfilepb, "LLB_themfilepb");
            this.LLB_themfilepb.LinkColor = System.Drawing.Color.White;
            this.LLB_themfilepb.Name = "LLB_themfilepb";
            this.LLB_themfilepb.TabStop = true;
            // 
            // LB_PhiDichVu
            // 
            resources.ApplyResources(this.LB_PhiDichVu, "LB_PhiDichVu");
            this.LB_PhiDichVu.ForeColor = System.Drawing.Color.White;
            this.LB_PhiDichVu.Name = "LB_PhiDichVu";
            // 
            // TXB_PhiDichVu
            // 
            resources.ApplyResources(this.TXB_PhiDichVu, "TXB_PhiDichVu");
            this.TXB_PhiDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_PhiDichVu.ForeColor = System.Drawing.Color.White;
            this.TXB_PhiDichVu.Name = "TXB_PhiDichVu";
            // 
            // BTN_file
            // 
            resources.ApplyResources(this.BTN_file, "BTN_file");
            this.BTN_file.ForeColor = System.Drawing.Color.White;
            this.BTN_file.Name = "BTN_file";
            this.BTN_file.UseVisualStyleBackColor = true;
            this.BTN_file.Click += new System.EventHandler(this.BTN_file_Click);
            // 
            // ThemCongViecPhongBan
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.Controls.Add(this.LB_PhiDichVu);
            this.Controls.Add(this.TXB_PhiDichVu);
            this.Controls.Add(this.LLB_themfilepb);
            this.Controls.Add(this.LB_Ghichu);
            this.Controls.Add(this.TXB_ghiChu);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CB_thoihan);
            this.Controls.Add(this.CBB_QuyenTruyCap);
            this.Controls.Add(this.TXB_MaCongViec);
            this.Controls.Add(this.LB_MaCongViec);
            this.Controls.Add(this.TXB_macanho);
            this.Controls.Add(this.DTP_gio);
            this.Controls.Add(this.CBB_phongban);
            this.Controls.Add(this.BTN_file);
            this.Controls.Add(this.LB_quyentruycap);
            this.Controls.Add(this.LB_maphongban);
            this.Controls.Add(this.LB_noidung);
            this.Controls.Add(this.BTN_huy);
            this.Controls.Add(this.TXB_noidung);
            this.Controls.Add(this.BTN_ok);
            this.Controls.Add(this.LB_macanho);
            this.Controls.Add(this.LB_thoihan);
            this.Controls.Add(this.DTP_ngay);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ThemCongViecPhongBan";
            this.Load += new System.EventHandler(this.ThemCongViecPhongBan_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox CBB_QuyenTruyCap;
        private System.Windows.Forms.TextBox TXB_MaCongViec;
        private System.Windows.Forms.Label LB_MaCongViec;
        private System.Windows.Forms.TextBox TXB_macanho;
        private System.Windows.Forms.DateTimePicker DTP_gio;
        private System.Windows.Forms.ComboBox CBB_phongban;
        private System.Windows.Forms.Button BTN_file;
        private System.Windows.Forms.Label LB_quyentruycap;
        private System.Windows.Forms.Label LB_maphongban;
        private System.Windows.Forms.Label LB_noidung;
        private Guna.UI.WinForms.GunaGradientButton BTN_huy;
        private System.Windows.Forms.TextBox TXB_noidung;
        private Guna.UI.WinForms.GunaGradientButton BTN_ok;
        private System.Windows.Forms.Label LB_macanho;
        private System.Windows.Forms.Label LB_thoihan;
        private System.Windows.Forms.DateTimePicker DTP_ngay;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label LB_Ghichu;
        public System.Windows.Forms.TextBox TXB_ghiChu;
        private System.Windows.Forms.CheckBox CB_thoihan;
        private System.Windows.Forms.LinkLabel LLB_themfilepb;
        private System.Windows.Forms.Label LB_PhiDichVu;
        public System.Windows.Forms.TextBox TXB_PhiDichVu;
    }
}