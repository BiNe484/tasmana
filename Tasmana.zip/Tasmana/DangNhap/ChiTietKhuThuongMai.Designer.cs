﻿namespace DangNhap
{
    partial class ChiTietKhuThuongMai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChiTietKhuThuongMai));
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.NUD_thangmay = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label9 = new System.Windows.Forms.Label();
            this.NUD_toilet = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LB_hinhanhcanho = new System.Windows.Forms.Label();
            this.BTN_xoa = new Guna.UI.WinForms.GunaGradientButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BTN_luu = new Guna.UI.WinForms.GunaGradientButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.BTN_lichsu = new System.Windows.Forms.Button();
            this.BTN_chung = new System.Windows.Forms.Button();
            this.NUD_phongngu = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label15 = new System.Windows.Forms.Label();
            this.PN_hienthi = new System.Windows.Forms.Panel();
            this.NUD_mucphiql = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.NUD_vitritang = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label22 = new System.Windows.Forms.Label();
            this.TXB_NSA = new System.Windows.Forms.TextBox();
            this.TXB_GSA = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.NUD_thanhtoan = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.BTN_uploadanh = new Guna.UI.WinForms.GunaGradientButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.numericUpDownExt4 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label16 = new System.Windows.Forms.Label();
            this.numericUpDownExt5 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownExt6 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.PB_hinhcanho = new System.Windows.Forms.PictureBox();
            this.TXB_macanho = new System.Windows.Forms.TextBox();
            this.LB_khachdangthue = new System.Windows.Forms.Label();
            this.TXB_khachdangthue = new System.Windows.Forms.TextBox();
            this.LB_phongngu = new System.Windows.Forms.Label();
            this.LB_thanhtoan = new System.Windows.Forms.Label();
            this.LB_ttktm = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_thangmay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_toilet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_phongngu)).BeginInit();
            this.PN_hienthi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_mucphiql)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_vitritang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_thanhtoan)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_hinhcanho)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Name = "label10";
            // 
            // NUD_thangmay
            // 
            resources.ApplyResources(this.NUD_thangmay, "NUD_thangmay");
            this.NUD_thangmay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_thangmay.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.NUD_thangmay.ForeColor = System.Drawing.Color.White;
            this.NUD_thangmay.Name = "NUD_thangmay";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Name = "label9";
            // 
            // NUD_toilet
            // 
            resources.ApplyResources(this.NUD_toilet, "NUD_toilet");
            this.NUD_toilet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_toilet.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.NUD_toilet.ForeColor = System.Drawing.Color.White;
            this.NUD_toilet.Name = "NUD_toilet";
            // 
            // panel8
            // 
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.BackColor = System.Drawing.Color.Silver;
            this.panel8.Name = "panel8";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Name = "label13";
            // 
            // textBox3
            // 
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Name = "textBox3";
            // 
            // comboBox2
            // 
            resources.ApplyResources(this.comboBox2, "comboBox2");
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.comboBox2.ForeColor = System.Drawing.Color.White;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Name = "comboBox2";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Name = "label14";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Name = "label18";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Name = "label7";
            // 
            // LB_hinhanhcanho
            // 
            resources.ApplyResources(this.LB_hinhanhcanho, "LB_hinhanhcanho");
            this.LB_hinhanhcanho.ForeColor = System.Drawing.Color.White;
            this.LB_hinhanhcanho.Name = "LB_hinhanhcanho";
            // 
            // BTN_xoa
            // 
            resources.ApplyResources(this.BTN_xoa, "BTN_xoa");
            this.BTN_xoa.Animated = true;
            this.BTN_xoa.AnimationHoverSpeed = 0.2F;
            this.BTN_xoa.AnimationSpeed = 0.03F;
            this.BTN_xoa.BackColor = System.Drawing.Color.Transparent;
            this.BTN_xoa.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_xoa.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_xoa.BorderColor = System.Drawing.Color.Red;
            this.BTN_xoa.BorderSize = 1;
            this.BTN_xoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_xoa.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_xoa.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_xoa.ForeColor = System.Drawing.Color.Red;
            this.BTN_xoa.Image = null;
            this.BTN_xoa.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_xoa.Name = "BTN_xoa";
            this.BTN_xoa.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_xoa.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_xoa.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_xoa.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_xoa.OnHoverImage = null;
            this.BTN_xoa.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_xoa.Radius = 5;
            this.BTN_xoa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_xoa.Click += new System.EventHandler(this.BTN_xoa_Click);
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Name = "panel6";
            // 
            // BTN_luu
            // 
            resources.ApplyResources(this.BTN_luu, "BTN_luu");
            this.BTN_luu.Animated = true;
            this.BTN_luu.AnimationHoverSpeed = 0.5F;
            this.BTN_luu.AnimationSpeed = 0.03F;
            this.BTN_luu.BackColor = System.Drawing.Color.Transparent;
            this.BTN_luu.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_luu.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.BorderColor = System.Drawing.Color.Black;
            this.BTN_luu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_luu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_luu.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_luu.ForeColor = System.Drawing.Color.White;
            this.BTN_luu.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_luu.Image = null;
            this.BTN_luu.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_luu.Name = "BTN_luu";
            this.BTN_luu.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverImage = null;
            this.BTN_luu.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_luu.Radius = 5;
            this.BTN_luu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_luu.Click += new System.EventHandler(this.BTN_luu_Click);
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Name = "panel3";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Name = "panel2";
            // 
            // BTN_lichsu
            // 
            resources.ApplyResources(this.BTN_lichsu, "BTN_lichsu");
            this.BTN_lichsu.BackColor = System.Drawing.Color.Transparent;
            this.BTN_lichsu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_lichsu.FlatAppearance.BorderSize = 0;
            this.BTN_lichsu.ForeColor = System.Drawing.Color.White;
            this.BTN_lichsu.Name = "BTN_lichsu";
            this.BTN_lichsu.UseVisualStyleBackColor = false;
            this.BTN_lichsu.Click += new System.EventHandler(this.BTN_lichsu_Click);
            // 
            // BTN_chung
            // 
            resources.ApplyResources(this.BTN_chung, "BTN_chung");
            this.BTN_chung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(55)))));
            this.BTN_chung.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_chung.FlatAppearance.BorderSize = 0;
            this.BTN_chung.ForeColor = System.Drawing.Color.White;
            this.BTN_chung.Name = "BTN_chung";
            this.BTN_chung.UseVisualStyleBackColor = false;
            this.BTN_chung.Click += new System.EventHandler(this.BTN_chung_Click);
            // 
            // NUD_phongngu
            // 
            resources.ApplyResources(this.NUD_phongngu, "NUD_phongngu");
            this.NUD_phongngu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_phongngu.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.NUD_phongngu.ForeColor = System.Drawing.Color.White;
            this.NUD_phongngu.Name = "NUD_phongngu";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Name = "label15";
            // 
            // PN_hienthi
            // 
            resources.ApplyResources(this.PN_hienthi, "PN_hienthi");
            this.PN_hienthi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.PN_hienthi.Controls.Add(this.NUD_mucphiql);
            this.PN_hienthi.Controls.Add(this.NUD_vitritang);
            this.PN_hienthi.Controls.Add(this.label22);
            this.PN_hienthi.Controls.Add(this.TXB_NSA);
            this.PN_hienthi.Controls.Add(this.TXB_GSA);
            this.PN_hienthi.Controls.Add(this.label21);
            this.PN_hienthi.Controls.Add(this.label20);
            this.PN_hienthi.Controls.Add(this.label19);
            this.PN_hienthi.Controls.Add(this.NUD_thanhtoan);
            this.PN_hienthi.Controls.Add(this.BTN_uploadanh);
            this.PN_hienthi.Controls.Add(this.panel7);
            this.PN_hienthi.Controls.Add(this.panel1);
            this.PN_hienthi.Controls.Add(this.label3);
            this.PN_hienthi.Controls.Add(this.label10);
            this.PN_hienthi.Controls.Add(this.NUD_thangmay);
            this.PN_hienthi.Controls.Add(this.label9);
            this.PN_hienthi.Controls.Add(this.NUD_toilet);
            this.PN_hienthi.Controls.Add(this.NUD_phongngu);
            this.PN_hienthi.Controls.Add(this.LB_hinhanhcanho);
            this.PN_hienthi.Controls.Add(this.PB_hinhcanho);
            this.PN_hienthi.Controls.Add(this.TXB_macanho);
            this.PN_hienthi.Controls.Add(this.LB_khachdangthue);
            this.PN_hienthi.Controls.Add(this.TXB_khachdangthue);
            this.PN_hienthi.Controls.Add(this.LB_phongngu);
            this.PN_hienthi.Controls.Add(this.LB_thanhtoan);
            this.PN_hienthi.Controls.Add(this.label7);
            this.PN_hienthi.Name = "PN_hienthi";
            // 
            // NUD_mucphiql
            // 
            resources.ApplyResources(this.NUD_mucphiql, "NUD_mucphiql");
            this.NUD_mucphiql.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_mucphiql.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.NUD_mucphiql.ForeColor = System.Drawing.Color.White;
            this.NUD_mucphiql.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NUD_mucphiql.Name = "NUD_mucphiql";
            // 
            // NUD_vitritang
            // 
            resources.ApplyResources(this.NUD_vitritang, "NUD_vitritang");
            this.NUD_vitritang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_vitritang.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.NUD_vitritang.ForeColor = System.Drawing.Color.White;
            this.NUD_vitritang.Name = "NUD_vitritang";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Name = "label22";
            // 
            // TXB_NSA
            // 
            resources.ApplyResources(this.TXB_NSA, "TXB_NSA");
            this.TXB_NSA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_NSA.ForeColor = System.Drawing.Color.White;
            this.TXB_NSA.Name = "TXB_NSA";
            // 
            // TXB_GSA
            // 
            resources.ApplyResources(this.TXB_GSA, "TXB_GSA");
            this.TXB_GSA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_GSA.ForeColor = System.Drawing.Color.White;
            this.TXB_GSA.Name = "TXB_GSA";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Name = "label21";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Name = "label20";
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Name = "label19";
            // 
            // NUD_thanhtoan
            // 
            resources.ApplyResources(this.NUD_thanhtoan, "NUD_thanhtoan");
            this.NUD_thanhtoan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_thanhtoan.BeforeTouchSize = new System.Drawing.Size(96, 30);
            this.NUD_thanhtoan.ForeColor = System.Drawing.Color.White;
            this.NUD_thanhtoan.Name = "NUD_thanhtoan";
            // 
            // BTN_uploadanh
            // 
            resources.ApplyResources(this.BTN_uploadanh, "BTN_uploadanh");
            this.BTN_uploadanh.Animated = true;
            this.BTN_uploadanh.AnimationHoverSpeed = 0.5F;
            this.BTN_uploadanh.AnimationSpeed = 0.03F;
            this.BTN_uploadanh.BackColor = System.Drawing.Color.Transparent;
            this.BTN_uploadanh.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_uploadanh.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_uploadanh.BorderColor = System.Drawing.Color.Black;
            this.BTN_uploadanh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_uploadanh.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_uploadanh.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_uploadanh.ForeColor = System.Drawing.Color.White;
            this.BTN_uploadanh.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_uploadanh.Image = null;
            this.BTN_uploadanh.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_uploadanh.Name = "BTN_uploadanh";
            this.BTN_uploadanh.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_uploadanh.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_uploadanh.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_uploadanh.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_uploadanh.OnHoverImage = null;
            this.BTN_uploadanh.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_uploadanh.Radius = 5;
            this.BTN_uploadanh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_uploadanh.Click += new System.EventHandler(this.BTN_uploadanh_Click);
            // 
            // panel7
            // 
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.BackColor = System.Drawing.Color.Silver;
            this.panel7.Name = "panel7";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.numericUpDownExt4);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.numericUpDownExt5);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.numericUpDownExt6);
            this.panel1.Name = "panel1";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Name = "textBox4";
            // 
            // numericUpDownExt4
            // 
            resources.ApplyResources(this.numericUpDownExt4, "numericUpDownExt4");
            this.numericUpDownExt4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt4.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt4.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt4.Name = "numericUpDownExt4";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Name = "label16";
            // 
            // numericUpDownExt5
            // 
            resources.ApplyResources(this.numericUpDownExt5, "numericUpDownExt5");
            this.numericUpDownExt5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt5.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt5.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt5.Name = "numericUpDownExt5";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Name = "label17";
            // 
            // numericUpDownExt6
            // 
            resources.ApplyResources(this.numericUpDownExt6, "numericUpDownExt6");
            this.numericUpDownExt6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt6.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt6.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt6.Name = "numericUpDownExt6";
            // 
            // PB_hinhcanho
            // 
            resources.ApplyResources(this.PB_hinhcanho, "PB_hinhcanho");
            this.PB_hinhcanho.Name = "PB_hinhcanho";
            this.PB_hinhcanho.TabStop = false;
            // 
            // TXB_macanho
            // 
            resources.ApplyResources(this.TXB_macanho, "TXB_macanho");
            this.TXB_macanho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_macanho.ForeColor = System.Drawing.Color.White;
            this.TXB_macanho.Name = "TXB_macanho";
            // 
            // LB_khachdangthue
            // 
            resources.ApplyResources(this.LB_khachdangthue, "LB_khachdangthue");
            this.LB_khachdangthue.ForeColor = System.Drawing.Color.White;
            this.LB_khachdangthue.Name = "LB_khachdangthue";
            // 
            // TXB_khachdangthue
            // 
            resources.ApplyResources(this.TXB_khachdangthue, "TXB_khachdangthue");
            this.TXB_khachdangthue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_khachdangthue.ForeColor = System.Drawing.Color.White;
            this.TXB_khachdangthue.Name = "TXB_khachdangthue";
            // 
            // LB_phongngu
            // 
            resources.ApplyResources(this.LB_phongngu, "LB_phongngu");
            this.LB_phongngu.ForeColor = System.Drawing.Color.White;
            this.LB_phongngu.Name = "LB_phongngu";
            // 
            // LB_thanhtoan
            // 
            resources.ApplyResources(this.LB_thanhtoan, "LB_thanhtoan");
            this.LB_thanhtoan.ForeColor = System.Drawing.Color.White;
            this.LB_thanhtoan.Name = "LB_thanhtoan";
            // 
            // LB_ttktm
            // 
            resources.ApplyResources(this.LB_ttktm, "LB_ttktm");
            this.LB_ttktm.BackColor = System.Drawing.Color.Transparent;
            this.LB_ttktm.ForeColor = System.Drawing.Color.White;
            this.LB_ttktm.Name = "LB_ttktm";
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Name = "panel5";
            // 
            // BTN_thoat
            // 
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // ChiTietKhuThuongMai
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.BTN_xoa);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.BTN_luu);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.BTN_lichsu);
            this.Controls.Add(this.BTN_chung);
            this.Controls.Add(this.BTN_thoat);
            this.Controls.Add(this.PN_hienthi);
            this.Controls.Add(this.LB_ttktm);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChiTietKhuThuongMai";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChiTietKhuThuongMai_FormClosing);
            this.Load += new System.EventHandler(this.ChiTietKhuThuongMai_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KhuThuongMai_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.KhuThuongMai_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.KhuThuongMai_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.NUD_thangmay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_toilet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_phongngu)).EndInit();
            this.PN_hienthi.ResumeLayout(false);
            this.PN_hienthi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_mucphiql)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_vitritang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_thanhtoan)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_hinhcanho)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt NUD_thangmay;
        private System.Windows.Forms.Label label9;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt NUD_toilet;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label LB_hinhanhcanho;
        private System.Windows.Forms.PictureBox PB_hinhcanho;
        private Guna.UI.WinForms.GunaGradientButton BTN_xoa;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI.WinForms.GunaGradientButton BTN_luu;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button BTN_lichsu;
        private System.Windows.Forms.Button BTN_chung;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt NUD_phongngu;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel PN_hienthi;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt NUD_mucphiql;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt NUD_vitritang;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox TXB_NSA;
        private System.Windows.Forms.TextBox TXB_GSA;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt NUD_thanhtoan;
        private Guna.UI.WinForms.GunaGradientButton BTN_uploadanh;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox4;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt4;
        private System.Windows.Forms.Label label16;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt5;
        private System.Windows.Forms.Label label17;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt6;
        private System.Windows.Forms.TextBox TXB_macanho;
        private System.Windows.Forms.Label LB_khachdangthue;
        private System.Windows.Forms.TextBox TXB_khachdangthue;
        private System.Windows.Forms.Label LB_phongngu;
        private System.Windows.Forms.Label LB_thanhtoan;
        private System.Windows.Forms.Label LB_ttktm;
        private System.Windows.Forms.Panel panel5;
    }
}