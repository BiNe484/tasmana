﻿
namespace DangNhap
{
    partial class ThongTinCuDan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinCuDan));
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LB_ttcd = new System.Windows.Forms.Label();
            this.PN_hienthi = new System.Windows.Forms.Panel();
            this.CBB_nguoithan = new System.Windows.Forms.ComboBox();
            this.CBB_loaicd = new System.Windows.Forms.ComboBox();
            this.LB_etinhtrangxe = new System.Windows.Forms.Label();
            this.LB_eloaixe = new System.Windows.Forms.Label();
            this.LB_ediennuoc = new System.Windows.Forms.Label();
            this.LB_etamtru = new System.Windows.Forms.Label();
            this.LB_eemail = new System.Windows.Forms.Label();
            this.LB_esdt = new System.Windows.Forms.Label();
            this.LB_ecccd = new System.Windows.Forms.Label();
            this.LB_equoctich = new System.Windows.Forms.Label();
            this.LB_ehoten = new System.Windows.Forms.Label();
            this.LB_emacd = new System.Windows.Forms.Label();
            this.LB_eloaicd = new System.Windows.Forms.Label();
            this.LB_emacanho = new System.Windows.Forms.Label();
            this.NUD_congno = new System.Windows.Forms.NumericUpDown();
            this.TXB_tinhtrangxe = new System.Windows.Forms.TextBox();
            this.LB_tinhtrangxe = new System.Windows.Forms.Label();
            this.TXB_loaixe = new System.Windows.Forms.TextBox();
            this.LB_loaixe = new System.Windows.Forms.Label();
            this.LB_nguoithan = new System.Windows.Forms.Label();
            this.TXB_bienso = new System.Windows.Forms.TextBox();
            this.LB_bienso = new System.Windows.Forms.Label();
            this.TXB_diennuoc = new System.Windows.Forms.TextBox();
            this.LB_diennuoc = new System.Windows.Forms.Label();
            this.DTP_di = new System.Windows.Forms.DateTimePicker();
            this.DTP_vao = new System.Windows.Forms.DateTimePicker();
            this.LB_di = new System.Windows.Forms.Label();
            this.DTP_bangiao = new System.Windows.Forms.DateTimePicker();
            this.DTP_ngaysinh = new System.Windows.Forms.DateTimePicker();
            this.LB_bangiao = new System.Windows.Forms.Label();
            this.LB_macd = new System.Windows.Forms.Label();
            this.TXB_macd = new System.Windows.Forms.TextBox();
            this.LB_loaicudan = new System.Windows.Forms.Label();
            this.LB_quoctich = new System.Windows.Forms.Label();
            this.TXB_quoctich = new System.Windows.Forms.TextBox();
            this.LB_thunuoi = new System.Windows.Forms.Label();
            this.TXB_thunuoi = new System.Windows.Forms.TextBox();
            this.LB_congno = new System.Windows.Forms.Label();
            this.LB_vao = new System.Windows.Forms.Label();
            this.LB_email = new System.Windows.Forms.Label();
            this.TXB_email = new System.Windows.Forms.TextBox();
            this.LB_tamtru = new System.Windows.Forms.Label();
            this.TXB_sothetamtru = new System.Windows.Forms.TextBox();
            this.LB_sdt = new System.Windows.Forms.Label();
            this.TXB_sdt = new System.Windows.Forms.TextBox();
            this.LB_dinhdanh = new System.Windows.Forms.Label();
            this.TXB_madinhdanh = new System.Windows.Forms.TextBox();
            this.LB_ngaysinh = new System.Windows.Forms.Label();
            this.LB_hoten = new System.Windows.Forms.Label();
            this.TXB_hovaten = new System.Windows.Forms.TextBox();
            this.LB_macanho = new System.Windows.Forms.Label();
            this.TXB_macanho = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.numericUpDownExt4 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label16 = new System.Windows.Forms.Label();
            this.numericUpDownExt5 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownExt6 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.BTN_xoa = new Guna.UI.WinForms.GunaGradientButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BTN_luu = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            this.PN_hienthi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_congno)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt6)).BeginInit();
            this.SuspendLayout();
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Name = "panel5";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Name = "panel3";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Name = "panel2";
            // 
            // LB_ttcd
            // 
            resources.ApplyResources(this.LB_ttcd, "LB_ttcd");
            this.LB_ttcd.BackColor = System.Drawing.Color.Transparent;
            this.LB_ttcd.ForeColor = System.Drawing.Color.White;
            this.LB_ttcd.Name = "LB_ttcd";
            // 
            // PN_hienthi
            // 
            resources.ApplyResources(this.PN_hienthi, "PN_hienthi");
            this.PN_hienthi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.PN_hienthi.Controls.Add(this.CBB_nguoithan);
            this.PN_hienthi.Controls.Add(this.CBB_loaicd);
            this.PN_hienthi.Controls.Add(this.LB_etinhtrangxe);
            this.PN_hienthi.Controls.Add(this.LB_eloaixe);
            this.PN_hienthi.Controls.Add(this.LB_ediennuoc);
            this.PN_hienthi.Controls.Add(this.LB_etamtru);
            this.PN_hienthi.Controls.Add(this.LB_eemail);
            this.PN_hienthi.Controls.Add(this.LB_esdt);
            this.PN_hienthi.Controls.Add(this.LB_ecccd);
            this.PN_hienthi.Controls.Add(this.LB_equoctich);
            this.PN_hienthi.Controls.Add(this.LB_ehoten);
            this.PN_hienthi.Controls.Add(this.LB_emacd);
            this.PN_hienthi.Controls.Add(this.LB_eloaicd);
            this.PN_hienthi.Controls.Add(this.LB_emacanho);
            this.PN_hienthi.Controls.Add(this.NUD_congno);
            this.PN_hienthi.Controls.Add(this.TXB_tinhtrangxe);
            this.PN_hienthi.Controls.Add(this.LB_tinhtrangxe);
            this.PN_hienthi.Controls.Add(this.TXB_loaixe);
            this.PN_hienthi.Controls.Add(this.LB_loaixe);
            this.PN_hienthi.Controls.Add(this.LB_nguoithan);
            this.PN_hienthi.Controls.Add(this.TXB_bienso);
            this.PN_hienthi.Controls.Add(this.LB_bienso);
            this.PN_hienthi.Controls.Add(this.TXB_diennuoc);
            this.PN_hienthi.Controls.Add(this.LB_diennuoc);
            this.PN_hienthi.Controls.Add(this.DTP_di);
            this.PN_hienthi.Controls.Add(this.DTP_vao);
            this.PN_hienthi.Controls.Add(this.LB_di);
            this.PN_hienthi.Controls.Add(this.DTP_bangiao);
            this.PN_hienthi.Controls.Add(this.DTP_ngaysinh);
            this.PN_hienthi.Controls.Add(this.LB_bangiao);
            this.PN_hienthi.Controls.Add(this.LB_macd);
            this.PN_hienthi.Controls.Add(this.TXB_macd);
            this.PN_hienthi.Controls.Add(this.LB_loaicudan);
            this.PN_hienthi.Controls.Add(this.LB_quoctich);
            this.PN_hienthi.Controls.Add(this.TXB_quoctich);
            this.PN_hienthi.Controls.Add(this.LB_thunuoi);
            this.PN_hienthi.Controls.Add(this.TXB_thunuoi);
            this.PN_hienthi.Controls.Add(this.LB_congno);
            this.PN_hienthi.Controls.Add(this.LB_vao);
            this.PN_hienthi.Controls.Add(this.LB_email);
            this.PN_hienthi.Controls.Add(this.TXB_email);
            this.PN_hienthi.Controls.Add(this.LB_tamtru);
            this.PN_hienthi.Controls.Add(this.TXB_sothetamtru);
            this.PN_hienthi.Controls.Add(this.LB_sdt);
            this.PN_hienthi.Controls.Add(this.TXB_sdt);
            this.PN_hienthi.Controls.Add(this.LB_dinhdanh);
            this.PN_hienthi.Controls.Add(this.TXB_madinhdanh);
            this.PN_hienthi.Controls.Add(this.LB_ngaysinh);
            this.PN_hienthi.Controls.Add(this.LB_hoten);
            this.PN_hienthi.Controls.Add(this.TXB_hovaten);
            this.PN_hienthi.Controls.Add(this.LB_macanho);
            this.PN_hienthi.Controls.Add(this.TXB_macanho);
            this.PN_hienthi.Controls.Add(this.panel7);
            this.PN_hienthi.Controls.Add(this.panel1);
            this.PN_hienthi.Name = "PN_hienthi";
            // 
            // CBB_nguoithan
            // 
            resources.ApplyResources(this.CBB_nguoithan, "CBB_nguoithan");
            this.CBB_nguoithan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_nguoithan.ForeColor = System.Drawing.Color.White;
            this.CBB_nguoithan.FormattingEnabled = true;
            this.CBB_nguoithan.Name = "CBB_nguoithan";
            // 
            // CBB_loaicd
            // 
            resources.ApplyResources(this.CBB_loaicd, "CBB_loaicd");
            this.CBB_loaicd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_loaicd.ForeColor = System.Drawing.Color.White;
            this.CBB_loaicd.FormattingEnabled = true;
            this.CBB_loaicd.Items.AddRange(new object[] {
            resources.GetString("CBB_loaicd.Items"),
            resources.GetString("CBB_loaicd.Items1"),
            resources.GetString("CBB_loaicd.Items2"),
            resources.GetString("CBB_loaicd.Items3"),
            resources.GetString("CBB_loaicd.Items4")});
            this.CBB_loaicd.Name = "CBB_loaicd";
            this.CBB_loaicd.SelectedIndexChanged += new System.EventHandler(this.CBB_loaicd_SelectedIndexChanged);
            // 
            // LB_etinhtrangxe
            // 
            resources.ApplyResources(this.LB_etinhtrangxe, "LB_etinhtrangxe");
            this.LB_etinhtrangxe.ForeColor = System.Drawing.Color.Red;
            this.LB_etinhtrangxe.Name = "LB_etinhtrangxe";
            // 
            // LB_eloaixe
            // 
            resources.ApplyResources(this.LB_eloaixe, "LB_eloaixe");
            this.LB_eloaixe.ForeColor = System.Drawing.Color.Red;
            this.LB_eloaixe.Name = "LB_eloaixe";
            // 
            // LB_ediennuoc
            // 
            resources.ApplyResources(this.LB_ediennuoc, "LB_ediennuoc");
            this.LB_ediennuoc.ForeColor = System.Drawing.Color.Red;
            this.LB_ediennuoc.Name = "LB_ediennuoc";
            // 
            // LB_etamtru
            // 
            resources.ApplyResources(this.LB_etamtru, "LB_etamtru");
            this.LB_etamtru.ForeColor = System.Drawing.Color.Red;
            this.LB_etamtru.Name = "LB_etamtru";
            // 
            // LB_eemail
            // 
            resources.ApplyResources(this.LB_eemail, "LB_eemail");
            this.LB_eemail.ForeColor = System.Drawing.Color.Red;
            this.LB_eemail.Name = "LB_eemail";
            // 
            // LB_esdt
            // 
            resources.ApplyResources(this.LB_esdt, "LB_esdt");
            this.LB_esdt.ForeColor = System.Drawing.Color.Red;
            this.LB_esdt.Name = "LB_esdt";
            // 
            // LB_ecccd
            // 
            resources.ApplyResources(this.LB_ecccd, "LB_ecccd");
            this.LB_ecccd.ForeColor = System.Drawing.Color.Red;
            this.LB_ecccd.Name = "LB_ecccd";
            // 
            // LB_equoctich
            // 
            resources.ApplyResources(this.LB_equoctich, "LB_equoctich");
            this.LB_equoctich.ForeColor = System.Drawing.Color.Red;
            this.LB_equoctich.Name = "LB_equoctich";
            // 
            // LB_ehoten
            // 
            resources.ApplyResources(this.LB_ehoten, "LB_ehoten");
            this.LB_ehoten.ForeColor = System.Drawing.Color.Red;
            this.LB_ehoten.Name = "LB_ehoten";
            // 
            // LB_emacd
            // 
            resources.ApplyResources(this.LB_emacd, "LB_emacd");
            this.LB_emacd.ForeColor = System.Drawing.Color.Red;
            this.LB_emacd.Name = "LB_emacd";
            // 
            // LB_eloaicd
            // 
            resources.ApplyResources(this.LB_eloaicd, "LB_eloaicd");
            this.LB_eloaicd.ForeColor = System.Drawing.Color.Red;
            this.LB_eloaicd.Name = "LB_eloaicd";
            // 
            // LB_emacanho
            // 
            resources.ApplyResources(this.LB_emacanho, "LB_emacanho");
            this.LB_emacanho.ForeColor = System.Drawing.Color.Red;
            this.LB_emacanho.Name = "LB_emacanho";
            // 
            // NUD_congno
            // 
            resources.ApplyResources(this.NUD_congno, "NUD_congno");
            this.NUD_congno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_congno.ForeColor = System.Drawing.Color.White;
            this.NUD_congno.Maximum = new decimal(new int[] {
            -1530494977,
            232830,
            0,
            0});
            this.NUD_congno.Name = "NUD_congno";
            // 
            // TXB_tinhtrangxe
            // 
            resources.ApplyResources(this.TXB_tinhtrangxe, "TXB_tinhtrangxe");
            this.TXB_tinhtrangxe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_tinhtrangxe.ForeColor = System.Drawing.Color.White;
            this.TXB_tinhtrangxe.Name = "TXB_tinhtrangxe";
            this.TXB_tinhtrangxe.TextChanged += new System.EventHandler(this.TXB_tinhtrangxe_TextChanged);
            // 
            // LB_tinhtrangxe
            // 
            resources.ApplyResources(this.LB_tinhtrangxe, "LB_tinhtrangxe");
            this.LB_tinhtrangxe.ForeColor = System.Drawing.Color.White;
            this.LB_tinhtrangxe.Name = "LB_tinhtrangxe";
            // 
            // TXB_loaixe
            // 
            resources.ApplyResources(this.TXB_loaixe, "TXB_loaixe");
            this.TXB_loaixe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_loaixe.ForeColor = System.Drawing.Color.White;
            this.TXB_loaixe.Name = "TXB_loaixe";
            this.TXB_loaixe.TextChanged += new System.EventHandler(this.TXB_loaixe_TextChanged);
            // 
            // LB_loaixe
            // 
            resources.ApplyResources(this.LB_loaixe, "LB_loaixe");
            this.LB_loaixe.ForeColor = System.Drawing.Color.White;
            this.LB_loaixe.Name = "LB_loaixe";
            // 
            // LB_nguoithan
            // 
            resources.ApplyResources(this.LB_nguoithan, "LB_nguoithan");
            this.LB_nguoithan.ForeColor = System.Drawing.Color.White;
            this.LB_nguoithan.Name = "LB_nguoithan";
            // 
            // TXB_bienso
            // 
            resources.ApplyResources(this.TXB_bienso, "TXB_bienso");
            this.TXB_bienso.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_bienso.ForeColor = System.Drawing.Color.White;
            this.TXB_bienso.Name = "TXB_bienso";
            // 
            // LB_bienso
            // 
            resources.ApplyResources(this.LB_bienso, "LB_bienso");
            this.LB_bienso.ForeColor = System.Drawing.Color.White;
            this.LB_bienso.Name = "LB_bienso";
            // 
            // TXB_diennuoc
            // 
            resources.ApplyResources(this.TXB_diennuoc, "TXB_diennuoc");
            this.TXB_diennuoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_diennuoc.ForeColor = System.Drawing.Color.White;
            this.TXB_diennuoc.Name = "TXB_diennuoc";
            this.TXB_diennuoc.TextChanged += new System.EventHandler(this.TXB_diennuoc_TextChanged);
            // 
            // LB_diennuoc
            // 
            resources.ApplyResources(this.LB_diennuoc, "LB_diennuoc");
            this.LB_diennuoc.ForeColor = System.Drawing.Color.White;
            this.LB_diennuoc.Name = "LB_diennuoc";
            // 
            // DTP_di
            // 
            resources.ApplyResources(this.DTP_di, "DTP_di");
            this.DTP_di.Name = "DTP_di";
            // 
            // DTP_vao
            // 
            resources.ApplyResources(this.DTP_vao, "DTP_vao");
            this.DTP_vao.Name = "DTP_vao";
            // 
            // LB_di
            // 
            resources.ApplyResources(this.LB_di, "LB_di");
            this.LB_di.ForeColor = System.Drawing.Color.White;
            this.LB_di.Name = "LB_di";
            // 
            // DTP_bangiao
            // 
            resources.ApplyResources(this.DTP_bangiao, "DTP_bangiao");
            this.DTP_bangiao.Name = "DTP_bangiao";
            // 
            // DTP_ngaysinh
            // 
            resources.ApplyResources(this.DTP_ngaysinh, "DTP_ngaysinh");
            this.DTP_ngaysinh.Name = "DTP_ngaysinh";
            // 
            // LB_bangiao
            // 
            resources.ApplyResources(this.LB_bangiao, "LB_bangiao");
            this.LB_bangiao.ForeColor = System.Drawing.Color.White;
            this.LB_bangiao.Name = "LB_bangiao";
            // 
            // LB_macd
            // 
            resources.ApplyResources(this.LB_macd, "LB_macd");
            this.LB_macd.ForeColor = System.Drawing.Color.White;
            this.LB_macd.Name = "LB_macd";
            // 
            // TXB_macd
            // 
            resources.ApplyResources(this.TXB_macd, "TXB_macd");
            this.TXB_macd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_macd.ForeColor = System.Drawing.Color.White;
            this.TXB_macd.Name = "TXB_macd";
            this.TXB_macd.TextChanged += new System.EventHandler(this.TXB_macd_TextChanged);
            // 
            // LB_loaicudan
            // 
            resources.ApplyResources(this.LB_loaicudan, "LB_loaicudan");
            this.LB_loaicudan.ForeColor = System.Drawing.Color.White;
            this.LB_loaicudan.Name = "LB_loaicudan";
            // 
            // LB_quoctich
            // 
            resources.ApplyResources(this.LB_quoctich, "LB_quoctich");
            this.LB_quoctich.ForeColor = System.Drawing.Color.White;
            this.LB_quoctich.Name = "LB_quoctich";
            // 
            // TXB_quoctich
            // 
            resources.ApplyResources(this.TXB_quoctich, "TXB_quoctich");
            this.TXB_quoctich.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_quoctich.ForeColor = System.Drawing.Color.White;
            this.TXB_quoctich.Name = "TXB_quoctich";
            this.TXB_quoctich.TextChanged += new System.EventHandler(this.TXB_quoctich_TextChanged);
            // 
            // LB_thunuoi
            // 
            resources.ApplyResources(this.LB_thunuoi, "LB_thunuoi");
            this.LB_thunuoi.ForeColor = System.Drawing.Color.White;
            this.LB_thunuoi.Name = "LB_thunuoi";
            // 
            // TXB_thunuoi
            // 
            resources.ApplyResources(this.TXB_thunuoi, "TXB_thunuoi");
            this.TXB_thunuoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_thunuoi.ForeColor = System.Drawing.Color.White;
            this.TXB_thunuoi.Name = "TXB_thunuoi";
            // 
            // LB_congno
            // 
            resources.ApplyResources(this.LB_congno, "LB_congno");
            this.LB_congno.ForeColor = System.Drawing.Color.White;
            this.LB_congno.Name = "LB_congno";
            // 
            // LB_vao
            // 
            resources.ApplyResources(this.LB_vao, "LB_vao");
            this.LB_vao.ForeColor = System.Drawing.Color.White;
            this.LB_vao.Name = "LB_vao";
            // 
            // LB_email
            // 
            resources.ApplyResources(this.LB_email, "LB_email");
            this.LB_email.ForeColor = System.Drawing.Color.White;
            this.LB_email.Name = "LB_email";
            // 
            // TXB_email
            // 
            resources.ApplyResources(this.TXB_email, "TXB_email");
            this.TXB_email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_email.ForeColor = System.Drawing.Color.White;
            this.TXB_email.Name = "TXB_email";
            this.TXB_email.TextChanged += new System.EventHandler(this.TXB_email_TextChanged);
            // 
            // LB_tamtru
            // 
            resources.ApplyResources(this.LB_tamtru, "LB_tamtru");
            this.LB_tamtru.ForeColor = System.Drawing.Color.White;
            this.LB_tamtru.Name = "LB_tamtru";
            // 
            // TXB_sothetamtru
            // 
            resources.ApplyResources(this.TXB_sothetamtru, "TXB_sothetamtru");
            this.TXB_sothetamtru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_sothetamtru.ForeColor = System.Drawing.Color.White;
            this.TXB_sothetamtru.Name = "TXB_sothetamtru";
            this.TXB_sothetamtru.TextChanged += new System.EventHandler(this.TXB_sothetamtru_TextChanged);
            // 
            // LB_sdt
            // 
            resources.ApplyResources(this.LB_sdt, "LB_sdt");
            this.LB_sdt.ForeColor = System.Drawing.Color.White;
            this.LB_sdt.Name = "LB_sdt";
            // 
            // TXB_sdt
            // 
            resources.ApplyResources(this.TXB_sdt, "TXB_sdt");
            this.TXB_sdt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_sdt.ForeColor = System.Drawing.Color.White;
            this.TXB_sdt.Name = "TXB_sdt";
            this.TXB_sdt.TextChanged += new System.EventHandler(this.TXB_sdt_TextChanged);
            // 
            // LB_dinhdanh
            // 
            resources.ApplyResources(this.LB_dinhdanh, "LB_dinhdanh");
            this.LB_dinhdanh.ForeColor = System.Drawing.Color.White;
            this.LB_dinhdanh.Name = "LB_dinhdanh";
            // 
            // TXB_madinhdanh
            // 
            resources.ApplyResources(this.TXB_madinhdanh, "TXB_madinhdanh");
            this.TXB_madinhdanh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_madinhdanh.ForeColor = System.Drawing.Color.White;
            this.TXB_madinhdanh.Name = "TXB_madinhdanh";
            this.TXB_madinhdanh.TextChanged += new System.EventHandler(this.TXB_madinhdanh_TextChanged);
            // 
            // LB_ngaysinh
            // 
            resources.ApplyResources(this.LB_ngaysinh, "LB_ngaysinh");
            this.LB_ngaysinh.ForeColor = System.Drawing.Color.White;
            this.LB_ngaysinh.Name = "LB_ngaysinh";
            // 
            // LB_hoten
            // 
            resources.ApplyResources(this.LB_hoten, "LB_hoten");
            this.LB_hoten.ForeColor = System.Drawing.Color.White;
            this.LB_hoten.Name = "LB_hoten";
            // 
            // TXB_hovaten
            // 
            resources.ApplyResources(this.TXB_hovaten, "TXB_hovaten");
            this.TXB_hovaten.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_hovaten.ForeColor = System.Drawing.Color.White;
            this.TXB_hovaten.Name = "TXB_hovaten";
            this.TXB_hovaten.TextChanged += new System.EventHandler(this.TXB_hovaten_TextChanged);
            // 
            // LB_macanho
            // 
            resources.ApplyResources(this.LB_macanho, "LB_macanho");
            this.LB_macanho.ForeColor = System.Drawing.Color.White;
            this.LB_macanho.Name = "LB_macanho";
            // 
            // TXB_macanho
            // 
            resources.ApplyResources(this.TXB_macanho, "TXB_macanho");
            this.TXB_macanho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_macanho.ForeColor = System.Drawing.Color.White;
            this.TXB_macanho.Name = "TXB_macanho";
            this.TXB_macanho.TextChanged += new System.EventHandler(this.TXB_macanho_TextChanged);
            // 
            // panel7
            // 
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.BackColor = System.Drawing.Color.Silver;
            this.panel7.Name = "panel7";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.numericUpDownExt4);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.numericUpDownExt5);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.numericUpDownExt6);
            this.panel1.Name = "panel1";
            // 
            // panel8
            // 
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.BackColor = System.Drawing.Color.Silver;
            this.panel8.Name = "panel8";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Name = "label13";
            // 
            // textBox3
            // 
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Name = "textBox3";
            // 
            // comboBox2
            // 
            resources.ApplyResources(this.comboBox2, "comboBox2");
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.comboBox2.ForeColor = System.Drawing.Color.White;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Name = "comboBox2";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Name = "label14";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Name = "label18";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Name = "label15";
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Name = "textBox4";
            // 
            // numericUpDownExt4
            // 
            resources.ApplyResources(this.numericUpDownExt4, "numericUpDownExt4");
            this.numericUpDownExt4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt4.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt4.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt4.Name = "numericUpDownExt4";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Name = "label16";
            // 
            // numericUpDownExt5
            // 
            resources.ApplyResources(this.numericUpDownExt5, "numericUpDownExt5");
            this.numericUpDownExt5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt5.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt5.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt5.Name = "numericUpDownExt5";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Name = "label17";
            // 
            // numericUpDownExt6
            // 
            resources.ApplyResources(this.numericUpDownExt6, "numericUpDownExt6");
            this.numericUpDownExt6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt6.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt6.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt6.Name = "numericUpDownExt6";
            // 
            // BTN_xoa
            // 
            resources.ApplyResources(this.BTN_xoa, "BTN_xoa");
            this.BTN_xoa.Animated = true;
            this.BTN_xoa.AnimationHoverSpeed = 0.2F;
            this.BTN_xoa.AnimationSpeed = 0.03F;
            this.BTN_xoa.BackColor = System.Drawing.Color.Transparent;
            this.BTN_xoa.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_xoa.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_xoa.BorderColor = System.Drawing.Color.Red;
            this.BTN_xoa.BorderSize = 1;
            this.BTN_xoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_xoa.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_xoa.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_xoa.ForeColor = System.Drawing.Color.Red;
            this.BTN_xoa.Image = null;
            this.BTN_xoa.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_xoa.Name = "BTN_xoa";
            this.BTN_xoa.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_xoa.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_xoa.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_xoa.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_xoa.OnHoverImage = null;
            this.BTN_xoa.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_xoa.Radius = 5;
            this.BTN_xoa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_xoa.Click += new System.EventHandler(this.BTN_xoa_Click);
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Name = "panel6";
            // 
            // BTN_luu
            // 
            resources.ApplyResources(this.BTN_luu, "BTN_luu");
            this.BTN_luu.Animated = true;
            this.BTN_luu.AnimationHoverSpeed = 0.5F;
            this.BTN_luu.AnimationSpeed = 0.03F;
            this.BTN_luu.BackColor = System.Drawing.Color.Transparent;
            this.BTN_luu.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(255)))));
            this.BTN_luu.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.BorderColor = System.Drawing.Color.Black;
            this.BTN_luu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_luu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_luu.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_luu.ForeColor = System.Drawing.Color.White;
            this.BTN_luu.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_luu.Image = null;
            this.BTN_luu.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_luu.Name = "BTN_luu";
            this.BTN_luu.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverImage = null;
            this.BTN_luu.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_luu.Radius = 5;
            this.BTN_luu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_luu.Click += new System.EventHandler(this.BTN_luu_Click);
            // 
            // BTN_thoat
            // 
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // ThongTinCuDan
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.BTN_xoa);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.BTN_luu);
            this.Controls.Add(this.BTN_thoat);
            this.Controls.Add(this.PN_hienthi);
            this.Controls.Add(this.LB_ttcd);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ThongTinCuDan";
            this.Load += new System.EventHandler(this.ThongTinCuDan_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TTCD_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TTCD_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TTCD_MouseUp);
            this.PN_hienthi.ResumeLayout(false);
            this.PN_hienthi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_congno)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label LB_ttcd;
        private System.Windows.Forms.Panel PN_hienthi;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox4;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt4;
        private System.Windows.Forms.Label label16;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt5;
        private System.Windows.Forms.Label label17;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt6;
        private System.Windows.Forms.Label LB_macanho;
        private System.Windows.Forms.TextBox TXB_macanho;
        private System.Windows.Forms.Label LB_congno;
        private System.Windows.Forms.Label LB_vao;
        private System.Windows.Forms.Label LB_email;
        private System.Windows.Forms.TextBox TXB_email;
        private System.Windows.Forms.Label LB_tamtru;
        private System.Windows.Forms.TextBox TXB_sothetamtru;
        private System.Windows.Forms.Label LB_sdt;
        private System.Windows.Forms.TextBox TXB_sdt;
        private System.Windows.Forms.Label LB_dinhdanh;
        private System.Windows.Forms.TextBox TXB_madinhdanh;
        private System.Windows.Forms.Label LB_ngaysinh;
        private System.Windows.Forms.Label LB_hoten;
        private System.Windows.Forms.TextBox TXB_hovaten;
        private System.Windows.Forms.Label LB_loaicudan;
        private System.Windows.Forms.Label LB_quoctich;
        private System.Windows.Forms.TextBox TXB_quoctich;
        private System.Windows.Forms.Label LB_thunuoi;
        private System.Windows.Forms.TextBox TXB_thunuoi;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
        private Guna.UI.WinForms.GunaGradientButton BTN_xoa;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI.WinForms.GunaGradientButton BTN_luu;
        private System.Windows.Forms.Label LB_macd;
        private System.Windows.Forms.TextBox TXB_macd;
        private System.Windows.Forms.Label LB_bangiao;
        private System.Windows.Forms.DateTimePicker DTP_bangiao;
        private System.Windows.Forms.DateTimePicker DTP_ngaysinh;
        private System.Windows.Forms.DateTimePicker DTP_di;
        private System.Windows.Forms.DateTimePicker DTP_vao;
        private System.Windows.Forms.Label LB_di;
        private System.Windows.Forms.Label LB_bienso;
        private System.Windows.Forms.TextBox TXB_diennuoc;
        private System.Windows.Forms.Label LB_diennuoc;
        private System.Windows.Forms.TextBox TXB_tinhtrangxe;
        private System.Windows.Forms.Label LB_tinhtrangxe;
        private System.Windows.Forms.TextBox TXB_loaixe;
        private System.Windows.Forms.Label LB_loaixe;
        private System.Windows.Forms.Label LB_nguoithan;
        private System.Windows.Forms.TextBox TXB_bienso;
        private System.Windows.Forms.NumericUpDown NUD_congno;
        private System.Windows.Forms.Label LB_etinhtrangxe;
        private System.Windows.Forms.Label LB_eloaixe;
        private System.Windows.Forms.Label LB_ediennuoc;
        private System.Windows.Forms.Label LB_etamtru;
        private System.Windows.Forms.Label LB_eemail;
        private System.Windows.Forms.Label LB_esdt;
        private System.Windows.Forms.Label LB_ecccd;
        private System.Windows.Forms.Label LB_equoctich;
        private System.Windows.Forms.Label LB_ehoten;
        private System.Windows.Forms.Label LB_emacd;
        private System.Windows.Forms.Label LB_eloaicd;
        private System.Windows.Forms.Label LB_emacanho;
        private System.Windows.Forms.ComboBox CBB_loaicd;
        private System.Windows.Forms.ComboBox CBB_nguoithan;
    }
}