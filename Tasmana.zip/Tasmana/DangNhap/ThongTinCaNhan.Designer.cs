﻿
namespace DangNhap
{
    partial class ThongTinCaNhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinCaNhan));
            this.TXB_bhxh = new System.Windows.Forms.TextBox();
            this.TXB_quequan = new System.Windows.Forms.TextBox();
            this.LB_quequan = new System.Windows.Forms.Label();
            this.LB_tamtru = new System.Windows.Forms.Label();
            this.LB_BHXH = new System.Windows.Forms.Label();
            this.LB_thuongtru = new System.Windows.Forms.Label();
            this.LB_id = new System.Windows.Forms.Label();
            this.TXB_cccd = new System.Windows.Forms.TextBox();
            this.TXB_tamtru = new System.Windows.Forms.TextBox();
            this.TXB_thuongtru = new System.Windows.Forms.TextBox();
            this.TXB_matkhau = new System.Windows.Forms.TextBox();
            this.TXB_manguoidung = new System.Windows.Forms.TextBox();
            this.LB_matkhau = new System.Windows.Forms.Label();
            this.LB_taikhoan = new System.Windows.Forms.Label();
            this.LB_honnhan = new System.Windows.Forms.Label();
            this.TXB_honnhan = new System.Windows.Forms.TextBox();
            this.LB_sdt = new System.Windows.Forms.Label();
            this.LB_email = new System.Windows.Forms.Label();
            this.TXB_sdt = new System.Windows.Forms.TextBox();
            this.TXB_email = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.LB_emk = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CHB_matkhau = new System.Windows.Forms.CheckBox();
            this.CHB_vohieuhoa = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.LB_ethuongtru = new System.Windows.Forms.Label();
            this.LB_equequan = new System.Windows.Forms.Label();
            this.LB_ebaohiem = new System.Windows.Forms.Label();
            this.LB_ecccd = new System.Windows.Forms.Label();
            this.LB_eemail = new System.Windows.Forms.Label();
            this.LB_esdt = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LB_ehdld = new System.Windows.Forms.Label();
            this.LB_eloainv = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.TXB_tinhtrangHDLD = new System.Windows.Forms.TextBox();
            this.CBB_loainv = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CBB_phongban = new System.Windows.Forms.ComboBox();
            this.CBB_nhom = new System.Windows.Forms.ComboBox();
            this.DTP_ngaykyHDLD = new System.Windows.Forms.DateTimePicker();
            this.DTP_ngayhetHDLD = new System.Windows.Forms.DateTimePicker();
            this.CHB_tunglanv = new System.Windows.Forms.CheckBox();
            this.LB_vitri = new System.Windows.Forms.Label();
            this.LB_manhom = new System.Windows.Forms.Label();
            this.LB_ngayhetHDLD = new System.Windows.Forms.Label();
            this.LB_HDLD = new System.Windows.Forms.Label();
            this.LB_ngaykyHDLD = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.LB_egioitinh = new System.Windows.Forms.Label();
            this.LB_ehonnhan = new System.Windows.Forms.Label();
            this.LB_eten = new System.Windows.Forms.Label();
            this.LB_eho = new System.Windows.Forms.Label();
            this.LB_emanv = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.TXB_ten = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DTP_ngaysinh = new System.Windows.Forms.DateTimePicker();
            this.GB_gioitinh = new System.Windows.Forms.GroupBox();
            this.Rad_nu = new System.Windows.Forms.RadioButton();
            this.Rad_nam = new System.Windows.Forms.RadioButton();
            this.TXB_ho = new System.Windows.Forms.TextBox();
            this.TXB_manv = new System.Windows.Forms.TextBox();
            this.LB_hovaten = new System.Windows.Forms.Label();
            this.LB_manv = new System.Windows.Forms.Label();
            this.LB_ngaysinh = new System.Windows.Forms.Label();
            this.BTN_luu = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.BTN_x = new Guna.UI.WinForms.GunaGradientButton();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.GB_gioitinh.SuspendLayout();
            this.SuspendLayout();
            // 
            // TXB_bhxh
            // 
            this.TXB_bhxh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_bhxh, "TXB_bhxh");
            this.TXB_bhxh.ForeColor = System.Drawing.Color.White;
            this.TXB_bhxh.Name = "TXB_bhxh";
            this.TXB_bhxh.TextChanged += new System.EventHandler(this.TXB_bhxh_TextChanged);
            // 
            // TXB_quequan
            // 
            this.TXB_quequan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_quequan, "TXB_quequan");
            this.TXB_quequan.ForeColor = System.Drawing.Color.White;
            this.TXB_quequan.Name = "TXB_quequan";
            this.TXB_quequan.TextChanged += new System.EventHandler(this.TXB_quequan_TextChanged);
            // 
            // LB_quequan
            // 
            resources.ApplyResources(this.LB_quequan, "LB_quequan");
            this.LB_quequan.ForeColor = System.Drawing.Color.White;
            this.LB_quequan.Name = "LB_quequan";
            // 
            // LB_tamtru
            // 
            resources.ApplyResources(this.LB_tamtru, "LB_tamtru");
            this.LB_tamtru.ForeColor = System.Drawing.Color.White;
            this.LB_tamtru.Name = "LB_tamtru";
            // 
            // LB_BHXH
            // 
            resources.ApplyResources(this.LB_BHXH, "LB_BHXH");
            this.LB_BHXH.ForeColor = System.Drawing.Color.White;
            this.LB_BHXH.Name = "LB_BHXH";
            // 
            // LB_thuongtru
            // 
            resources.ApplyResources(this.LB_thuongtru, "LB_thuongtru");
            this.LB_thuongtru.ForeColor = System.Drawing.Color.White;
            this.LB_thuongtru.Name = "LB_thuongtru";
            // 
            // LB_id
            // 
            resources.ApplyResources(this.LB_id, "LB_id");
            this.LB_id.ForeColor = System.Drawing.Color.White;
            this.LB_id.Name = "LB_id";
            // 
            // TXB_cccd
            // 
            this.TXB_cccd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_cccd, "TXB_cccd");
            this.TXB_cccd.ForeColor = System.Drawing.Color.White;
            this.TXB_cccd.Name = "TXB_cccd";
            this.TXB_cccd.TextChanged += new System.EventHandler(this.TXB_cccd_TextChanged);
            // 
            // TXB_tamtru
            // 
            this.TXB_tamtru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_tamtru, "TXB_tamtru");
            this.TXB_tamtru.ForeColor = System.Drawing.Color.White;
            this.TXB_tamtru.Name = "TXB_tamtru";
            // 
            // TXB_thuongtru
            // 
            this.TXB_thuongtru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_thuongtru, "TXB_thuongtru");
            this.TXB_thuongtru.ForeColor = System.Drawing.Color.White;
            this.TXB_thuongtru.Name = "TXB_thuongtru";
            this.TXB_thuongtru.TextChanged += new System.EventHandler(this.TXB_thuongtru_TextChanged);
            // 
            // TXB_matkhau
            // 
            this.TXB_matkhau.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_matkhau, "TXB_matkhau");
            this.TXB_matkhau.ForeColor = System.Drawing.Color.White;
            this.TXB_matkhau.Name = "TXB_matkhau";
            this.TXB_matkhau.TextChanged += new System.EventHandler(this.TXB_matkhau_TextChanged);
            // 
            // TXB_manguoidung
            // 
            this.TXB_manguoidung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_manguoidung, "TXB_manguoidung");
            this.TXB_manguoidung.ForeColor = System.Drawing.Color.White;
            this.TXB_manguoidung.Name = "TXB_manguoidung";
            // 
            // LB_matkhau
            // 
            resources.ApplyResources(this.LB_matkhau, "LB_matkhau");
            this.LB_matkhau.ForeColor = System.Drawing.Color.White;
            this.LB_matkhau.Name = "LB_matkhau";
            // 
            // LB_taikhoan
            // 
            resources.ApplyResources(this.LB_taikhoan, "LB_taikhoan");
            this.LB_taikhoan.ForeColor = System.Drawing.Color.White;
            this.LB_taikhoan.Name = "LB_taikhoan";
            // 
            // LB_honnhan
            // 
            resources.ApplyResources(this.LB_honnhan, "LB_honnhan");
            this.LB_honnhan.ForeColor = System.Drawing.Color.White;
            this.LB_honnhan.Name = "LB_honnhan";
            // 
            // TXB_honnhan
            // 
            this.TXB_honnhan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_honnhan, "TXB_honnhan");
            this.TXB_honnhan.ForeColor = System.Drawing.Color.White;
            this.TXB_honnhan.Name = "TXB_honnhan";
            this.TXB_honnhan.TextChanged += new System.EventHandler(this.TXB_honnhan_TextChanged);
            // 
            // LB_sdt
            // 
            resources.ApplyResources(this.LB_sdt, "LB_sdt");
            this.LB_sdt.ForeColor = System.Drawing.Color.White;
            this.LB_sdt.Name = "LB_sdt";
            // 
            // LB_email
            // 
            resources.ApplyResources(this.LB_email, "LB_email");
            this.LB_email.ForeColor = System.Drawing.Color.White;
            this.LB_email.Name = "LB_email";
            // 
            // TXB_sdt
            // 
            this.TXB_sdt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_sdt, "TXB_sdt");
            this.TXB_sdt.ForeColor = System.Drawing.Color.White;
            this.TXB_sdt.Name = "TXB_sdt";
            this.TXB_sdt.TextChanged += new System.EventHandler(this.TXB_sdt_TextChanged);
            // 
            // TXB_email
            // 
            this.TXB_email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_email, "TXB_email");
            this.TXB_email.ForeColor = System.Drawing.Color.White;
            this.TXB_email.Name = "TXB_email";
            this.TXB_email.TextChanged += new System.EventHandler(this.TXB_email_TextChanged);
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Name = "panel5";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel6.Controls.Add(this.LB_emk);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Controls.Add(this.CHB_matkhau);
            this.panel6.Controls.Add(this.CHB_vohieuhoa);
            this.panel6.Controls.Add(this.TXB_matkhau);
            this.panel6.Controls.Add(this.TXB_manguoidung);
            this.panel6.Controls.Add(this.LB_taikhoan);
            this.panel6.Controls.Add(this.LB_matkhau);
            this.panel6.Name = "panel6";
            // 
            // LB_emk
            // 
            resources.ApplyResources(this.LB_emk, "LB_emk");
            this.LB_emk.ForeColor = System.Drawing.Color.Red;
            this.LB_emk.Name = "LB_emk";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Name = "label5";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.Name = "panel9";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Name = "panel8";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // CHB_matkhau
            // 
            resources.ApplyResources(this.CHB_matkhau, "CHB_matkhau");
            this.CHB_matkhau.ForeColor = System.Drawing.Color.White;
            this.CHB_matkhau.Name = "CHB_matkhau";
            this.CHB_matkhau.UseVisualStyleBackColor = true;
            this.CHB_matkhau.CheckedChanged += new System.EventHandler(this.CHB_matkhau_CheckedChanged);
            // 
            // CHB_vohieuhoa
            // 
            resources.ApplyResources(this.CHB_vohieuhoa, "CHB_vohieuhoa");
            this.CHB_vohieuhoa.ForeColor = System.Drawing.Color.Red;
            this.CHB_vohieuhoa.Name = "CHB_vohieuhoa";
            this.CHB_vohieuhoa.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel4.Controls.Add(this.LB_ethuongtru);
            this.panel4.Controls.Add(this.LB_equequan);
            this.panel4.Controls.Add(this.LB_ebaohiem);
            this.panel4.Controls.Add(this.LB_ecccd);
            this.panel4.Controls.Add(this.LB_eemail);
            this.panel4.Controls.Add(this.LB_esdt);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.panel18);
            this.panel4.Controls.Add(this.panel19);
            this.panel4.Controls.Add(this.panel20);
            this.panel4.Controls.Add(this.panel21);
            this.panel4.Controls.Add(this.TXB_bhxh);
            this.panel4.Controls.Add(this.LB_sdt);
            this.panel4.Controls.Add(this.TXB_quequan);
            this.panel4.Controls.Add(this.TXB_email);
            this.panel4.Controls.Add(this.LB_quequan);
            this.panel4.Controls.Add(this.LB_tamtru);
            this.panel4.Controls.Add(this.LB_email);
            this.panel4.Controls.Add(this.LB_BHXH);
            this.panel4.Controls.Add(this.TXB_sdt);
            this.panel4.Controls.Add(this.LB_thuongtru);
            this.panel4.Controls.Add(this.TXB_thuongtru);
            this.panel4.Controls.Add(this.LB_id);
            this.panel4.Controls.Add(this.TXB_tamtru);
            this.panel4.Controls.Add(this.TXB_cccd);
            this.panel4.Name = "panel4";
            // 
            // LB_ethuongtru
            // 
            resources.ApplyResources(this.LB_ethuongtru, "LB_ethuongtru");
            this.LB_ethuongtru.ForeColor = System.Drawing.Color.Red;
            this.LB_ethuongtru.Name = "LB_ethuongtru";
            // 
            // LB_equequan
            // 
            resources.ApplyResources(this.LB_equequan, "LB_equequan");
            this.LB_equequan.ForeColor = System.Drawing.Color.Red;
            this.LB_equequan.Name = "LB_equequan";
            // 
            // LB_ebaohiem
            // 
            resources.ApplyResources(this.LB_ebaohiem, "LB_ebaohiem");
            this.LB_ebaohiem.ForeColor = System.Drawing.Color.Red;
            this.LB_ebaohiem.Name = "LB_ebaohiem";
            // 
            // LB_ecccd
            // 
            resources.ApplyResources(this.LB_ecccd, "LB_ecccd");
            this.LB_ecccd.ForeColor = System.Drawing.Color.Red;
            this.LB_ecccd.Name = "LB_ecccd";
            // 
            // LB_eemail
            // 
            resources.ApplyResources(this.LB_eemail, "LB_eemail");
            this.LB_eemail.ForeColor = System.Drawing.Color.Red;
            this.LB_eemail.Name = "LB_eemail";
            // 
            // LB_esdt
            // 
            resources.ApplyResources(this.LB_esdt, "LB_esdt");
            this.LB_esdt.ForeColor = System.Drawing.Color.Red;
            this.LB_esdt.Name = "LB_esdt";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel18, "panel18");
            this.panel18.Name = "panel18";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel19, "panel19");
            this.panel19.Name = "panel19";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel20, "panel20");
            this.panel20.Name = "panel20";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel21, "panel21");
            this.panel21.Name = "panel21";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.LB_ehdld);
            this.panel1.Controls.Add(this.LB_eloainv);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.panel16);
            this.panel1.Controls.Add(this.panel17);
            this.panel1.Controls.Add(this.TXB_tinhtrangHDLD);
            this.panel1.Controls.Add(this.CBB_loainv);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.CBB_phongban);
            this.panel1.Controls.Add(this.CBB_nhom);
            this.panel1.Controls.Add(this.DTP_ngaykyHDLD);
            this.panel1.Controls.Add(this.DTP_ngayhetHDLD);
            this.panel1.Controls.Add(this.CHB_tunglanv);
            this.panel1.Controls.Add(this.LB_vitri);
            this.panel1.Controls.Add(this.LB_manhom);
            this.panel1.Controls.Add(this.LB_ngayhetHDLD);
            this.panel1.Controls.Add(this.LB_HDLD);
            this.panel1.Controls.Add(this.LB_ngaykyHDLD);
            this.panel1.Name = "panel1";
            // 
            // LB_ehdld
            // 
            resources.ApplyResources(this.LB_ehdld, "LB_ehdld");
            this.LB_ehdld.ForeColor = System.Drawing.Color.Red;
            this.LB_ehdld.Name = "LB_ehdld";
            // 
            // LB_eloainv
            // 
            resources.ApplyResources(this.LB_eloainv, "LB_eloainv");
            this.LB_eloainv.ForeColor = System.Drawing.Color.Red;
            this.LB_eloainv.Name = "LB_eloainv";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel14, "panel14");
            this.panel14.Name = "panel14";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel15, "panel15");
            this.panel15.Name = "panel15";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel16, "panel16");
            this.panel16.Name = "panel16";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel17, "panel17");
            this.panel17.Name = "panel17";
            // 
            // TXB_tinhtrangHDLD
            // 
            this.TXB_tinhtrangHDLD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_tinhtrangHDLD, "TXB_tinhtrangHDLD");
            this.TXB_tinhtrangHDLD.ForeColor = System.Drawing.Color.White;
            this.TXB_tinhtrangHDLD.Name = "TXB_tinhtrangHDLD";
            this.TXB_tinhtrangHDLD.TextChanged += new System.EventHandler(this.TXB_tinhtrangHDLD_TextChanged);
            // 
            // CBB_loainv
            // 
            this.CBB_loainv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.CBB_loainv, "CBB_loainv");
            this.CBB_loainv.ForeColor = System.Drawing.Color.White;
            this.CBB_loainv.FormattingEnabled = true;
            this.CBB_loainv.Name = "CBB_loainv";
            this.CBB_loainv.SelectedIndexChanged += new System.EventHandler(this.CBB_loainv_SelectedIndexChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // CBB_phongban
            // 
            this.CBB_phongban.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.CBB_phongban, "CBB_phongban");
            this.CBB_phongban.ForeColor = System.Drawing.Color.White;
            this.CBB_phongban.FormattingEnabled = true;
            this.CBB_phongban.Name = "CBB_phongban";
            this.CBB_phongban.SelectedIndexChanged += new System.EventHandler(this.CBB_phongban_SelectedIndexChanged);
            // 
            // CBB_nhom
            // 
            this.CBB_nhom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.CBB_nhom, "CBB_nhom");
            this.CBB_nhom.ForeColor = System.Drawing.Color.White;
            this.CBB_nhom.FormattingEnabled = true;
            this.CBB_nhom.Name = "CBB_nhom";
            // 
            // DTP_ngaykyHDLD
            // 
            resources.ApplyResources(this.DTP_ngaykyHDLD, "DTP_ngaykyHDLD");
            this.DTP_ngaykyHDLD.Name = "DTP_ngaykyHDLD";
            // 
            // DTP_ngayhetHDLD
            // 
            resources.ApplyResources(this.DTP_ngayhetHDLD, "DTP_ngayhetHDLD");
            this.DTP_ngayhetHDLD.Name = "DTP_ngayhetHDLD";
            // 
            // CHB_tunglanv
            // 
            resources.ApplyResources(this.CHB_tunglanv, "CHB_tunglanv");
            this.CHB_tunglanv.ForeColor = System.Drawing.Color.White;
            this.CHB_tunglanv.Name = "CHB_tunglanv";
            this.CHB_tunglanv.UseVisualStyleBackColor = true;
            // 
            // LB_vitri
            // 
            resources.ApplyResources(this.LB_vitri, "LB_vitri");
            this.LB_vitri.ForeColor = System.Drawing.Color.White;
            this.LB_vitri.Name = "LB_vitri";
            // 
            // LB_manhom
            // 
            resources.ApplyResources(this.LB_manhom, "LB_manhom");
            this.LB_manhom.ForeColor = System.Drawing.Color.White;
            this.LB_manhom.Name = "LB_manhom";
            // 
            // LB_ngayhetHDLD
            // 
            resources.ApplyResources(this.LB_ngayhetHDLD, "LB_ngayhetHDLD");
            this.LB_ngayhetHDLD.ForeColor = System.Drawing.Color.White;
            this.LB_ngayhetHDLD.Name = "LB_ngayhetHDLD";
            // 
            // LB_HDLD
            // 
            resources.ApplyResources(this.LB_HDLD, "LB_HDLD");
            this.LB_HDLD.ForeColor = System.Drawing.Color.White;
            this.LB_HDLD.Name = "LB_HDLD";
            // 
            // LB_ngaykyHDLD
            // 
            resources.ApplyResources(this.LB_ngaykyHDLD, "LB_ngaykyHDLD");
            this.LB_ngaykyHDLD.ForeColor = System.Drawing.Color.White;
            this.LB_ngaykyHDLD.Name = "LB_ngaykyHDLD";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.panel3.Controls.Add(this.LB_egioitinh);
            this.panel3.Controls.Add(this.LB_ehonnhan);
            this.panel3.Controls.Add(this.LB_eten);
            this.panel3.Controls.Add(this.LB_eho);
            this.panel3.Controls.Add(this.LB_emanv);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.panel13);
            this.panel3.Controls.Add(this.TXB_ten);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.DTP_ngaysinh);
            this.panel3.Controls.Add(this.GB_gioitinh);
            this.panel3.Controls.Add(this.TXB_ho);
            this.panel3.Controls.Add(this.TXB_manv);
            this.panel3.Controls.Add(this.LB_hovaten);
            this.panel3.Controls.Add(this.LB_manv);
            this.panel3.Controls.Add(this.LB_honnhan);
            this.panel3.Controls.Add(this.TXB_honnhan);
            this.panel3.Controls.Add(this.LB_ngaysinh);
            this.panel3.Name = "panel3";
            // 
            // LB_egioitinh
            // 
            resources.ApplyResources(this.LB_egioitinh, "LB_egioitinh");
            this.LB_egioitinh.ForeColor = System.Drawing.Color.Red;
            this.LB_egioitinh.Name = "LB_egioitinh";
            // 
            // LB_ehonnhan
            // 
            resources.ApplyResources(this.LB_ehonnhan, "LB_ehonnhan");
            this.LB_ehonnhan.ForeColor = System.Drawing.Color.Red;
            this.LB_ehonnhan.Name = "LB_ehonnhan";
            // 
            // LB_eten
            // 
            resources.ApplyResources(this.LB_eten, "LB_eten");
            this.LB_eten.ForeColor = System.Drawing.Color.Red;
            this.LB_eten.Name = "LB_eten";
            // 
            // LB_eho
            // 
            resources.ApplyResources(this.LB_eho, "LB_eho");
            this.LB_eho.ForeColor = System.Drawing.Color.Red;
            this.LB_eho.Name = "LB_eho";
            // 
            // LB_emanv
            // 
            resources.ApplyResources(this.LB_emanv, "LB_emanv");
            this.LB_emanv.ForeColor = System.Drawing.Color.Red;
            this.LB_emanv.Name = "LB_emanv";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Name = "label7";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel10, "panel10");
            this.panel10.Name = "panel10";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel11, "panel11");
            this.panel11.Name = "panel11";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel12, "panel12");
            this.panel12.Name = "panel12";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel13, "panel13");
            this.panel13.Name = "panel13";
            // 
            // TXB_ten
            // 
            this.TXB_ten.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_ten, "TXB_ten");
            this.TXB_ten.ForeColor = System.Drawing.Color.White;
            this.TXB_ten.Name = "TXB_ten";
            this.TXB_ten.TextChanged += new System.EventHandler(this.TXB_ten_TextChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // DTP_ngaysinh
            // 
            resources.ApplyResources(this.DTP_ngaysinh, "DTP_ngaysinh");
            this.DTP_ngaysinh.Name = "DTP_ngaysinh";
            // 
            // GB_gioitinh
            // 
            this.GB_gioitinh.Controls.Add(this.Rad_nu);
            this.GB_gioitinh.Controls.Add(this.Rad_nam);
            resources.ApplyResources(this.GB_gioitinh, "GB_gioitinh");
            this.GB_gioitinh.ForeColor = System.Drawing.Color.White;
            this.GB_gioitinh.Name = "GB_gioitinh";
            this.GB_gioitinh.TabStop = false;
            // 
            // Rad_nu
            // 
            resources.ApplyResources(this.Rad_nu, "Rad_nu");
            this.Rad_nu.ForeColor = System.Drawing.Color.White;
            this.Rad_nu.Name = "Rad_nu";
            this.Rad_nu.TabStop = true;
            this.Rad_nu.UseVisualStyleBackColor = true;
            this.Rad_nu.CheckedChanged += new System.EventHandler(this.Rad_nu_CheckedChanged);
            // 
            // Rad_nam
            // 
            resources.ApplyResources(this.Rad_nam, "Rad_nam");
            this.Rad_nam.ForeColor = System.Drawing.Color.White;
            this.Rad_nam.Name = "Rad_nam";
            this.Rad_nam.TabStop = true;
            this.Rad_nam.UseVisualStyleBackColor = true;
            this.Rad_nam.CheckedChanged += new System.EventHandler(this.Rad_nam_CheckedChanged);
            // 
            // TXB_ho
            // 
            this.TXB_ho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_ho, "TXB_ho");
            this.TXB_ho.ForeColor = System.Drawing.Color.White;
            this.TXB_ho.Name = "TXB_ho";
            this.TXB_ho.TextChanged += new System.EventHandler(this.TXB_ho_TextChanged);
            // 
            // TXB_manv
            // 
            this.TXB_manv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            resources.ApplyResources(this.TXB_manv, "TXB_manv");
            this.TXB_manv.ForeColor = System.Drawing.Color.White;
            this.TXB_manv.Name = "TXB_manv";
            this.TXB_manv.TextChanged += new System.EventHandler(this.TXB_manv_TextChanged);
            // 
            // LB_hovaten
            // 
            resources.ApplyResources(this.LB_hovaten, "LB_hovaten");
            this.LB_hovaten.ForeColor = System.Drawing.Color.White;
            this.LB_hovaten.Name = "LB_hovaten";
            // 
            // LB_manv
            // 
            resources.ApplyResources(this.LB_manv, "LB_manv");
            this.LB_manv.ForeColor = System.Drawing.Color.White;
            this.LB_manv.Name = "LB_manv";
            // 
            // LB_ngaysinh
            // 
            resources.ApplyResources(this.LB_ngaysinh, "LB_ngaysinh");
            this.LB_ngaysinh.ForeColor = System.Drawing.Color.White;
            this.LB_ngaysinh.Name = "LB_ngaysinh";
            // 
            // BTN_luu
            // 
            resources.ApplyResources(this.BTN_luu, "BTN_luu");
            this.BTN_luu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BTN_luu.FlatAppearance.BorderSize = 0;
            this.BTN_luu.ForeColor = System.Drawing.Color.White;
            this.BTN_luu.Name = "BTN_luu";
            this.BTN_luu.UseVisualStyleBackColor = false;
            this.BTN_luu.Click += new System.EventHandler(this.BTN_luu_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel22, "panel22");
            this.panel22.Name = "panel22";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel23, "panel23");
            this.panel23.Name = "panel23";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel24, "panel24");
            this.panel24.Name = "panel24";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel25, "panel25");
            this.panel25.Name = "panel25";
            // 
            // BTN_x
            // 
            resources.ApplyResources(this.BTN_x, "BTN_x");
            this.BTN_x.AnimationHoverSpeed = 1F;
            this.BTN_x.AnimationSpeed = 1F;
            this.BTN_x.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_x.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_x.BorderColor = System.Drawing.Color.Black;
            this.BTN_x.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_x.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_x.ForeColor = System.Drawing.Color.Black;
            this.BTN_x.Image = ((System.Drawing.Image)(resources.GetObject("BTN_x.Image")));
            this.BTN_x.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_x.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_x.Name = "BTN_x";
            this.BTN_x.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_x.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_x.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_x.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_x.OnHoverImage = null;
            this.BTN_x.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_x.Click += new System.EventHandler(this.BTN_x_Click);
            // 
            // ThongTinCaNhan
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel25);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BTN_luu);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.BTN_x);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ThongTinCaNhan";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ThongTinCaNhan_FormClosing);
            this.Load += new System.EventHandler(this.ThongTinCaNhan_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ThongTinCaNhan_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ThongTinCaNhan_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ThongTinCaNhan_MouseUp);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.GB_gioitinh.ResumeLayout(false);
            this.GB_gioitinh.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TXB_matkhau;
        private System.Windows.Forms.TextBox TXB_manguoidung;
        private System.Windows.Forms.Label LB_matkhau;
        private System.Windows.Forms.Label LB_taikhoan;
        private System.Windows.Forms.Label LB_honnhan;
        private System.Windows.Forms.TextBox TXB_honnhan;
        private System.Windows.Forms.Label LB_sdt;
        private System.Windows.Forms.Label LB_email;
        private System.Windows.Forms.TextBox TXB_sdt;
        private System.Windows.Forms.TextBox TXB_email;
        private System.Windows.Forms.TextBox TXB_bhxh;
        private System.Windows.Forms.TextBox TXB_quequan;
        private System.Windows.Forms.Label LB_quequan;
        private System.Windows.Forms.Label LB_tamtru;
        private System.Windows.Forms.Label LB_BHXH;
        private System.Windows.Forms.Label LB_thuongtru;
        private System.Windows.Forms.Label LB_id;
        private System.Windows.Forms.TextBox TXB_cccd;
        private System.Windows.Forms.TextBox TXB_tamtru;
        private System.Windows.Forms.TextBox TXB_thuongtru;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LB_vitri;
        private System.Windows.Forms.Label LB_manhom;
        private System.Windows.Forms.Label LB_ngayhetHDLD;
        private System.Windows.Forms.Label LB_HDLD;
        private System.Windows.Forms.Label LB_manv;
        private System.Windows.Forms.Label LB_ngaykyHDLD;
        private System.Windows.Forms.Label LB_ngaysinh;
        private System.Windows.Forms.Label LB_hovaten;
        private System.Windows.Forms.TextBox TXB_manv;
        private System.Windows.Forms.TextBox TXB_ho;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button BTN_luu;
        private System.Windows.Forms.CheckBox CHB_tunglanv;
        private System.Windows.Forms.RadioButton Rad_nam;
        private System.Windows.Forms.GroupBox GB_gioitinh;
        private System.Windows.Forms.RadioButton Rad_nu;
        private System.Windows.Forms.DateTimePicker DTP_ngaysinh;
        private System.Windows.Forms.DateTimePicker DTP_ngayhetHDLD;
        private System.Windows.Forms.DateTimePicker DTP_ngaykyHDLD;
        private System.Windows.Forms.TextBox TXB_ten;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox CBB_phongban;
        private System.Windows.Forms.ComboBox CBB_nhom;
        private System.Windows.Forms.ComboBox CBB_loainv;
        private System.Windows.Forms.TextBox TXB_tinhtrangHDLD;
        private System.Windows.Forms.CheckBox CHB_vohieuhoa;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox CHB_matkhau;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private Guna.UI.WinForms.GunaGradientButton BTN_x;
        private System.Windows.Forms.Label LB_emk;
        private System.Windows.Forms.Label LB_ethuongtru;
        private System.Windows.Forms.Label LB_equequan;
        private System.Windows.Forms.Label LB_ebaohiem;
        private System.Windows.Forms.Label LB_ecccd;
        private System.Windows.Forms.Label LB_eemail;
        private System.Windows.Forms.Label LB_esdt;
        private System.Windows.Forms.Label LB_ehdld;
        private System.Windows.Forms.Label LB_eloainv;
        private System.Windows.Forms.Label LB_egioitinh;
        private System.Windows.Forms.Label LB_ehonnhan;
        private System.Windows.Forms.Label LB_eten;
        private System.Windows.Forms.Label LB_eho;
        private System.Windows.Forms.Label LB_emanv;
    }
}