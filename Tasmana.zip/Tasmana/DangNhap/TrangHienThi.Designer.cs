﻿namespace DangNhap
{
    partial class TrangHienThi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangHienThi));
            this.panel1 = new System.Windows.Forms.Panel();
            this.LB_SoCV_CoCapNhat = new System.Windows.Forms.Label();
            this.LB_CapNhat = new System.Windows.Forms.Label();
            this.gunaCirclePictureBox4 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.LB_SoCV_TreHan = new System.Windows.Forms.Label();
            this.LB_SoCV_DangTienHanh = new System.Windows.Forms.Label();
            this.LB_SoCongViecCBD = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.gunaCirclePictureBox3 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox2 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LB_chuabatdau = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BTN_nhanvien = new Guna.UI.WinForms.GunaButton();
            this.BTN_congviec = new Guna.UI.WinForms.GunaButton();
            this.BTN_cudan = new Guna.UI.WinForms.GunaButton();
            this.BTN_thongbao = new Guna.UI.WinForms.GunaButton();
            this.BTN_canho = new Guna.UI.WinForms.GunaButton();
            this.BTN_logout = new Guna.UI.WinForms.GunaButton();
            this.BTN_thongke = new Guna.UI.WinForms.GunaButton();
            this.P_logotasmana = new Guna.UI.WinForms.GunaPictureBox();
            this.LB_tendangnhap = new System.Windows.Forms.Label();
            this.Timer_KTCongViec = new System.Windows.Forms.Timer(this.components);
            this.NTFIcon_ThongBaoCV = new System.Windows.Forms.NotifyIcon(this.components);
            this.PN_main = new System.Windows.Forms.Panel();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.PB_question = new System.Windows.Forms.PictureBox();
            this.PB_language = new System.Windows.Forms.PictureBox();
            this.gunaGradientButton1 = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_thongtin = new Guna.UI.WinForms.GunaButton();
            this.BTN_square = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_x = new Guna.UI.WinForms.GunaGradientButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P_logotasmana)).BeginInit();
            this.PN_main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_question)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_language)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(20)))), ((int)(((byte)(21)))));
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.LB_SoCV_CoCapNhat);
            this.panel1.Controls.Add(this.LB_CapNhat);
            this.panel1.Controls.Add(this.gunaCirclePictureBox4);
            this.panel1.Controls.Add(this.LB_SoCV_TreHan);
            this.panel1.Controls.Add(this.LB_SoCV_DangTienHanh);
            this.panel1.Controls.Add(this.LB_SoCongViecCBD);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.gunaCirclePictureBox3);
            this.panel1.Controls.Add(this.gunaCirclePictureBox2);
            this.panel1.Controls.Add(this.gunaCirclePictureBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.LB_chuabatdau);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.BTN_nhanvien);
            this.panel1.Controls.Add(this.BTN_congviec);
            this.panel1.Controls.Add(this.BTN_cudan);
            this.panel1.Controls.Add(this.BTN_thongbao);
            this.panel1.Controls.Add(this.BTN_canho);
            this.panel1.Controls.Add(this.BTN_logout);
            this.panel1.Controls.Add(this.BTN_thongke);
            this.panel1.Controls.Add(this.P_logotasmana);
            this.panel1.Name = "panel1";
            // 
            // LB_SoCV_CoCapNhat
            // 
            resources.ApplyResources(this.LB_SoCV_CoCapNhat, "LB_SoCV_CoCapNhat");
            this.LB_SoCV_CoCapNhat.ForeColor = System.Drawing.Color.White;
            this.LB_SoCV_CoCapNhat.Name = "LB_SoCV_CoCapNhat";
            // 
            // LB_CapNhat
            // 
            resources.ApplyResources(this.LB_CapNhat, "LB_CapNhat");
            this.LB_CapNhat.ForeColor = System.Drawing.Color.White;
            this.LB_CapNhat.Name = "LB_CapNhat";
            // 
            // gunaCirclePictureBox4
            // 
            this.gunaCirclePictureBox4.BaseColor = System.Drawing.Color.Orange;
            resources.ApplyResources(this.gunaCirclePictureBox4, "gunaCirclePictureBox4");
            this.gunaCirclePictureBox4.Name = "gunaCirclePictureBox4";
            this.gunaCirclePictureBox4.TabStop = false;
            this.gunaCirclePictureBox4.UseTransfarantBackground = false;
            // 
            // LB_SoCV_TreHan
            // 
            resources.ApplyResources(this.LB_SoCV_TreHan, "LB_SoCV_TreHan");
            this.LB_SoCV_TreHan.ForeColor = System.Drawing.Color.White;
            this.LB_SoCV_TreHan.Name = "LB_SoCV_TreHan";
            // 
            // LB_SoCV_DangTienHanh
            // 
            resources.ApplyResources(this.LB_SoCV_DangTienHanh, "LB_SoCV_DangTienHanh");
            this.LB_SoCV_DangTienHanh.ForeColor = System.Drawing.Color.White;
            this.LB_SoCV_DangTienHanh.Name = "LB_SoCV_DangTienHanh";
            // 
            // LB_SoCongViecCBD
            // 
            resources.ApplyResources(this.LB_SoCongViecCBD, "LB_SoCongViecCBD");
            this.LB_SoCongViecCBD.ForeColor = System.Drawing.Color.White;
            this.LB_SoCongViecCBD.Name = "LB_SoCongViecCBD";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label4.Name = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // panel9
            // 
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel9.Name = "panel9";
            // 
            // gunaCirclePictureBox3
            // 
            this.gunaCirclePictureBox3.BaseColor = System.Drawing.Color.Lime;
            resources.ApplyResources(this.gunaCirclePictureBox3, "gunaCirclePictureBox3");
            this.gunaCirclePictureBox3.Name = "gunaCirclePictureBox3";
            this.gunaCirclePictureBox3.TabStop = false;
            this.gunaCirclePictureBox3.UseTransfarantBackground = false;
            // 
            // gunaCirclePictureBox2
            // 
            this.gunaCirclePictureBox2.BaseColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.gunaCirclePictureBox2, "gunaCirclePictureBox2");
            this.gunaCirclePictureBox2.Name = "gunaCirclePictureBox2";
            this.gunaCirclePictureBox2.TabStop = false;
            this.gunaCirclePictureBox2.UseTransfarantBackground = false;
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.gunaCirclePictureBox1, "gunaCirclePictureBox1");
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // LB_chuabatdau
            // 
            resources.ApplyResources(this.LB_chuabatdau, "LB_chuabatdau");
            this.LB_chuabatdau.ForeColor = System.Drawing.Color.White;
            this.LB_chuabatdau.Name = "LB_chuabatdau";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // BTN_nhanvien
            // 
            this.BTN_nhanvien.AnimationHoverSpeed = 0.07F;
            this.BTN_nhanvien.AnimationSpeed = 0.03F;
            this.BTN_nhanvien.BackColor = System.Drawing.Color.Transparent;
            this.BTN_nhanvien.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_nhanvien.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_nhanvien.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_nhanvien.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_nhanvien, "BTN_nhanvien");
            this.BTN_nhanvien.ForeColor = System.Drawing.Color.White;
            this.BTN_nhanvien.Image = ((System.Drawing.Image)(resources.GetObject("BTN_nhanvien.Image")));
            this.BTN_nhanvien.ImageOffsetX = 20;
            this.BTN_nhanvien.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_nhanvien.Name = "BTN_nhanvien";
            this.BTN_nhanvien.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(73)))), ((int)(((byte)(75)))));
            this.BTN_nhanvien.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BTN_nhanvien.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_nhanvien.OnHoverImage = null;
            this.BTN_nhanvien.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_nhanvien.Radius = 5;
            this.BTN_nhanvien.TextOffsetX = 9;
            this.BTN_nhanvien.Click += new System.EventHandler(this.BTN_nhanvien_Click);
            // 
            // BTN_congviec
            // 
            this.BTN_congviec.AnimationHoverSpeed = 0.07F;
            this.BTN_congviec.AnimationSpeed = 0.03F;
            this.BTN_congviec.BackColor = System.Drawing.Color.Transparent;
            this.BTN_congviec.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_congviec.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_congviec.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_congviec.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_congviec, "BTN_congviec");
            this.BTN_congviec.ForeColor = System.Drawing.Color.White;
            this.BTN_congviec.Image = ((System.Drawing.Image)(resources.GetObject("BTN_congviec.Image")));
            this.BTN_congviec.ImageOffsetX = 20;
            this.BTN_congviec.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_congviec.Name = "BTN_congviec";
            this.BTN_congviec.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(73)))), ((int)(((byte)(75)))));
            this.BTN_congviec.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BTN_congviec.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_congviec.OnHoverImage = null;
            this.BTN_congviec.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_congviec.Radius = 5;
            this.BTN_congviec.TextOffsetX = 9;
            this.BTN_congviec.Click += new System.EventHandler(this.BTN_congviec_Click);
            // 
            // BTN_cudan
            // 
            this.BTN_cudan.AnimationHoverSpeed = 0.07F;
            this.BTN_cudan.AnimationSpeed = 0.03F;
            this.BTN_cudan.BackColor = System.Drawing.Color.Transparent;
            this.BTN_cudan.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_cudan.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_cudan.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_cudan.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_cudan, "BTN_cudan");
            this.BTN_cudan.ForeColor = System.Drawing.Color.White;
            this.BTN_cudan.Image = ((System.Drawing.Image)(resources.GetObject("BTN_cudan.Image")));
            this.BTN_cudan.ImageOffsetX = 20;
            this.BTN_cudan.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_cudan.Name = "BTN_cudan";
            this.BTN_cudan.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(73)))), ((int)(((byte)(75)))));
            this.BTN_cudan.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BTN_cudan.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_cudan.OnHoverImage = null;
            this.BTN_cudan.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_cudan.Radius = 5;
            this.BTN_cudan.TextOffsetX = 9;
            this.BTN_cudan.Click += new System.EventHandler(this.BTN_cudan_Click);
            // 
            // BTN_thongbao
            // 
            this.BTN_thongbao.AnimationHoverSpeed = 0.07F;
            this.BTN_thongbao.AnimationSpeed = 0.03F;
            this.BTN_thongbao.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thongbao.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_thongbao.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_thongbao.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thongbao.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_thongbao, "BTN_thongbao");
            this.BTN_thongbao.ForeColor = System.Drawing.Color.White;
            this.BTN_thongbao.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thongbao.Image")));
            this.BTN_thongbao.ImageOffsetX = 20;
            this.BTN_thongbao.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_thongbao.Name = "BTN_thongbao";
            this.BTN_thongbao.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(73)))), ((int)(((byte)(75)))));
            this.BTN_thongbao.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BTN_thongbao.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thongbao.OnHoverImage = null;
            this.BTN_thongbao.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_thongbao.Radius = 5;
            this.BTN_thongbao.TextOffsetX = 9;
            this.BTN_thongbao.Click += new System.EventHandler(this.BTN_thongbao_Click);
            // 
            // BTN_canho
            // 
            this.BTN_canho.AnimationHoverSpeed = 0.07F;
            this.BTN_canho.AnimationSpeed = 0.03F;
            this.BTN_canho.BackColor = System.Drawing.Color.Transparent;
            this.BTN_canho.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_canho.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_canho.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_canho.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_canho, "BTN_canho");
            this.BTN_canho.ForeColor = System.Drawing.Color.White;
            this.BTN_canho.Image = ((System.Drawing.Image)(resources.GetObject("BTN_canho.Image")));
            this.BTN_canho.ImageOffsetX = 20;
            this.BTN_canho.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_canho.Name = "BTN_canho";
            this.BTN_canho.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(73)))), ((int)(((byte)(75)))));
            this.BTN_canho.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BTN_canho.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_canho.OnHoverImage = null;
            this.BTN_canho.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_canho.Radius = 5;
            this.BTN_canho.TextOffsetX = 9;
            this.BTN_canho.Click += new System.EventHandler(this.BTN_canho_Click);
            // 
            // BTN_logout
            // 
            resources.ApplyResources(this.BTN_logout, "BTN_logout");
            this.BTN_logout.AnimationHoverSpeed = 0.07F;
            this.BTN_logout.AnimationSpeed = 0.03F;
            this.BTN_logout.BackColor = System.Drawing.Color.Transparent;
            this.BTN_logout.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_logout.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_logout.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_logout.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_logout.ForeColor = System.Drawing.Color.Red;
            this.BTN_logout.Image = ((System.Drawing.Image)(resources.GetObject("BTN_logout.Image")));
            this.BTN_logout.ImageOffsetX = 20;
            this.BTN_logout.ImageSize = new System.Drawing.Size(25, 25);
            this.BTN_logout.Name = "BTN_logout";
            this.BTN_logout.OnHoverBaseColor = System.Drawing.Color.Red;
            this.BTN_logout.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_logout.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_logout.OnHoverImage = ((System.Drawing.Image)(resources.GetObject("BTN_logout.OnHoverImage")));
            this.BTN_logout.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_logout.Radius = 5;
            this.BTN_logout.TextOffsetX = 9;
            this.BTN_logout.Click += new System.EventHandler(this.BTN_logout_Click);
            // 
            // BTN_thongke
            // 
            this.BTN_thongke.AnimationHoverSpeed = 0.07F;
            this.BTN_thongke.AnimationSpeed = 0.03F;
            this.BTN_thongke.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thongke.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_thongke.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_thongke.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thongke.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_thongke, "BTN_thongke");
            this.BTN_thongke.ForeColor = System.Drawing.Color.White;
            this.BTN_thongke.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thongke.Image")));
            this.BTN_thongke.ImageOffsetX = 20;
            this.BTN_thongke.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_thongke.Name = "BTN_thongke";
            this.BTN_thongke.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(73)))), ((int)(((byte)(75)))));
            this.BTN_thongke.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BTN_thongke.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thongke.OnHoverImage = null;
            this.BTN_thongke.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_thongke.Radius = 5;
            this.BTN_thongke.TextOffsetX = 9;
            this.BTN_thongke.Click += new System.EventHandler(this.BTN_thongke_Click);
            // 
            // P_logotasmana
            // 
            this.P_logotasmana.BackColor = System.Drawing.Color.Transparent;
            this.P_logotasmana.BaseColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.P_logotasmana, "P_logotasmana");
            this.P_logotasmana.Name = "P_logotasmana";
            this.P_logotasmana.TabStop = false;
            this.P_logotasmana.Click += new System.EventHandler(this.P_logotasmana_Click);
            // 
            // LB_tendangnhap
            // 
            resources.ApplyResources(this.LB_tendangnhap, "LB_tendangnhap");
            this.LB_tendangnhap.BackColor = System.Drawing.Color.Transparent;
            this.LB_tendangnhap.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LB_tendangnhap.Name = "LB_tendangnhap";
            // 
            // Timer_KTCongViec
            // 
            this.Timer_KTCongViec.Enabled = true;
            this.Timer_KTCongViec.Interval = 1000;
            this.Timer_KTCongViec.Tick += new System.EventHandler(this.Timer_KTCongViec_Tick);
            // 
            // NTFIcon_ThongBaoCV
            // 
            this.NTFIcon_ThongBaoCV.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            resources.ApplyResources(this.NTFIcon_ThongBaoCV, "NTFIcon_ThongBaoCV");
            // 
            // PN_main
            // 
            resources.ApplyResources(this.PN_main, "PN_main");
            this.PN_main.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.PN_main.Controls.Add(this.gunaPictureBox3);
            this.PN_main.Controls.Add(this.label1);
            this.PN_main.Name = "PN_main";
            // 
            // gunaPictureBox3
            // 
            resources.ApplyResources(this.gunaPictureBox3, "gunaPictureBox3");
            this.gunaPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.Transparent;
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.TabStop = false;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Name = "label1";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Name = "panel8";
            // 
            // PB_question
            // 
            resources.ApplyResources(this.PB_question, "PB_question");
            this.PB_question.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PB_question.Name = "PB_question";
            this.PB_question.TabStop = false;
            this.PB_question.Click += new System.EventHandler(this.PB_question_Click);
            // 
            // PB_language
            // 
            resources.ApplyResources(this.PB_language, "PB_language");
            this.PB_language.Name = "PB_language";
            this.PB_language.TabStop = false;
            this.PB_language.Click += new System.EventHandler(this.PB_language_Click);
            // 
            // gunaGradientButton1
            // 
            resources.ApplyResources(this.gunaGradientButton1, "gunaGradientButton1");
            this.gunaGradientButton1.AnimationHoverSpeed = 1F;
            this.gunaGradientButton1.AnimationSpeed = 1F;
            this.gunaGradientButton1.BaseColor1 = System.Drawing.Color.Transparent;
            this.gunaGradientButton1.BaseColor2 = System.Drawing.Color.Transparent;
            this.gunaGradientButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientButton1.ForeColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.Image = ((System.Drawing.Image)(resources.GetObject("gunaGradientButton1.Image")));
            this.gunaGradientButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton1.ImageSize = new System.Drawing.Size(25, 20);
            this.gunaGradientButton1.Name = "gunaGradientButton1";
            this.gunaGradientButton1.OnHoverBaseColor1 = System.Drawing.Color.Silver;
            this.gunaGradientButton1.OnHoverBaseColor2 = System.Drawing.Color.Silver;
            this.gunaGradientButton1.OnHoverBorderColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverImage = null;
            this.gunaGradientButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton1.Click += new System.EventHandler(this.gunaGradientButton1_Click);
            // 
            // BTN_thongtin
            // 
            this.BTN_thongtin.AnimationHoverSpeed = 0.07F;
            this.BTN_thongtin.AnimationSpeed = 0.03F;
            this.BTN_thongtin.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thongtin.BaseColor = System.Drawing.Color.Transparent;
            this.BTN_thongtin.BorderColor = System.Drawing.Color.Black;
            this.BTN_thongtin.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thongtin.FocusedColor = System.Drawing.Color.Empty;
            resources.ApplyResources(this.BTN_thongtin, "BTN_thongtin");
            this.BTN_thongtin.ForeColor = System.Drawing.Color.White;
            this.BTN_thongtin.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thongtin.Image")));
            this.BTN_thongtin.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thongtin.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_thongtin.Name = "BTN_thongtin";
            this.BTN_thongtin.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.BTN_thongtin.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thongtin.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thongtin.OnHoverImage = null;
            this.BTN_thongtin.OnPressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BTN_thongtin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thongtin.Click += new System.EventHandler(this.BTN_thongtin_Click);
            // 
            // BTN_square
            // 
            resources.ApplyResources(this.BTN_square, "BTN_square");
            this.BTN_square.AnimationHoverSpeed = 1F;
            this.BTN_square.AnimationSpeed = 1F;
            this.BTN_square.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_square.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_square.BorderColor = System.Drawing.Color.Black;
            this.BTN_square.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_square.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_square.ForeColor = System.Drawing.Color.Black;
            this.BTN_square.Image = ((System.Drawing.Image)(resources.GetObject("BTN_square.Image")));
            this.BTN_square.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_square.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_square.Name = "BTN_square";
            this.BTN_square.OnHoverBaseColor1 = System.Drawing.Color.Silver;
            this.BTN_square.OnHoverBaseColor2 = System.Drawing.Color.Silver;
            this.BTN_square.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_square.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_square.OnHoverImage = null;
            this.BTN_square.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_square.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_square.Click += new System.EventHandler(this.BTN_square_Click);
            // 
            // BTN_x
            // 
            resources.ApplyResources(this.BTN_x, "BTN_x");
            this.BTN_x.AnimationHoverSpeed = 1F;
            this.BTN_x.AnimationSpeed = 1F;
            this.BTN_x.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_x.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_x.BorderColor = System.Drawing.Color.Black;
            this.BTN_x.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_x.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_x.ForeColor = System.Drawing.Color.Black;
            this.BTN_x.Image = ((System.Drawing.Image)(resources.GetObject("BTN_x.Image")));
            this.BTN_x.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_x.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_x.Name = "BTN_x";
            this.BTN_x.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_x.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_x.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_x.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_x.OnHoverImage = null;
            this.BTN_x.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_x.Click += new System.EventHandler(this.BTN_x_Click);
            // 
            // TrangHienThi
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.PB_question);
            this.Controls.Add(this.PB_language);
            this.Controls.Add(this.gunaGradientButton1);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.PN_main);
            this.Controls.Add(this.LB_tendangnhap);
            this.Controls.Add(this.BTN_thongtin);
            this.Controls.Add(this.BTN_square);
            this.Controls.Add(this.BTN_x);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TrangHienThi";
            this.Load += new System.EventHandler(this.TrangHienThi_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TrangHienThi_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TrangHienThi_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TrangHienThi_MouseUp);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P_logotasmana)).EndInit();
            this.PN_main.ResumeLayout(false);
            this.PN_main.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_question)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_language)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaButton BTN_nhanvien;
        private Guna.UI.WinForms.GunaButton BTN_congviec;
        private Guna.UI.WinForms.GunaButton BTN_cudan;
        private Guna.UI.WinForms.GunaButton BTN_thongbao;
        private Guna.UI.WinForms.GunaButton BTN_canho;
        private Guna.UI.WinForms.GunaButton BTN_logout;
        private Guna.UI.WinForms.GunaButton BTN_thongke;
        private System.Windows.Forms.Label LB_tendangnhap;
        private Guna.UI.WinForms.GunaButton BTN_thongtin;
        private Guna.UI.WinForms.GunaGradientButton BTN_square;
        private Guna.UI.WinForms.GunaGradientButton BTN_x;
        private System.Windows.Forms.Timer Timer_KTCongViec;
        private System.Windows.Forms.NotifyIcon NTFIcon_ThongBaoCV;
        private System.Windows.Forms.Panel PN_main;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LB_chuabatdau;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox3;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox2;
        private Guna.UI.WinForms.GunaGradientButton gunaGradientButton1;
        private System.Windows.Forms.Label label4;
        private Guna.UI.WinForms.GunaPictureBox P_logotasmana;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private System.Windows.Forms.Label LB_SoCV_TreHan;
        private System.Windows.Forms.Label LB_SoCV_DangTienHanh;
        private System.Windows.Forms.Label LB_SoCongViecCBD;
        private System.Windows.Forms.Label LB_SoCV_CoCapNhat;
        private System.Windows.Forms.Label LB_CapNhat;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox4;
        private System.Windows.Forms.PictureBox PB_language;
        private System.Windows.Forms.PictureBox PB_question;
    }
}