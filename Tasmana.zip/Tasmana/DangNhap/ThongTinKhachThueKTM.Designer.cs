﻿
namespace DangNhap
{
    partial class ThongTinKhachThueKTM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinKhachThueKTM));
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LB_ttcd = new System.Windows.Forms.Label();
            this.PN_hienthi = new System.Windows.Forms.Panel();
            this.LB_errortinhtrangxe = new System.Windows.Forms.Label();
            this.LB_errorloaixe = new System.Windows.Forms.Label();
            this.CBB_manv = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LB_erroremail = new System.Windows.Forms.Label();
            this.LB_errorsdt = new System.Windows.Forms.Label();
            this.LB_errhoten = new System.Windows.Forms.Label();
            this.LB_errortencty = new System.Windows.Forms.Label();
            this.LB_errmakhachthue = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.NUD_phiql = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.TXB_mota = new System.Windows.Forms.TextBox();
            this.TXB_tinhtrangxe = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.TXB_loaixe = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.TXB_bienso = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.DTP_di = new System.Windows.Forms.DateTimePicker();
            this.DTP_vao = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.DTP_ngaykyhd = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.TXB_hotendaidien = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.TXB_tencongty = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TXB_email = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TXB_sdt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TXB_makhachthue = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.numericUpDownExt4 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label16 = new System.Windows.Forms.Label();
            this.numericUpDownExt5 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownExt6 = new Syncfusion.Windows.Forms.Tools.NumericUpDownExt();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BTN_luu = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_xoa = new Guna.UI.WinForms.GunaGradientButton();
            this.BTN_thoat = new Guna.UI.WinForms.GunaGradientButton();
            this.PN_hienthi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_phiql)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt6)).BeginInit();
            this.SuspendLayout();
            // 
            // panel5
            // 
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Name = "panel5";
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Name = "panel4";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Name = "panel3";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Name = "panel2";
            // 
            // LB_ttcd
            // 
            resources.ApplyResources(this.LB_ttcd, "LB_ttcd");
            this.LB_ttcd.BackColor = System.Drawing.Color.Transparent;
            this.LB_ttcd.ForeColor = System.Drawing.Color.White;
            this.LB_ttcd.Name = "LB_ttcd";
            // 
            // PN_hienthi
            // 
            resources.ApplyResources(this.PN_hienthi, "PN_hienthi");
            this.PN_hienthi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(31)))), ((int)(((byte)(33)))));
            this.PN_hienthi.Controls.Add(this.LB_errortinhtrangxe);
            this.PN_hienthi.Controls.Add(this.LB_errorloaixe);
            this.PN_hienthi.Controls.Add(this.CBB_manv);
            this.PN_hienthi.Controls.Add(this.label1);
            this.PN_hienthi.Controls.Add(this.LB_erroremail);
            this.PN_hienthi.Controls.Add(this.LB_errorsdt);
            this.PN_hienthi.Controls.Add(this.LB_errhoten);
            this.PN_hienthi.Controls.Add(this.LB_errortencty);
            this.PN_hienthi.Controls.Add(this.LB_errmakhachthue);
            this.PN_hienthi.Controls.Add(this.label10);
            this.PN_hienthi.Controls.Add(this.NUD_phiql);
            this.PN_hienthi.Controls.Add(this.label5);
            this.PN_hienthi.Controls.Add(this.TXB_mota);
            this.PN_hienthi.Controls.Add(this.TXB_tinhtrangxe);
            this.PN_hienthi.Controls.Add(this.label27);
            this.PN_hienthi.Controls.Add(this.TXB_loaixe);
            this.PN_hienthi.Controls.Add(this.label21);
            this.PN_hienthi.Controls.Add(this.TXB_bienso);
            this.PN_hienthi.Controls.Add(this.label25);
            this.PN_hienthi.Controls.Add(this.DTP_di);
            this.PN_hienthi.Controls.Add(this.DTP_vao);
            this.PN_hienthi.Controls.Add(this.label24);
            this.PN_hienthi.Controls.Add(this.DTP_ngaykyhd);
            this.PN_hienthi.Controls.Add(this.label9);
            this.PN_hienthi.Controls.Add(this.TXB_hotendaidien);
            this.PN_hienthi.Controls.Add(this.label22);
            this.PN_hienthi.Controls.Add(this.TXB_tencongty);
            this.PN_hienthi.Controls.Add(this.label8);
            this.PN_hienthi.Controls.Add(this.label6);
            this.PN_hienthi.Controls.Add(this.TXB_email);
            this.PN_hienthi.Controls.Add(this.label4);
            this.PN_hienthi.Controls.Add(this.TXB_sdt);
            this.PN_hienthi.Controls.Add(this.label2);
            this.PN_hienthi.Controls.Add(this.label7);
            this.PN_hienthi.Controls.Add(this.TXB_makhachthue);
            this.PN_hienthi.Controls.Add(this.panel7);
            this.PN_hienthi.Controls.Add(this.panel1);
            this.PN_hienthi.Name = "PN_hienthi";
            // 
            // LB_errortinhtrangxe
            // 
            resources.ApplyResources(this.LB_errortinhtrangxe, "LB_errortinhtrangxe");
            this.LB_errortinhtrangxe.ForeColor = System.Drawing.Color.Red;
            this.LB_errortinhtrangxe.Name = "LB_errortinhtrangxe";
            // 
            // LB_errorloaixe
            // 
            resources.ApplyResources(this.LB_errorloaixe, "LB_errorloaixe");
            this.LB_errorloaixe.ForeColor = System.Drawing.Color.Red;
            this.LB_errorloaixe.Name = "LB_errorloaixe";
            // 
            // CBB_manv
            // 
            resources.ApplyResources(this.CBB_manv, "CBB_manv");
            this.CBB_manv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.CBB_manv.ForeColor = System.Drawing.Color.White;
            this.CBB_manv.FormattingEnabled = true;
            this.CBB_manv.Name = "CBB_manv";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // LB_erroremail
            // 
            resources.ApplyResources(this.LB_erroremail, "LB_erroremail");
            this.LB_erroremail.ForeColor = System.Drawing.Color.Red;
            this.LB_erroremail.Name = "LB_erroremail";
            // 
            // LB_errorsdt
            // 
            resources.ApplyResources(this.LB_errorsdt, "LB_errorsdt");
            this.LB_errorsdt.ForeColor = System.Drawing.Color.Red;
            this.LB_errorsdt.Name = "LB_errorsdt";
            // 
            // LB_errhoten
            // 
            resources.ApplyResources(this.LB_errhoten, "LB_errhoten");
            this.LB_errhoten.ForeColor = System.Drawing.Color.Red;
            this.LB_errhoten.Name = "LB_errhoten";
            // 
            // LB_errortencty
            // 
            resources.ApplyResources(this.LB_errortencty, "LB_errortencty");
            this.LB_errortencty.ForeColor = System.Drawing.Color.Red;
            this.LB_errortencty.Name = "LB_errortencty";
            // 
            // LB_errmakhachthue
            // 
            resources.ApplyResources(this.LB_errmakhachthue, "LB_errmakhachthue");
            this.LB_errmakhachthue.ForeColor = System.Drawing.Color.Red;
            this.LB_errmakhachthue.Name = "LB_errmakhachthue";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Name = "label10";
            // 
            // NUD_phiql
            // 
            resources.ApplyResources(this.NUD_phiql, "NUD_phiql");
            this.NUD_phiql.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.NUD_phiql.ForeColor = System.Drawing.Color.White;
            this.NUD_phiql.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NUD_phiql.Name = "NUD_phiql";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Name = "label5";
            // 
            // TXB_mota
            // 
            resources.ApplyResources(this.TXB_mota, "TXB_mota");
            this.TXB_mota.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_mota.ForeColor = System.Drawing.Color.White;
            this.TXB_mota.Name = "TXB_mota";
            // 
            // TXB_tinhtrangxe
            // 
            resources.ApplyResources(this.TXB_tinhtrangxe, "TXB_tinhtrangxe");
            this.TXB_tinhtrangxe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_tinhtrangxe.ForeColor = System.Drawing.Color.White;
            this.TXB_tinhtrangxe.Name = "TXB_tinhtrangxe";
            this.TXB_tinhtrangxe.TextChanged += new System.EventHandler(this.TXB_tinhtrangxe_TextChanged);
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Name = "label27";
            // 
            // TXB_loaixe
            // 
            resources.ApplyResources(this.TXB_loaixe, "TXB_loaixe");
            this.TXB_loaixe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_loaixe.ForeColor = System.Drawing.Color.White;
            this.TXB_loaixe.Name = "TXB_loaixe";
            this.TXB_loaixe.TextChanged += new System.EventHandler(this.TXB_loaixe_TextChanged);
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Name = "label21";
            // 
            // TXB_bienso
            // 
            resources.ApplyResources(this.TXB_bienso, "TXB_bienso");
            this.TXB_bienso.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_bienso.ForeColor = System.Drawing.Color.White;
            this.TXB_bienso.Name = "TXB_bienso";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Name = "label25";
            // 
            // DTP_di
            // 
            resources.ApplyResources(this.DTP_di, "DTP_di");
            this.DTP_di.Name = "DTP_di";
            // 
            // DTP_vao
            // 
            resources.ApplyResources(this.DTP_vao, "DTP_vao");
            this.DTP_vao.Name = "DTP_vao";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Name = "label24";
            // 
            // DTP_ngaykyhd
            // 
            resources.ApplyResources(this.DTP_ngaykyhd, "DTP_ngaykyhd");
            this.DTP_ngaykyhd.Name = "DTP_ngaykyhd";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Name = "label9";
            // 
            // TXB_hotendaidien
            // 
            resources.ApplyResources(this.TXB_hotendaidien, "TXB_hotendaidien");
            this.TXB_hotendaidien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_hotendaidien.ForeColor = System.Drawing.Color.White;
            this.TXB_hotendaidien.Name = "TXB_hotendaidien";
            this.TXB_hotendaidien.TextChanged += new System.EventHandler(this.TXB_hotendaidien_TextChanged);
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Name = "label22";
            // 
            // TXB_tencongty
            // 
            resources.ApplyResources(this.TXB_tencongty, "TXB_tencongty");
            this.TXB_tencongty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_tencongty.ForeColor = System.Drawing.Color.White;
            this.TXB_tencongty.Name = "TXB_tencongty";
            this.TXB_tencongty.TextChanged += new System.EventHandler(this.TXB_tencongty_TextChanged);
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Name = "label8";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            // 
            // TXB_email
            // 
            resources.ApplyResources(this.TXB_email, "TXB_email");
            this.TXB_email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_email.ForeColor = System.Drawing.Color.White;
            this.TXB_email.Name = "TXB_email";
            this.TXB_email.TextChanged += new System.EventHandler(this.TXB_email_TextChanged);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            // 
            // TXB_sdt
            // 
            resources.ApplyResources(this.TXB_sdt, "TXB_sdt");
            this.TXB_sdt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_sdt.ForeColor = System.Drawing.Color.White;
            this.TXB_sdt.Name = "TXB_sdt";
            this.TXB_sdt.TextChanged += new System.EventHandler(this.TXB_sdt_TextChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Name = "label7";
            // 
            // TXB_makhachthue
            // 
            resources.ApplyResources(this.TXB_makhachthue, "TXB_makhachthue");
            this.TXB_makhachthue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.TXB_makhachthue.ForeColor = System.Drawing.Color.White;
            this.TXB_makhachthue.Name = "TXB_makhachthue";
            this.TXB_makhachthue.TextChanged += new System.EventHandler(this.TXB_makhachthue_TextChanged);
            // 
            // panel7
            // 
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.BackColor = System.Drawing.Color.Silver;
            this.panel7.Name = "panel7";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.numericUpDownExt4);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.numericUpDownExt5);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.numericUpDownExt6);
            this.panel1.Name = "panel1";
            // 
            // panel8
            // 
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.BackColor = System.Drawing.Color.Silver;
            this.panel8.Name = "panel8";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Name = "label13";
            // 
            // textBox3
            // 
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Name = "textBox3";
            // 
            // comboBox2
            // 
            resources.ApplyResources(this.comboBox2, "comboBox2");
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.comboBox2.ForeColor = System.Drawing.Color.White;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Name = "comboBox2";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Name = "label14";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Name = "label18";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Name = "label15";
            // 
            // textBox4
            // 
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.textBox4.ForeColor = System.Drawing.Color.White;
            this.textBox4.Name = "textBox4";
            // 
            // numericUpDownExt4
            // 
            resources.ApplyResources(this.numericUpDownExt4, "numericUpDownExt4");
            this.numericUpDownExt4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt4.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt4.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt4.Name = "numericUpDownExt4";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Name = "label16";
            // 
            // numericUpDownExt5
            // 
            resources.ApplyResources(this.numericUpDownExt5, "numericUpDownExt5");
            this.numericUpDownExt5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt5.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt5.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt5.Name = "numericUpDownExt5";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Name = "label17";
            // 
            // numericUpDownExt6
            // 
            resources.ApplyResources(this.numericUpDownExt6, "numericUpDownExt6");
            this.numericUpDownExt6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.numericUpDownExt6.BeforeTouchSize = new System.Drawing.Size(375, 30);
            this.numericUpDownExt6.ForeColor = System.Drawing.Color.White;
            this.numericUpDownExt6.Name = "numericUpDownExt6";
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.BackColor = System.Drawing.Color.Silver;
            this.panel6.Name = "panel6";
            // 
            // BTN_luu
            // 
            resources.ApplyResources(this.BTN_luu, "BTN_luu");
            this.BTN_luu.Animated = true;
            this.BTN_luu.AnimationHoverSpeed = 0.5F;
            this.BTN_luu.AnimationSpeed = 0.03F;
            this.BTN_luu.BackColor = System.Drawing.Color.Transparent;
            this.BTN_luu.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(184)))));
            this.BTN_luu.BorderColor = System.Drawing.Color.Black;
            this.BTN_luu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_luu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_luu.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_luu.ForeColor = System.Drawing.Color.White;
            this.BTN_luu.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.BTN_luu.Image = null;
            this.BTN_luu.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_luu.Name = "BTN_luu";
            this.BTN_luu.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(40)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(40)))), ((int)(((byte)(184)))));
            this.BTN_luu.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_luu.OnHoverImage = null;
            this.BTN_luu.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_luu.Radius = 5;
            this.BTN_luu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_luu.Click += new System.EventHandler(this.BTN_luu_Click);
            // 
            // BTN_xoa
            // 
            resources.ApplyResources(this.BTN_xoa, "BTN_xoa");
            this.BTN_xoa.Animated = true;
            this.BTN_xoa.AnimationHoverSpeed = 0.2F;
            this.BTN_xoa.AnimationSpeed = 0.03F;
            this.BTN_xoa.BackColor = System.Drawing.Color.Transparent;
            this.BTN_xoa.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_xoa.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_xoa.BorderColor = System.Drawing.Color.Red;
            this.BTN_xoa.BorderSize = 1;
            this.BTN_xoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_xoa.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_xoa.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_xoa.ForeColor = System.Drawing.Color.Red;
            this.BTN_xoa.Image = null;
            this.BTN_xoa.ImageSize = new System.Drawing.Size(20, 20);
            this.BTN_xoa.Name = "BTN_xoa";
            this.BTN_xoa.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_xoa.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(30)))), ((int)(((byte)(43)))));
            this.BTN_xoa.OnHoverBorderColor = System.Drawing.Color.White;
            this.BTN_xoa.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_xoa.OnHoverImage = null;
            this.BTN_xoa.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_xoa.Radius = 5;
            this.BTN_xoa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_xoa.Click += new System.EventHandler(this.BTN_xoa_Click);
            // 
            // BTN_thoat
            // 
            resources.ApplyResources(this.BTN_thoat, "BTN_thoat");
            this.BTN_thoat.AnimationHoverSpeed = 0.5F;
            this.BTN_thoat.AnimationSpeed = 0.03F;
            this.BTN_thoat.BackColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor1 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BaseColor2 = System.Drawing.Color.Transparent;
            this.BTN_thoat.BorderColor = System.Drawing.Color.Transparent;
            this.BTN_thoat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BTN_thoat.FocusedColor = System.Drawing.Color.Empty;
            this.BTN_thoat.ForeColor = System.Drawing.Color.Black;
            this.BTN_thoat.Image = ((System.Drawing.Image)(resources.GetObject("BTN_thoat.Image")));
            this.BTN_thoat.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.ImageSize = new System.Drawing.Size(10, 10);
            this.BTN_thoat.Name = "BTN_thoat";
            this.BTN_thoat.OnHoverBaseColor1 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBaseColor2 = System.Drawing.Color.Red;
            this.BTN_thoat.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BTN_thoat.OnHoverForeColor = System.Drawing.Color.White;
            this.BTN_thoat.OnHoverImage = null;
            this.BTN_thoat.OnPressedColor = System.Drawing.Color.Black;
            this.BTN_thoat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BTN_thoat.Click += new System.EventHandler(this.BTN_thoat_Click);
            // 
            // ThongTinKhachThueKTM
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(38)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.BTN_xoa);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.BTN_luu);
            this.Controls.Add(this.BTN_thoat);
            this.Controls.Add(this.PN_hienthi);
            this.Controls.Add(this.LB_ttcd);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ThongTinKhachThueKTM";
            this.Load += new System.EventHandler(this.ThongTinCuDan_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TTKTM_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TTKTM_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TTKTM_MouseUp);
            this.PN_hienthi.ResumeLayout(false);
            this.PN_hienthi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_phiql)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownExt6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label LB_ttcd;
        private System.Windows.Forms.Panel PN_hienthi;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox4;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt4;
        private System.Windows.Forms.Label label16;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt5;
        private System.Windows.Forms.Label label17;
        private Syncfusion.Windows.Forms.Tools.NumericUpDownExt numericUpDownExt6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TXB_makhachthue;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXB_email;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TXB_sdt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox TXB_tencongty;
        private Guna.UI.WinForms.GunaGradientButton BTN_thoat;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI.WinForms.GunaGradientButton BTN_luu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TXB_hotendaidien;
        private System.Windows.Forms.DateTimePicker DTP_ngaykyhd;
        private System.Windows.Forms.DateTimePicker DTP_di;
        private System.Windows.Forms.DateTimePicker DTP_vao;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox TXB_tinhtrangxe;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox TXB_loaixe;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox TXB_bienso;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown NUD_phiql;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TXB_mota;
        private Guna.UI.WinForms.GunaGradientButton BTN_xoa;
        private System.Windows.Forms.Label LB_erroremail;
        private System.Windows.Forms.Label LB_errorsdt;
        private System.Windows.Forms.Label LB_errhoten;
        private System.Windows.Forms.Label LB_errortencty;
        private System.Windows.Forms.Label LB_errmakhachthue;
        private System.Windows.Forms.ComboBox CBB_manv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LB_errortinhtrangxe;
        private System.Windows.Forms.Label LB_errorloaixe;
    }
}