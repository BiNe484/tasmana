﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DangNhap
{
    class Constraint
    {
        public static int NotifyTime = 1;
        public static int NotifyTimeOut = 250;
    }
}
